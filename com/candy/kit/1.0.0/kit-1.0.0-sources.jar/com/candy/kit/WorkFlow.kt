package com.candy.kit

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.util.UUID

/**
 * 工作流任务管理器
 * @author: ChenYang
 * @date: 2026-04-11 18:18
 */
class WorkFlow(
    parentScope: CoroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
) {
    private val workJob = SupervisorJob(parentScope.coroutineContext[Job])
    private val scope = CoroutineScope(parentScope.coroutineContext + workJob)

    private val queue = ArrayDeque<TaskHandle>()
    private val lock = Any()
    private val signal = Channel<Unit>(Channel.CONFLATED)

    //当前正在运行的任务
    private var currentHandle: TaskHandle? = null
    private var currentJob: Job? = null
    private var stopped = false

    init {
        scope.launch {
            while (isActive) {
                val runningTask = synchronized(lock) {
                    queue.removeFirstOrNull()?.let { handle ->
                        val job = launch(start = CoroutineStart.LAZY) {
                            try {
                                handle.task()
                            } catch (_: CancellationException) {
                                // 任务取消
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                        currentHandle = handle
                        currentJob = job
                        RunningTask(handle, job)
                    }
                }

                if (runningTask != null) {
                    runningTask.job.start()
                    runningTask.job.join()

                    synchronized(lock) {
                        if (
                            currentHandle === runningTask.handle &&
                            currentJob === runningTask.job
                        ) {
                            currentHandle = null
                            currentJob = null
                        }
                    }
                } else {
                    if (signal.receiveCatching().isClosed) break
                }
            }
        }
    }

    /**
     * 提交普通任务
     * @param key 任务唯一标识
     * @param replaceRunning 如果该 Key 的任务正在运行，是否中断并替换
     * @param timeoutMillis 任务开始执行后的超时时间；null 表示不超时
     */
    fun post(
        key: String = UUID.randomUUID().toString(),
        replaceRunning: Boolean = false,
        timeoutMillis: Long? = null,
        block: suspend () -> Unit
    ): String = wrapAndEnqueue(
        key = key,
        isFirst = false,
        replaceRunning = replaceRunning,
        timeoutMillis = timeoutMillis,
        block = block
    )

    /**
     * 提交高优先级任务（插入队首）
     * @param timeoutMillis 任务开始执行后的超时时间；null 表示不超时
     */
    fun postFirst(
        key: String = UUID.randomUUID().toString(),
        replaceRunning: Boolean = false,
        timeoutMillis: Long? = null,
        block: suspend () -> Unit
    ): String = wrapAndEnqueue(
        key = key,
        isFirst = true,
        replaceRunning = replaceRunning,
        timeoutMillis = timeoutMillis,
        block = block
    )

    /**
     * 提交异步任务（需手动调用 taskDone）
     * @param timeoutMillis 任务开始执行后的超时时间；null 表示不超时
     */
    fun postAsync(
        key: String = UUID.randomUUID().toString(),
        replaceRunning: Boolean = false,
        timeoutMillis: Long? = null,
        block: suspend TaskScope.() -> Unit
    ): String = wrapAndEnqueue(
        key = key,
        isFirst = false,
        isAsync = true,
        replaceRunning = replaceRunning,
        timeoutMillis = timeoutMillis,
        asyncBlock = block
    )

    private fun wrapAndEnqueue(
        key: String,
        isFirst: Boolean,
        isAsync: Boolean = false,
        replaceRunning: Boolean = false,
        timeoutMillis: Long? = null,
        block: (suspend () -> Unit)? = null,
        asyncBlock: (suspend TaskScope.() -> Unit)? = null
    ): String {
        require(timeoutMillis == null || timeoutMillis > 0) {
            "timeoutMillis must be greater than 0"
        }

        val executeTask: suspend () -> Unit = {
            if (isAsync) {
                val deferred = CompletableDeferred<Unit>()
                val taskScope = object : TaskScope {
                    override fun taskDone() {
                        if (deferred.isActive) deferred.complete(Unit)
                    }
                }
                asyncBlock?.invoke(taskScope)
                deferred.await()
            } else {
                block?.invoke()
            }
        }

        val taskLogic: suspend () -> Unit = {
            if (timeoutMillis == null) {
                executeTask()
            } else {
                withTimeout(timeoutMillis) { executeTask() }
            }
        }

        val newHandle = TaskHandle(key, taskLogic)
        var queueChanged = false

        synchronized(lock) {
            check(!stopped) { "WorkFlow has been stopped" }

            //检查是否正在运行
            if (currentHandle?.key == key) {
                if (replaceRunning) {
                    currentJob?.cancel()
                    queue.addFirst(newHandle)
                    queueChanged = true
                }
                //如果replaceRunning为false忽略任务
            } else {
                //检查是否在队列中排队，如果是则替换
                val indexInQueue = queue.indexOfFirst { it.key == key }
                if (indexInQueue != -1) {
                    queue.removeAt(indexInQueue)
                }
                if (isFirst) queue.addFirst(newHandle) else queue.addLast(newHandle)
                queueChanged = true
            }
        }

        if (queueChanged) signal.trySend(Unit)
        return key
    }

    fun hasTask(key: String): Boolean = synchronized(lock) {
        currentHandle?.key == key || queue.any { it.key == key }
    }

    fun isTaskRunning(key: String): Boolean = synchronized(lock) {
        currentHandle?.key == key
    }

    fun getAllTask(): List<String> = synchronized(lock) {
        val keys = mutableListOf<String>()
        currentHandle?.let { keys.add(it.key) }
        keys.addAll(queue.map { it.key })
        keys
    }

    fun getRunningTask(): String? = synchronized(lock) { currentHandle?.key }

    /**
     * 移除任务
     * @param key 任务标识
     * @param cancelIfRunning 如果任务正在运行，是否取消
     */
    fun remove(key: String, cancelIfRunning: Boolean = true) {
        synchronized(lock) {
            if (currentHandle?.key == key) {
                if (cancelIfRunning) {
                    currentJob?.cancel()
                    currentHandle = null
                    currentJob = null
                }
            } else {
                queue.removeAll { it.key == key }
            }
        }
    }

    fun stop() {
        val shouldStop = synchronized(lock) {
            if (stopped) {
                false
            } else {
                stopped = true
                queue.clear()
                currentHandle = null
                currentJob = null
                true
            }
        }
        if (!shouldStop) return

        signal.close()
        workJob.cancel()
    }

    interface TaskScope {
        fun taskDone()
    }

    class TaskHandle(val key: String, val task: suspend () -> Unit)

    private class RunningTask(val handle: TaskHandle, val job: Job)
}
