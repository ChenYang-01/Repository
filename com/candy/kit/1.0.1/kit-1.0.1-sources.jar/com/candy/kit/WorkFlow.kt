package com.candy.kit

import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.util.UUID
import kotlin.coroutines.CoroutineContext
import kotlin.time.Duration.Companion.milliseconds

/**
 * 工作流任务管理器
 * @author: ChenYang
 * @date: 2026-04-11 18:18
 */
class WorkFlow(
    parentScope: CoroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
) {
    private val workJob = SupervisorJob(parentScope.coroutineContext[Job])
    private val scope = CoroutineScope(parentScope.coroutineContext + workJob)
    private val parentExceptionHandler =
        parentScope.coroutineContext[CoroutineExceptionHandler]

    private val queue = ArrayDeque<WorkHandle>()
    private val lock = Any()
    private val signal = Channel<Unit>(Channel.CONFLATED)

    //当前正在运行的任务
    private var currentHandle: WorkHandle? = null
    private var currentJob: Job? = null
    private var stopped = false

    /**
     * 普通任务异常回调，在任务使用的协程上下文中调用。取消和超时不会触发该回调。
     */
    @Volatile
    var onWorkError: ((key: String, throwable: Throwable) -> Unit)? = null

    init {
        workJob.invokeOnCompletion {
            synchronized(lock) {
                stopped = true
                queue.clear()
                currentHandle = null
                currentJob = null
            }
            signal.close()
        }

        scope.launch {
            while (isActive) {
                val runningWork = synchronized(lock) {
                    queue.removeFirstOrNull()?.let { handle ->
                        // 任务作为 SupervisorJob 的直接子协程运行，异常不会中断工作循环，
                        // 取消继续传播，普通异常由 WorkFlow 统一报告。
                        val job = scope.launch(start = CoroutineStart.LAZY) {
                            try {
                                handle.work()
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                reportWorkError(handle.key, e, coroutineContext)
                            }
                        }
                        currentHandle = handle
                        currentJob = job
                        RunningWork(handle, job)
                    }
                }

                if (runningWork != null) {
                    runningWork.job.start()
                    runningWork.job.join()

                    synchronized(lock) {
                        if (
                            currentHandle === runningWork.handle &&
                            currentJob === runningWork.job
                        ) {
                            currentHandle = null
                            currentJob = null
                        }
                    }
                } else {
                    if (signal.receiveCatching().isClosed) break
                }
            }
        }
    }

    private fun reportWorkError(
        key: String,
        throwable: Throwable,
        coroutineContext: CoroutineContext
    ) {
        try {
            val callback = onWorkError
            when {
                callback != null -> callback(key, throwable)
                parentExceptionHandler != null -> {
                    parentExceptionHandler.handleException(coroutineContext, throwable)
                }
                else -> Log.e(TAG, "Work '$key' failed", throwable)
            }
        } catch (handlerError: Exception) {
            Log.e(TAG, "Error handler failed for work '$key'", handlerError)
            Log.e(TAG, "Original failure from work '$key'", throwable)
        }
    }

    /**
     * 提交普通任务
     * @param key 任务唯一标识
     * @param replaceRunning 如果该 Key 的任务正在运行，是否中断并替换
     * @param timeoutMillis 任务开始执行后的超时时间；null 表示不超时
     */
    fun post(
        key: String = UUID.randomUUID().toString(),
        replaceRunning: Boolean = false,
        timeoutMillis: Long? = null,
        block: suspend () -> Unit
    ): String = wrapAndEnqueue(
        key = key,
        isFirst = false,
        replaceRunning = replaceRunning,
        timeoutMillis = timeoutMillis,
        block = block
    )

    /**
     * 提交高优先级任务（插入队首）
     * @param timeoutMillis 任务开始执行后的超时时间；null 表示不超时
     */
    fun postFirst(
        key: String = UUID.randomUUID().toString(),
        replaceRunning: Boolean = false,
        timeoutMillis: Long? = null,
        block: suspend () -> Unit
    ): String = wrapAndEnqueue(
        key = key,
        isFirst = true,
        replaceRunning = replaceRunning,
        timeoutMillis = timeoutMillis,
        block = block
    )

    /**
     * 提交异步任务（需手动调用 WorkDone）
     * @param timeoutMillis 任务开始执行后的超时时间；null 表示不超时
     */
    fun postAsync(
        key: String = UUID.randomUUID().toString(),
        replaceRunning: Boolean = false,
        timeoutMillis: Long? = null,
        block: suspend WorkScope.() -> Unit
    ): String = wrapAndEnqueue(
        key = key,
        isFirst = false,
        isAsync = true,
        replaceRunning = replaceRunning,
        timeoutMillis = timeoutMillis,
        asyncBlock = block
    )

    private fun wrapAndEnqueue(
        key: String,
        isFirst: Boolean,
        isAsync: Boolean = false,
        replaceRunning: Boolean = false,
        timeoutMillis: Long? = null,
        block: (suspend () -> Unit)? = null,
        asyncBlock: (suspend WorkScope.() -> Unit)? = null
    ): String {
        require(timeoutMillis == null || timeoutMillis > 0) {
            "timeoutMillis must be greater than 0"
        }

        val executeWork: suspend () -> Unit = {
            if (isAsync) {
                val deferred = CompletableDeferred<Unit>()
                val workScope = object : WorkScope {
                    override fun workDone() {
                        if (deferred.isActive) deferred.complete(Unit)
                    }
                }
                asyncBlock?.invoke(workScope)
                deferred.await()
            } else {
                block?.invoke()
            }
        }

        val workLogic: suspend () -> Unit = {
            if (timeoutMillis == null) {
                executeWork()
            } else {
                withTimeout(timeoutMillis.milliseconds) { executeWork() }
            }
        }

        val newHandle = WorkHandle(key, workLogic)
        var queueChanged = false
        var runningJobToCancel: Job? = null

        synchronized(lock) {
            check(!stopped && workJob.isActive) { "WorkFlow is not active" }

            //检查是否正在运行
            if (currentHandle?.key == key) {
                if (replaceRunning) {
                    queue.removeAll { it.key == key }
                    queue.addFirst(newHandle)
                    runningJobToCancel = currentJob
                    queueChanged = true
                }
                //如果replaceRunning为false忽略任务
            } else {
                //检查是否在队列中排队，如果是则替换
                queue.removeAll { it.key == key }
                if (isFirst) queue.addFirst(newHandle) else queue.addLast(newHandle)
                queueChanged = true
            }
        }

        runningJobToCancel?.cancel()
        if (queueChanged) signal.trySend(Unit)
        return key
    }

    fun hasWork(key: String): Boolean = synchronized(lock) {
        currentHandle?.key == key || queue.any { it.key == key }
    }

    fun isWorkRunning(key: String): Boolean = synchronized(lock) {
        currentHandle?.key == key
    }

    fun getAllWork(): List<String> = synchronized(lock) {
        val keys = mutableListOf<String>()
        currentHandle?.let { keys.add(it.key) }
        keys.addAll(queue.map { it.key })
        keys
    }

    fun getRunningWork(): String? = synchronized(lock) { currentHandle?.key }

    /**
     * 移除任务
     * @param key 任务标识
     * @param cancelIfRunning 如果任务正在运行，是否取消
     */
    fun remove(key: String, cancelIfRunning: Boolean = true) {
        val runningJobToCancel = synchronized(lock) {
            queue.removeAll { it.key == key }
            if (cancelIfRunning && currentHandle?.key == key) {
                currentJob
            } else {
                null
            }
        }
        runningJobToCancel?.cancel()
    }

    fun stop() {
        val shouldStop = synchronized(lock) {
            if (stopped) {
                false
            } else {
                stopped = true
                queue.clear()
                true
            }
        }
        if (!shouldStop) return

        signal.close()
        workJob.cancel()
    }

    interface WorkScope {
        fun workDone()
    }

    class WorkHandle(val key: String, val work: suspend () -> Unit)

    private class RunningWork(val handle: WorkHandle, val job: Job)

    private companion object {
        const val TAG = "WorkFlow"
    }
}
