package com.candy.kit.ext

import com.candy.kit.utils.RegexPool

/**
 * 验证字符串是否为合法的邮箱地址
 */
fun String?.isEmail(): Boolean = this?.let { RegexPool.email.matches(it) } ?: false

/**
 * 验证字符串是否为合法的 http/https 链接
 */
fun String?.isHttpUrl(): Boolean = this?.let { RegexPool.http.matches(it) } ?: false

/**
 * 验证字符串是否全部由汉字组成
 */
fun String?.isChinese(): Boolean = this?.let { RegexPool.chinese.matches(it) } ?: false

/**
 * 验证字符串是否全部由数字组成
 */
fun String?.isNumeric(): Boolean = this?.let { RegexPool.numeric.matches(it) } ?: false

/**
 * 验证字符串是否全部由英文字母组成
 */
fun String?.isAlphabetic(): Boolean = this?.let { RegexPool.alphabetic.matches(it) } ?: false

/**
 * 验证字符串是否为合法的 IPv4 地址
 */
fun String?.isIPv4(): Boolean = this?.let { RegexPool.ipv4.matches(it) } ?: false

/**
 * 验证字符串是否为合法的域名格式
 */
fun String?.isDomain(): Boolean = this?.let { RegexPool.domain.matches(it) } ?: false

/**
 * 验证字符串是否为合法的中国手机号
 */
fun String?.isMobileChina(): Boolean = this?.let { RegexPool.mobileChina.matches(it) } ?: false

/**
 * 验证字符串是否为合法的中国身份证号
 */
fun String?.isIdCardChina(): Boolean = this?.let { RegexPool.idCardChina.matches(it) } ?: false

/**
 * 验证字符串是否为强密码 (8-16位且同时包含大小写字母+数字)
 */
fun String?.isStrongPassword(): Boolean =
    this?.let { RegexPool.strongPassword.matches(it) } ?: false

/**
 * 验证字符串是否为 16 进制颜色值 (如 #FFFFFF)
 */
fun String?.isHexColor(): Boolean = this?.let { RegexPool.hexColor.matches(it) } ?: false

/**
 * 验证字符串是否为合法 MAC 地址
 */
fun String?.isMacAddress(): Boolean = this?.let { RegexPool.macAddress.matches(it) } ?: false

/**
 * 验证字符串是否为 Base64 编码格式
 */
fun String?.isBase64(): Boolean = this?.let { RegexPool.base64.matches(it) } ?: false

/**
 * 验证字符串是否包含空格
 */
fun String?.hasSpace(): Boolean = this?.contains(" ") ?: false