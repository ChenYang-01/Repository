package com.candy.kit.network

sealed interface NetworkType {
    data class Wifi(val ssid: String?) : NetworkType
    sealed interface Cellular : NetworkType {
        data object C2G : Cellular
        data object C3G : Cellular
        data object C4G : Cellular
        data object C5G : Cellular
        data object Unknown : Cellular
    }

    data object Ethernet : NetworkType
    data object None : NetworkType
}