package com.candy.kit.ext

fun Collection<*>?.sizeOrElse(size: Int): Int {
    return this?.size ?: size
}

fun Collection<*>?.sizeOrElse(size: () -> Int): Int {
    return this?.size ?: size()
}

fun <T> List<T>.getInRange(index: Int): T {
    return get(index.coerceIn(indices))
}