package com.candy.kit.log.tree

import android.util.Log
import com.candy.kit.log.Logger
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

abstract class Tree {

    open var tag: String = "Logger"

    open fun v(message: Any?, vararg args: Any?, tag: () -> String = { this.tag }) {
        formatLog(priority = Log.VERBOSE, tag = tag(), message = message, args = args)
    }

    open fun d(message: Any?, vararg args: Any?, tag: () -> String = { this.tag }) {
        formatLog(priority = Log.DEBUG, tag = tag(), message = message, args = args)
    }

    open fun i(message: Any?, vararg args: Any?, tag: () -> String = { this.tag }) {
        formatLog(priority = Log.INFO, tag = tag(), message = message, args = args)
    }

    open fun w(message: Any?, vararg args: Any?, tag: () -> String = { this.tag }) {
        formatLog(priority = Log.WARN, tag = tag(), message = message, args = args)
    }

    open fun e(message: Any?, vararg args: Any?, tag: () -> String = { this.tag }) {
        formatLog(priority = Log.ERROR, tag = tag(), message = message, args = args)
    }

    open fun wtf(message: Any?, vararg args: Any?, tag: () -> String = { this.tag }) {
        formatLog(priority = Log.ASSERT, tag = tag(), message = message, args = args)
    }

    protected open fun formatLog(priority: Int, tag: String, message: Any?, vararg args: Any?) {
        if (message is String) {
            var newMessage: String = message
            args.forEach {
                newMessage = newMessage.replaceFirst(Regex("%[sdf]"), it.parseToString())
            }
            print(priority = priority, tag = tag, message = newMessage, findCaller())
        } else {
            val newMessage = message.parseToString() + args.joinToString("") { it.parseToString() }
            print(priority = priority, tag = tag, message = newMessage, findCaller())
        }
    }

    abstract fun print(
        priority: Int,
        tag: String,
        message: String?,
        stackTrace: StackTraceElement?
    )

    protected open fun Any?.parseToString(): String {
        return when (this) {
            is String -> parseString(this)
            is Array<*> -> joinToString(prefix = "[", postfix = "]") { it.parseToString() }
            is IntArray -> contentToString()
            is FloatArray -> contentToString()
            is DoubleArray -> contentToString()
            is LongArray -> contentToString()
            is ShortArray -> contentToString()
            is ByteArray -> contentToString()
            is CharArray -> contentToString()
            is Throwable -> Log.getStackTraceString(this)
            is List<*> -> this.joinToString(prefix = "[", postfix = "]") { it.parseToString() }
            is Map<*, *> -> this.entries.joinToString(prefix = "{", postfix = "}") {
                "\"${it.key}\":\"${it.value?.parseToString() ?: "null"}\""
            }
            else -> this.toString()
        }
    }

    /**
     * 解析String，判断是否是json格式
     * @param content String
     * @return String
     */
    protected open fun parseString(content: String): String {
        return when {
            content.startsWith("{") && content.endsWith("}") -> {
                try {
                    JSONObject(content).toString(2)
                } catch (e: Exception) {
                    e.printStackTrace()
                    content
                }
            }

            content.startsWith("[") && content.endsWith("]") -> {
                try {
                    JSONArray(content).toString(2)
                } catch (e: Exception) {
                    e.printStackTrace()
                    content
                }
            }

            else -> content
        }
    }


    protected fun findCaller(): StackTraceElement {
        val stackTrace = Throwable().stackTrace

        return stackTrace.firstOrNull { !isLogFrameworkClass(it.className) } ?: stackTrace[0]
    }

    companion object {
        private val treeClassCache = ConcurrentHashMap<String, Boolean>()

        internal fun isLogFrameworkClass(className: String): Boolean {
            if (className == Logger::class.java.name) return true

            return treeClassCache.getOrPut(className) {
                runCatching {
                    val classLoader = Thread.currentThread().contextClassLoader
                                      ?: Tree::class.java.classLoader
                    val clazz = Class.forName(className, false, classLoader)
                    Tree::class.java.isAssignableFrom(clazz)
                }.getOrDefault(false)
            }
        }
    }
}
