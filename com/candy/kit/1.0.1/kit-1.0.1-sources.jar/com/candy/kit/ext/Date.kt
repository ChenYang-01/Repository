package com.candy.kit.ext

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.GregorianCalendar
import java.util.Locale

/**
 * 这个日期的年份：如2026
 */
val Date.curYear: Int
    get() {
        val calendar = Calendar.getInstance()
        calendar.time = this
        return calendar[Calendar.YEAR]
    }

/**
 * 这个日期的月份：如4
 */
val Date.curMonth: Int
    get() {
        val calendar = Calendar.getInstance()
        calendar.time = this
        return calendar[Calendar.MONTH] + 1
    }

/**
 * 这个日期的月份的日：如1
 */
val Date.dayOfMonth: Int
    get() {
        val calendar = Calendar.getInstance()
        calendar.time = this
        return calendar[Calendar.DATE]
    }

/**
 * 这个日期是他所在周的第几天：如星期五就是第6天
 */
val Date.week: Int
    get() {
        val calendar = Calendar.getInstance()
        calendar.time = this
        return calendar[Calendar.DAY_OF_WEEK]
    }

/**
 * 周的缩写：如周五
 */
val Date.simpleWeek: String
    get() = SimpleDateFormat("E", Locale.getDefault()).format(this)

/**
 * 周的全写：如星期五
 */
val Date.fullWeek: String
    get() = SimpleDateFormat("EEEE", Locale.getDefault()).format(this)

/**
 * 这个日期是否是今天
 */
val Date.isToday: Boolean
    get() {
        val today = Calendar.getInstance()
        val target = Calendar.getInstance().apply { time = this@isToday }
        return today[Calendar.ERA] == target[Calendar.ERA] &&
            today[Calendar.YEAR] == target[Calendar.YEAR] &&
            today[Calendar.DAY_OF_YEAR] == target[Calendar.DAY_OF_YEAR]
    }

/**
 * 这个日期是否是闰年
 */
val Date.isLeapYear: Boolean
    get() {
        val cal = Calendar.getInstance()
        cal.time = this
        val year = cal[Calendar.YEAR]
        return year % 4 == 0 && year % 100 != 0 || year % 400 == 0
    }

/**
 * 这个日期是否是上午
 */
val Date.isAm: Boolean
    get() {
        val calendar = Calendar.getInstance()
        calendar.time = this
        return calendar.get(GregorianCalendar.AM_PM) == 0
    }

fun Date.format(pattern: String): String {
    return SimpleDateFormat(pattern, Locale.getDefault()).format(this)
}

fun String.toDate(pattern: String): Date {
    return SimpleDateFormat(pattern, Locale.getDefault()).parse(this)!!
}

fun Long.toDate(): Date = Date(this)
