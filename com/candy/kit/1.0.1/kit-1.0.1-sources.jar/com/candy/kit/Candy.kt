package com.candy.kit

import android.app.Application

object Candy {
    internal lateinit var app: Application

    fun init(app: Application) {
        this.app = app
        ActivityStack.init(app)
    }
}