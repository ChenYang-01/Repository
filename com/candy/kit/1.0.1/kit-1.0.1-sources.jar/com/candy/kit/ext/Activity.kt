package com.candy.kit.ext

import android.app.Activity
import android.widget.FrameLayout

val Activity.contentView: FrameLayout
    get() = findViewById(android.R.id.content)

val Activity.decorView: FrameLayout
    get() = window.decorView.cast()