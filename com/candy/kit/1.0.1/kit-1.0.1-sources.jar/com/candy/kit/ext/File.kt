package com.candy.kit.ext

import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import com.candy.kit.Candy
import java.io.File
import java.io.FileInputStream
import java.util.Locale

val File.mimeType: String?
    get() = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)

fun File.save2Album(albumName: String? = null): Uri? {
    val mimeType = this.mimeType ?: ""
    return when {
        mimeType.startsWith("image/") -> saveImage2Album(albumName)
        mimeType.startsWith("video/") -> saveVideo2Album(albumName)
        mimeType.startsWith("audio/") -> saveAudio2Album(albumName)
        else -> {
            null
        }
    }
}

/**
 * 保存图片到相册
 */
fun File.saveImage2Album(albumName: String? = null): Uri? =
    saveMedia(this, "image/", MediaStore.Images.Media.EXTERNAL_CONTENT_URI, albumName)

/**
 * 保存视频到相册
 */
fun File.saveVideo2Album(albumName: String? = null): Uri? =
    saveMedia(this, "video/", MediaStore.Video.Media.EXTERNAL_CONTENT_URI, albumName)

/**
 * 保存音频到媒体库
 */
fun File.saveAudio2Album(albumName: String? = null): Uri? =
    saveMedia(this, "audio/", MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, albumName)

/**
 * 核心保存逻辑
 */
private fun saveMedia(
    sourceFile: File,
    mimeTypePrefix: String,
    collectionUri: Uri,
    albumName: String?
): Uri? {
    if (!sourceFile.exists()) return null

    //解析元数据（处理无后缀情况）
    val (finalFileName, finalMimeType) = resolveMetadata(sourceFile, mimeTypePrefix)
    val resolver = Candy.app.contentResolver

    //构建 ContentValues
    val contentValues = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, finalFileName)
        put(MediaStore.MediaColumns.MIME_TYPE, finalMimeType)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val baseDir = when (collectionUri) {
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI -> Environment.DIRECTORY_PICTURES
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI -> Environment.DIRECTORY_MOVIES
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI -> Environment.DIRECTORY_MUSIC
                else -> Environment.DIRECTORY_DOWNLOADS
            }
            val relativePath = if (albumName.isNullOrBlank()) baseDir else "$baseDir/$albumName"
            put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
    }

    //插入数据库并写入文件
    val uri = resolver.insert(collectionUri, contentValues) ?: return null

    return runCatching {
        resolver.openOutputStream(uri)?.use { outputStream ->
            FileInputStream(sourceFile).use { inputStream ->
                inputStream.copyTo(outputStream)
            }
        } ?: throw Exception("Failed to open output stream")

        // 释放 Pending 状态
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            contentValues.clear()
            contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, contentValues, null, null)
        }
        uri
    }.onFailure {
        resolver.delete(uri, null, null)
    }.getOrNull()
}

/**
 * 解析文件的最终名称和 MIME 类型
 * 如果文件没有后缀，则根据前缀补全默认后缀
 */
private fun resolveMetadata(file: File, mimeTypePrefix: String): Pair<String, String> {
    val extension = file.extension.lowercase(Locale.getDefault())
    val nameWithoutExtension = file.nameWithoutExtension

    // 如果有后缀，直接获取 MIME
    if (extension.isNotEmpty()) {
        val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
        if (mimeType != null) {
            return Pair(file.name, mimeType)
        }
    }

    // 如果无后缀或无法识别后缀，根据前缀补全
    return when {
        mimeTypePrefix.startsWith("image") -> Pair("$nameWithoutExtension.jpg", "image/png")
        mimeTypePrefix.startsWith("video") -> Pair("$nameWithoutExtension.mp4", "video/mp4")
        mimeTypePrefix.startsWith("audio") -> Pair("$nameWithoutExtension.mp3", "audio/mpeg")
        else -> Pair(file.name, "${mimeTypePrefix}*")
    }
}