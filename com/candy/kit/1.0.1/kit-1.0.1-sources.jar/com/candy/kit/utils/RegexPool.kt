package com.candy.kit.utils

object RegexPool {

    //##############################校验正则###################################
    /** 邮箱正则：支持标准邮箱格式 */
    val email by lazy { Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$") }

    /** HTTP/HTTPS 正则：匹配以 http:// 或 https:// 开头的标准网址 */
    val http by lazy {
        Regex(
            "^https?://[\\w\\-_]+(\\.[\\w\\-_]+)+([\\w\\-.,@?^=%&:/~+#]*[\\w\\-@?^=%&/~+#])?$"
        )
    }

    /** 汉字正则：匹配纯中文字符 */
    val chinese by lazy { Regex("^[\\u4e00-\\u9fa5]+$") }

    /** 数字正则：匹配纯阿拉伯数字 */
    val numeric by lazy { Regex("^[0-9]+$") }

    /** 字母正则：匹配纯英文字母（不分大小写） */
    val alphabetic by lazy { Regex("^[a-zA-Z]+$") }

    /** IPv4 正则：匹配标准 IPv4 地址格式 */
    val ipv4 by lazy {
        Regex(
            "^((25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d\\d?)$"
        )
    }

    /** 域名正则：匹配标准域名格式（如 example.com） */
    val domain by lazy {
        Regex(
            "^(?=^.{3,255}$)[a-zA-Z0-9][-a-zA-Z0-9]{0,62}(\\.[a-zA-Z0-9][-a-zA-Z0-9]{0,62})+$"
        )
    }

    /** 中国手机号：以1开头，第二位3-9，总11位 */
    val mobileChina by lazy { Regex("^1[3-9]\\d{9}$") }

    /** 中国身份证号：简单匹配15位或18位，18位末尾可以是X */
    val idCardChina by lazy { Regex("(^\\d{15}$)|(^\\d{18}$)|(^\\d{17}(\\d|X|x)$)") }

    /** 强密码：必须包含大小写字母和数字，长度8-16位 */
    val strongPassword by lazy { Regex("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,16}$") }

    /** 16进制颜色值：支持 #FFF 或 #FFFFFF */
    val hexColor by lazy { Regex("^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$") }

    /** MAC 地址：匹配标准 MAC 格式（支持冒号和连字符） */
    val macAddress by lazy { Regex("^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$") }

    /** Base64 编码格式：验证是否为合法的 Base64 字符串 */
    val base64 by lazy { Regex("^([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{2}==)?$") }

    //##############################提取正则###################################
    /** 数字正则 */
    val extractNumeric by lazy { Regex("\\d+") }

    /** 数值正则 (包含负号和小数点) */
    val extractDigits by lazy { Regex("-?(\\d*\\.\\d+|\\d+\\.?\\d*)") }

    /** 提取所有非数字序列 (排除 0-9) */
    val extractNonNumeric by lazy { Regex("[^0-9]+") }

    /** 提取所有非数值序列 (排除 0-9、负号、小数点) */
    val extractNonDigits by lazy { Regex("[^0-9\\-.]+") }

    /** 汉字正则 */
    val extractChinese by lazy { Regex("[\\u4e00-\\u9fa5]+") }

    /** 字母正则 */
    val extractAlphabetic by lazy { Regex("[a-zA-Z]+") }

    /** 匹配末尾多余 0 的正则：用于处理小数点后多余的 0 或直接去掉小数点 */
    val trailingZeros by lazy { Regex("(\\.\\d*?[1-9])0+$|\\.0*$") }
}