package com.candy.kit

import android.app.Activity
import android.app.Application
import android.os.Bundle
import androidx.annotation.MainThread
import com.candy.kit.ext.cast
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Activity栈管理
 * @author: ChenYang
 * @date: 2023-02-23 22:35
 */
object ActivityStack {

    private val stack = CopyOnWriteArrayList<Activity>()

    @Volatile
    private var initialized = false

    private val _isForeground = MutableStateFlow(false)
    val isForeground = _isForeground.asStateFlow()

    private val _top = MutableStateFlow<Activity?>(null)
    val top = _top.asStateFlow()

    val appStatus = combine(_isForeground, _top) { fog, top -> AppStatus(fog, top) }

    val all: List<Activity>
        get() = stack

    fun init(app: Application) {
        if (initialized) return

        synchronized(this) {
            if (initialized) return
            app.registerActivityLifecycleCallbacks(Callbacks())
            initialized = true
        }
    }

    /**
     * Activity是否已经在App中打开，即是否已经加入到栈中
     * @param activity Activity
     * @return Boolean
     */
    fun isLaunch(activity: Activity?): Boolean {
        return stack.contains(activity)
    }

    /**
     * Activity是否已经在App中打开，即是否已经加入到栈中
     * @param clazz Class<Activity>
     * @return Boolean
     */
    fun isLaunch(clazz: Class<out Activity>): Boolean {
        return indexOf(clazz) >= 0
    }

    /**
     * 关闭Activity
     * @param clazz Class<Activity>
     */
    @MainThread
    fun finish(clazz: Class<out Activity>) {
        getActivity(clazz)?.finish()
    }

    /**
     * 关闭栈中的所有Activity
     * @param fromBottom 是否栈底开始关闭；true：从栈底开始，false：从栈顶开始
     */
    @MainThread
    fun finishAll(fromBottom: Boolean = true) {
        if (fromBottom) {
            stack.forEach { it.finish() }
        } else {
            stack.reversed().forEach { it.finish() }
        }
    }

    /**
     * 根据[clazz]获取对应的Activity，如果栈中不存在则返回null
     * @param clazz Class<Activity>
     * @return Activity?
     */
    fun <T : Activity> getActivity(clazz: Class<out T>): T? {
        val index = indexOf(clazz)
        if (index < 0) return null
        return stack[index].cast()
    }

    /**
     * 获取Activity在栈中的索引，从栈底开始计数，如果Activity不在栈中，返回-1
     * @param activity Activity
     * @return Int
     */
    fun indexOf(activity: Activity): Int {
        return stack.indexOfFirst { it == activity }
    }

    /**
     * 获取Activity在栈中的索引，从栈底开始计数，如果Activity不在栈中，返回-1
     * @param clazz Class<out Activity>
     * @return Int
     */
    fun indexOf(clazz: Class<out Activity>): Int {
        return stack.indexOfFirst { it.javaClass == clazz }
    }

    private class Callbacks : Application.ActivityLifecycleCallbacks {

        private var activityCount = 0

        override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
            stack.add(activity)
        }

        override fun onActivityStarted(activity: Activity) {
            activityCount++
            if (activityCount == 1) {
                _isForeground.value = true
            }
        }

        override fun onActivityResumed(activity: Activity) {
            _top.value = activity
        }

        override fun onActivityPaused(activity: Activity) {
        }

        override fun onActivityStopped(activity: Activity) {
            activityCount--
            activityCount = activityCount.coerceAtLeast(0)
            if (activityCount == 0) {
                _isForeground.value = false
            }
        }

        override fun onActivityDestroyed(activity: Activity) {
            stack.remove(activity)
            if (_top.value === activity) {
                _top.value = null
            }
        }

        override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    }

    data class AppStatus(val isForeground: Boolean, val topActivity: Activity?)
}
