package com.candy.kit.ext

import android.app.Activity
import android.content.Context
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.postDelayed
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

val Activity.keyboardState: Flow<KeyboardState>
    get() = decorView.keyboardState

val View.keyboardState: Flow<KeyboardState>
    get() = callbackFlow {

        val rootView = this@keyboardState

        var lastState: KeyboardState? = null

        ViewCompat.setOnApplyWindowInsetsListener(rootView) { _, insets ->

            val visible = insets.isVisible(WindowInsetsCompat.Type.ime())
            val height = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom

            val newState = KeyboardState(visible, height)

            if (newState != lastState) {
                lastState = newState
                trySend(newState)
            }

            insets
        }

        awaitClose {
            ViewCompat.setOnApplyWindowInsetsListener(rootView, null)
        }
    }

fun Activity.showKeyboard() {
    WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.ime())
}

fun View.showKeyboard() {
    context.activity?.window?.let {
        this.requestFocus()
        val controller = WindowInsetsControllerCompat(it, this)
        controller.show(WindowInsetsCompat.Type.ime())
    }
}

fun View.showKeyboard(delay: Long) {
    postDelayed(delay) { showKeyboard() }
}

fun Activity.hideKeyboard() {
    WindowInsetsControllerCompat(window, window.decorView).hide(WindowInsetsCompat.Type.ime())
}

fun View.hideKeyboard() {
    context.activity?.window?.let {
        val controller = WindowInsetsControllerCompat(it, this)
        controller.hide(WindowInsetsCompat.Type.ime())
    }
}

fun Context.toggleKeyboard() {
    val imm = getSystemService(InputMethodManager::class.java)
    imm?.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0)
}

data class KeyboardState(val isVisible: Boolean, val height: Int)