package com.candy.kit

import android.util.Log
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.candy.kit.ext.cast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.ConcurrentHashMap
import kotlin.time.Duration.Companion.milliseconds

object FlowBus {

    private val registry by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        FlowBusRegistry(ProcessLifecycleOwner.get().lifecycleScope)
    }

    fun <T> with(key: String, isSticky: Boolean = false): MutableSharedFlow<T> {
        return registry.with(key, isSticky)
    }

    /**
     * 清除指定 Key 的事件流和粘性缓存。已持有旧 Flow 的收集器不会被取消。
     */
    fun clear(key: String): Boolean = registry.clear(key)

    inline fun <reified T : Any> post(event: T, isSticky: Boolean = false) {
        with<T>(T::class.java.name, isSticky).tryEmit(event)
    }

    inline fun <reified T : Any> with(isSticky: Boolean = false): MutableSharedFlow<T> {
        return with(T::class.java.name, isSticky)
    }

    inline fun <reified T : Any> clear(): Boolean {
        return clear(T::class.java.name)
    }
}

internal class FlowBusRegistry(
    private val scope: CoroutineScope,
    private val cleanupDelayMillis: Long = 5000
) {

    private val bus = ConcurrentHashMap<String, Entry>()

    init {
        require(cleanupDelayMillis > 0) {
            "cleanupDelayMillis must be greater than 0"
        }
    }

    fun <T> with(key: String, isSticky: Boolean = false): MutableSharedFlow<T> {
        bus[key]?.let { entry ->
            logConfigMismatch(key, entry.isSticky, isSticky)
            return entry.flow.cast()
        }

        val newFlow = MutableSharedFlow<Any>(
            replay = if (isSticky) 1 else 0,
            extraBufferCapacity = 64,
            onBufferOverflow = BufferOverflow.DROP_OLDEST
        )
        val newEntry = Entry(newFlow, isSticky)
        val existingEntry = bus.putIfAbsent(key, newEntry)
        val entry = existingEntry ?: newEntry.also {
            if (!isSticky) startAutoCleanup(key, it)
        }
        if (existingEntry != null) {
            logConfigMismatch(key, existingEntry.isSticky, isSticky)
        }
        return entry.flow.cast()
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    fun clear(key: String): Boolean {
        val entry = bus.remove(key) ?: return false
        entry.cleanupJob?.cancel()
        if (entry.isSticky) entry.flow.resetReplayCache()
        return true
    }

    /**
     * 当订阅者持续为空达到清理延迟后移除条目。清理任务只属于实际写入 Map 的 Flow，
     * 并在条目移除或被替换后结束，避免进程生命周期内持续持有废弃 Flow。
     */
    private fun startAutoCleanup(key: String, entry: Entry) {
        val cleanupJob = scope.launch(start = CoroutineStart.LAZY) {
            while (bus[key] === entry) {
                entry.flow.subscriptionCount.first { it == 0 }
                val becameActive = withTimeoutOrNull(cleanupDelayMillis.milliseconds) {
                    entry.flow.subscriptionCount.first { it > 0 }
                    true
                } ?: false

                if (becameActive) continue
                if (entry.flow.subscriptionCount.value == 0) {
                    bus.remove(key, entry)
                    return@launch
                }
            }
        }
        entry.cleanupJob = cleanupJob
        if (bus[key] === entry) cleanupJob.start() else cleanupJob.cancel()
    }

    private fun logConfigMismatch(
        key: String,
        existingIsSticky: Boolean,
        requestedIsSticky: Boolean
    ) {
        if (existingIsSticky == requestedIsSticky) return
        Log.e(
            TAG,
            "Key '$key' already uses isSticky=$existingIsSticky; " +
            "requested isSticky=$requestedIsSticky was ignored"
        )
    }

    private class Entry(
        val flow: MutableSharedFlow<Any>,
        val isSticky: Boolean
    ) {
        @Volatile
        var cleanupJob: Job? = null
    }

    private companion object {
        const val TAG = "FlowBus"
    }
}
