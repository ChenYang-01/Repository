package com.candy.kit.utils

import android.util.Base64
import java.security.PrivateKey
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * 用于常见解码操作的工具
 *
 * 提供常用的数据解码与解密功能，包括：
 * 1. Base64 解码 (String/ByteArray)
 * 2. AES 对称解密 (支持自定义转换模式与 IV)
 * 3. RSA 非对称解密 (使用私钥)
 *
 * @author MasterChan
 * @date 2026-04-06 21:25
 */
object Decryptor {

    fun base64(input: String, flags: Int = Base64.NO_WRAP): ByteArray {
        return Base64.decode(input, flags)
    }

    fun base64(input: ByteArray, flags: Int = Base64.NO_WRAP): ByteArray {
        return Base64.decode(input, flags)
    }

    fun base64String(input: String, flags: Int = Base64.NO_WRAP): String {
        return String(base64(input, flags))
    }

    fun aes(
        transformation: String = "AES/CBC/PKCS5Padding",
        iv: ByteArray = "0102030405060708".toByteArray(),
        key: ByteArray,
        data: String
    ): ByteArray {
        return decodeCipher(
            transformation,
            SecretKeySpec(key, "AES"),
            IvParameterSpec(iv),
            data.hexToByteArray()
        )
    }

    fun decodeCipher(
        transformation: String,
        keySpec: SecretKeySpec,
        ivSpec: IvParameterSpec?,
        data: ByteArray
    ): ByteArray {
        val cipher = Cipher.getInstance(transformation)
        if (ivSpec == null) {
            cipher.init(Cipher.DECRYPT_MODE, keySpec)
        } else {
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec)
        }
        return cipher.doFinal(data)
    }

    fun rsa(privateKey: PrivateKey, base64Data: String): ByteArray {
        val cipher = Cipher.getInstance("RSA")
        cipher.init(Cipher.DECRYPT_MODE, privateKey)
        val data = Base64.decode(base64Data, Base64.NO_WRAP)
        return cipher.doFinal(data)
    }
}