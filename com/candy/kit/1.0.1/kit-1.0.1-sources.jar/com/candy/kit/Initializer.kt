package com.candy.kit

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 统一应用初始化管理器，用于在应用启动时按序执行各项初始化任务。
 *
 * 该工具支持：
 * 1. **依赖管理**：通过拓扑排序自动处理初始化任务之间的依赖关系，防止循环依赖。
 * 2. **分阶段执行**：支持同步 (Main) 和异步 (IO) 任务分发。
 * 3. **并发优化**：无依赖关系的独立任务将并行执行，有依赖链的任务按序串行，最大程度提升启动效率。
 *
 * @author: ChenYang
 * @date: 2026-04-06 19:31
 */
class Initializer {

    private val registry = mutableMapOf<String, Config>()
    val initializeState = MutableSharedFlow<InitializeState>()

    fun register(
        node: Node,
        name: String = node.javaClass.name,
        stage: Stage = Stage.SYNC,
        dependencies: List<String> = emptyList()
    ) = apply {
        if (registry.containsKey(name)) {
            throw IllegalArgumentException("Initializer name:$name already registered")
        }
        registry[name] = Config(node, name, stage, dependencies)
    }

    fun register(
        name: String,
        stage: Stage = Stage.SYNC,
        dependencies: List<String> = emptyList(),
        node: () -> Node,
    ) = apply {
        if (registry.containsKey(name)) {
            throw IllegalArgumentException("Initializer name:$name already registered")
        }
        registry[name] = Config(node(), name, stage, dependencies)
    }

    suspend fun init(context: Context) {
        Log.i("Initializer", "==================Initializer Start==================")
        initializeState.emit(InitializeState.Start)
        coroutineScope {
            val (groupA, groupB) = generateGroupsWithTopo(registry.values.toList())
            groupA.forEach {
                launch(it.stage.dispatchers) {
                    initializeState.emit(InitializeState.NodeStart(it.name))
                    it.node.init(context)
                    initializeState.emit(InitializeState.NodeEnd(it.name))
                    Log.i("Initializer", "‖ ${it.name}")
                }
            }
            groupB.forEach { configs ->
                launch {
                    configs.forEach { cfg ->
                        withContext(cfg.stage.dispatchers) {
                            initializeState.emit(InitializeState.NodeStart(cfg.name))
                            cfg.node.init(context)
                            initializeState.emit(InitializeState.NodeEnd(cfg.name))
                            Log.i(
                                "Initializer", "‖ ${cfg.name} ->${cfg.dependencies.joinToString()}"
                            )
                        }
                    }
                }
            }
        }
        initializeState.emit(InitializeState.End)
        Log.i("Initializer", "==================Initializer End==================")
    }

    private fun generateGroupsWithTopo(list: List<Config>): Pair<List<Config>, List<List<Config>>> {
        val map = list.associateBy { it.name }

        list.forEach { config ->
            val missingDependencies = config.dependencies.filterNot(map::containsKey)
            check(missingDependencies.isEmpty()) {
                "Initializer name:${config.name} has unregistered dependencies: " +
                    missingDependencies.joinToString()
            }
        }

        // 谁依赖我
        val reverseDeps = mutableMapOf<String, MutableList<String>>()
        list.forEach { cfg ->
            cfg.dependencies.forEach { dep ->
                reverseDeps.getOrPut(dep) { mutableListOf() }.add(cfg.name)
            }
        }

        val assigned = mutableSetOf<String>()

        // 组 A: 完全独立
        val groupA = list.filter { it.dependencies.isEmpty() && reverseDeps[it.name].isNullOrEmpty() }
        assigned.addAll(groupA.map { it.name })

        // 组 B: 每个依赖子图形成一个 list
        val groupsB = mutableListOf<List<Config>>()

        list.forEach { cfg ->
            if (assigned.contains(cfg.name)) return@forEach

            val chainSet = mutableSetOf<String>()

            // DFS 向上和向下遍历，收集完整依赖子图
            fun dfs(node: Config) {
                if (chainSet.contains(node.name)) return
                chainSet.add(node.name)
                node.dependencies.forEach { dep -> map[dep]?.let { dfs(it) } }
                reverseDeps[node.name]?.forEach { depBy -> map[depBy]?.let { dfs(it) } }
            }

            dfs(cfg)

            // 子图拓扑排序
            val chainList = topologicalSort(chainSet.map { map[it]!! })
            groupsB.add(chainList)
            assigned.addAll(chainSet)
        }

        return Pair(topologicalSort(groupA), groupsB)
    }

    // 组内拓扑排序
    private fun topologicalSort(list: List<Config>): List<Config> {
        val result = mutableListOf<Config>()
        val visited = mutableSetOf<String>()
        val visiting = mutableSetOf<String>()
        val map = list.associateBy { it.name }

        fun dfs(node: Config) {
            if (visited.contains(node.name)) return
            if (visiting.contains(node.name)) {
                throw IllegalStateException("Initializer name:${node.name} has Circular dependency")
            }
            visiting.add(node.name)
            node.dependencies.forEach { dep -> map[dep]?.let { dfs(it) } }
            visiting.remove(node.name)
            visited.add(node.name)
            result.add(node)
        }

        list.forEach { dfs(it) }
        return result
    }

    private val Stage.dispatchers: CoroutineDispatcher
        get() = if (this == Stage.SYNC) Dispatchers.Main else Dispatchers.IO

    data class Config(
        /**
         * 初始化节点实现
         */
        val node: Node,
        /**
         * 节点名称
         */
        val name: String,
        /**
         * 初始化时使用的协程上下文
         */
        val stage: Stage = Stage.SYNC,
        /**
         * 依赖的[Node]，需要在他们之后完成初始化
         */
        val dependencies: List<String> = emptyList()
    )

    enum class Stage {
        SYNC,
        ASYNC
    }

    interface Node {
        suspend fun init(context: Context)
    }

    sealed interface InitializeState {
        data object Start : InitializeState
        data class NodeStart(val name: String) : InitializeState
        data class NodeEnd(val name: String) : InitializeState
        data object End : InitializeState
    }
}
