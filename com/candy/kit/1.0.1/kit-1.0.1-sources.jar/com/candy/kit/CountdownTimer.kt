package com.candy.kit

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class CountdownTimer(private val scope: CoroutineScope) {
    private var timerJob: Job? = null

    private val _remainingTime = MutableStateFlow(0L)
    val remainingTime = _remainingTime.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning = _isRunning.asStateFlow()

    private var pauseOffset = 0L

    /**
     * 开始倒计时
     * @param millisInFuture 总毫秒数
     * @param countDownInterval 步进间隔
     * @param onFinish 结束回调
     */
    fun start(
        millisInFuture: Long,
        countDownInterval: Long = 1000L,
        onFinish: (() -> Unit)? = null
    ) {
        if (_isRunning.value) return
        stop()
        _remainingTime.value = millisInFuture
        runTimer(countDownInterval, onFinish)
    }

    private fun runTimer(interval: Long, onFinish: (() -> Unit)?) {
        timerJob?.cancel()
        timerJob = scope.launch {
            _isRunning.value = true

            // 记录开始时的系统时间
            val startTime = System.currentTimeMillis()
            // 目标结束时间 = 当前时间 + 剩余时间
            val targetEndTime = startTime + _remainingTime.value

            while (isActive && _remainingTime.value > 0) {
                // 计算距离下一次触发还需要 delay 多久
                // 这样可以抵消掉代码执行带来的微小耗时
                delay(interval)

                val now = System.currentTimeMillis()
                val remaining = targetEndTime - now

                if (remaining <= 0) {
                    _remainingTime.value = 0
                } else {
                    _remainingTime.value = remaining
                }
            }

            _isRunning.value = false
            if (_remainingTime.value == 0L) {
                onFinish?.invoke()
            }
        }
    }

    fun pause() {
        timerJob?.cancel()
        _isRunning.value = false
    }

    fun resume(countDownInterval: Long = 1000L, onFinish: (() -> Unit)? = null) {
        if (_isRunning.value || _remainingTime.value <= 0) return
        runTimer(countDownInterval, onFinish)
    }

    fun stop() {
        timerJob?.cancel()
        _remainingTime.value = 0
        _isRunning.value = false
    }

    fun release() {
        stop()
    }
}