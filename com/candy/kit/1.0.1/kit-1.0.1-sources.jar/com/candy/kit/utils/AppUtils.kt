package com.candy.kit.utils

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import androidx.annotation.RequiresPermission
import com.candy.kit.Candy

object AppUtils {

    fun getAppIcon(packageName: String): Drawable? {
        return try {
            val pm = Candy.app.packageManager
            pm.getPackageInfo(packageName, 0)?.applicationInfo?.loadIcon(pm)
        } catch (_: Exception) {
            null
        }
    }

    fun getAppName(packageName: String): String? {
        return try {
            val packageInfo = Candy.app.packageManager.getPackageInfo(packageName, 0)
            packageInfo?.applicationInfo?.loadLabel(Candy.app.packageManager)?.toString()
        } catch (_: Throwable) {
            null
        }
    }


    fun getAppVersionName(packageName: String): String? {
        return try {
            Candy.app.packageManager.getPackageInfo(packageName, 0)?.versionName
        } catch (_: Exception) {
            null
        }
    }

    fun getAppVersionCode(packageName: String): Long {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                Candy.app.packageManager.getPackageInfo(packageName, 0)?.longVersionCode ?: -1L
            } else {
                Candy.app.packageManager.getPackageInfo(packageName, 0)?.versionCode?.toLong()
                ?: -1L
            }
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
            -1
        }
    }

    /**
     * 判断应用是否安装，需要在AndroidManifest中添加<queries>
     */
    fun isInstallApk(packageName: String): Boolean {
        return try {
            Candy.app.packageManager.getApplicationInfo(packageName, 0).enabled
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * 安装应用，需要[Manifest.permission.REQUEST_INSTALL_PACKAGES]权限
     * @param uri Uri?
     */
    @RequiresPermission(Manifest.permission.REQUEST_INSTALL_PACKAGES)
    fun installApk(uri: Uri) {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.setDataAndType(uri, "application/vnd.android.package-archive")
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        Candy.app.startActivity(intent)
    }

    /**
     * 启动APP，需要在AndroidManifest中添加<queries>
     * @param packageName String
     */
    fun launchApp(packageName: String): Boolean {
        var intent = Intent(Intent.ACTION_MAIN, null)
        intent.addCategory(Intent.CATEGORY_LAUNCHER)
        intent.setPackage(packageName)
        val info = Candy.app.packageManager.queryIntentActivities(intent, 0)
        val launcherActivity = info.firstOrNull()?.activityInfo?.name
        if (launcherActivity.isNullOrEmpty()) {
            return false
        }
        intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_LAUNCHER)
        intent.setClassName(packageName, launcherActivity)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        Candy.app.startActivity(intent)
        return true
    }
}
