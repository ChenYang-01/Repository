package com.candy.kit.log.tree

import android.util.Log

/**
 * 简约日志打印策略，每条日志仅输出调用位置和消息。
 */
class SimpleTree : Tree() {

    override fun print(
        priority: Int,
        tag: String,
        message: String?,
        stackTrace: StackTraceElement?
    ) {
        val caller = stackTrace?.let {
            val className = it.className.substringAfterLast(".")
            "$className.${it.methodName}(${it.fileName}:${it.lineNumber})"
        }
        val content = if (caller == null) {
            message.orEmpty()
        } else {
            "$caller: ${message.orEmpty()}"
        }
        Log.println(priority, tag, content)
    }
}
