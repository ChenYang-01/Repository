package com.candy.kit

import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.widget.TextView
import android.widget.Toast
import com.candy.kit.ext.isMainThread
import com.candy.kit.log.Logger
import com.candy.kit.log.tree.Tree

object Toaster {

    private var toaster: Toast? = null

    private val handler = Handler(Looper.getMainLooper())

    var config = Config()

    fun show(text: String, config: (Config) -> Config = { it }) {
        doShow(text, Toast.LENGTH_SHORT, config(this.config.copy()))
    }

    fun showLong(text: String, config: (Config) -> Config = { it }) {
        doShow(text, Toast.LENGTH_LONG, config(this.config.copy()))
    }

    private fun doShow(text: String, duration: Int = Toast.LENGTH_SHORT, config: Config) {
        if (!isMainThread) {
            handler.post { doShow(text, duration, config) }
            return
        }

        toaster?.cancel()

        toaster = Toast.makeText(Candy.app, "", duration).apply {
            if (config.viewRes != 0) {
                this.view = LayoutInflater.from(Candy.app).inflate(config.viewRes, null).apply {
                    findViewById<TextView>(R.id.tv_toast_message).text = text
                }
            } else {
                setText(text)
            }
            this.duration = duration
            setGravity(config.gravity, config.xOffset, config.yOffset)
        }

        toaster?.show()
        if (Toaster.config.printLogger) {
            Logger.print(
                priority = Log.DEBUG,
                message = "Toaster->$text",
                tag = Logger.tag,
                stackTrace = findCaller()
            )
        }
    }

    data class Config(
        var gravity: Int = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL,
        var xOffset: Int = 0,
        var yOffset: Int = 200,
        var viewRes: Int = 0,
        var printLogger: Boolean = true,
        var stackTrace: StackTraceElement? = null
    )

    private fun findCaller(): StackTraceElement {
        val stackTrace = Throwable().stackTrace
        val toasterClassName = Toaster::class.java.name

        return stackTrace.firstOrNull {
            it.className != toasterClassName &&
            !it.className.startsWith("$toasterClassName$") &&
            !Tree.isLogFrameworkClass(it.className)
        } ?: stackTrace[0]
    }
}
