package com.candy.kit.log.tree

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedWriter
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStreamWriter
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.time.Duration.Companion.milliseconds

open class WriterTree(val config: Config) : Tree(), Closeable {

    init {
        require(config.logDir.isNotBlank()) { "logDir cannot be blank." }
        require(config.extension.isNotBlank()) { "extension cannot be blank." }
        require(config.extension.none { it == '/' || it == '\\' }) {
            "extension cannot contain path separators."
        }
        require(config.saveDays >= 0) { "saveDays must be greater than or equal to 0." }
        require(config.maxFileSizeBytes > 0) { "maxFileSizeBytes must be greater than 0." }
        require(config.maxTotalSizeBytes >= config.maxFileSizeBytes) {
            "maxTotalSizeBytes must be greater than or equal to maxFileSizeBytes."
        }
        require(config.queueCapacity > 0) { "queueCapacity must be greater than 0." }
        require(config.flushIntervalMillis > 0) {
            "flushIntervalMillis must be greater than 0."
        }
    }

    val droppedLogCount: Long
        get() = droppedLogs.get()

    private val directory = File(config.logDir)
    private val managedLogFileRegex =
        Regex("""^\d{8}(?:\.(\d+))?\.${Regex.escape(config.extension)}$""")
    private val commandChannel = Channel<Command>(config.queueCapacity)
    private val supervisorJob = SupervisorJob()
    private val scope = CoroutineScope(supervisorJob + Dispatchers.IO)
    private val lifecycleMutex = Mutex()
    private val enqueueLock = Any()
    private val droppedLogs = AtomicLong()

    @Volatile
    private var acceptingLogs = true

    private var writer: BufferedWriter? = null
    private var currentFile: File? = null
    private var currentDate: LocalDate? = null
    private var currentSegment = 0
    private var currentFileSizeBytes = 0L
    private var managedSizeBytes = 0L

    private val workerJob = scope.launch {
        runWriterLoop()
    }

    protected open fun currentDateTime(): LocalDateTime = LocalDateTime.now()

    protected fun obtainLogFile(): File {
        ensureLogDirectory()
        return logFile(currentDateTime().toLocalDate(), segment = 0)
    }

    override fun print(
        priority: Int,
        tag: String,
        message: String?,
        stackTrace: StackTraceElement?
    ) {
        val entry = LogEntry(
            timestamp = currentDateTime(),
            message = message.orEmpty()
        )
        val accepted = synchronized(enqueueLock) {
            acceptingLogs && commandChannel.trySend(Command.Write(entry)).isSuccess
        }
        if (!accepted) {
            droppedLogs.incrementAndGet()
        }
    }

    suspend fun flush() {
        lifecycleMutex.withLock {
            if (!acceptingLogs) return
            val completion = CompletableDeferred<Unit>()
            commandChannel.send(Command.Flush(completion))
            completion.await()
        }
    }

    fun deleteOverdue() {
        scope.launch {
            lifecycleMutex.withLock {
                if (acceptingLogs) {
                    commandChannel.send(Command.Cleanup)
                }
            }
        }
    }

    suspend fun closeAndJoin() {
        lifecycleMutex.withLock {
            val shouldClose = synchronized(enqueueLock) {
                if (!acceptingLogs) {
                    false
                } else {
                    acceptingLogs = false
                    true
                }
            }
            if (!shouldClose) return

            val completion = CompletableDeferred<Unit>()
            commandChannel.send(Command.Close(completion))
            try {
                completion.await()
            } finally {
                withContext(NonCancellable) {
                    workerJob.join()
                    commandChannel.close()
                    scope.cancel()
                }
            }
        }
    }

    override fun close() {
        runBlocking {
            closeAndJoin()
        }
    }

    private suspend fun runWriterLoop() {
        try {
            ensureLogDirectory()
            deleteOverdueFiles()
            managedSizeBytes = calculateManagedSize()
            enforceTotalSizeLimit()
        } catch (exception: CancellationException) {
            throw exception
        } catch (exception: Exception) {
            reportFailure(exception)
        }

        while (true) {
            when (val command = receiveNextCommand()) {
                is Command.Write -> handleWrite(command.entry)
                is Command.Flush -> handleFlush(command.completion)
                Command.Cleanup -> handleCleanup()
                is Command.Close -> {
                    handleClose(command.completion)
                    return
                }
            }
        }
    }

    private suspend fun receiveNextCommand(): Command {
        while (true) {
            if (writer == null) {
                return commandChannel.receive()
            }
            val command = withTimeoutOrNull(config.flushIntervalMillis.milliseconds) {
                commandChannel.receive()
            }
            if (command != null) {
                return command
            }
            try {
                flushCurrentWriter()
            } catch (exception: Exception) {
                handleWriterFailure(exception)
            }
        }
    }

    private fun handleWrite(entry: LogEntry) {
        try {
            val content = formatContent(entry)
            val contentSizeBytes = content.toByteArray(Charsets.UTF_8).size.toLong()
            ensureWriter(entry.timestamp.toLocalDate(), contentSizeBytes)
            writer?.write(content)
            currentFileSizeBytes += contentSizeBytes
            managedSizeBytes += contentSizeBytes
            enforceTotalSizeLimit()
        } catch (exception: CancellationException) {
            throw exception
        } catch (exception: Exception) {
            handleWriterFailure(exception)
        }
    }

    private fun handleFlush(completion: CompletableDeferred<Unit>) {
        try {
            flushCurrentWriter()
            completion.complete(Unit)
        } catch (exception: Exception) {
            reportFailure(exception)
            completion.completeExceptionally(exception)
        }
    }

    private fun handleCleanup() {
        try {
            flushCurrentWriter()
            deleteOverdueFiles()
            managedSizeBytes = calculateManagedSize()
            enforceTotalSizeLimit()
        } catch (exception: CancellationException) {
            throw exception
        } catch (exception: Exception) {
            reportFailure(exception)
        }
    }

    private fun handleClose(completion: CompletableDeferred<Unit>) {
        try {
            closeCurrentWriter()
            completion.complete(Unit)
        } catch (exception: Exception) {
            reportFailure(exception)
            completion.completeExceptionally(exception)
        }
    }

    private fun ensureWriter(date: LocalDate, contentSizeBytes: Long) {
        if (currentDate != date) {
            closeCurrentWriter()
            openWriterFor(date, contentSizeBytes)
            return
        }

        if (currentFileSizeBytes > 0 &&
            currentFileSizeBytes + contentSizeBytes > config.maxFileSizeBytes
        ) {
            closeCurrentWriter()
            currentSegment += 1
            openWriter(logFile(date, currentSegment))
        }
    }

    private fun openWriterFor(date: LocalDate, contentSizeBytes: Long) {
        ensureLogDirectory()
        val existingFiles = managedLogFiles()
            .mapNotNull { file ->
                parseLogFile(file)?.takeIf { it.date == date }?.let { it.segment to file }
            }
            .sortedBy { it.first }
        val latest = existingFiles.lastOrNull()
        val segment = latest?.first ?: 0
        val file = latest?.second ?: logFile(date, segment)

        currentDate = date
        currentSegment = segment
        if (file.length() > 0 &&
            file.length() + contentSizeBytes > config.maxFileSizeBytes
        ) {
            currentSegment += 1
            openWriter(logFile(date, currentSegment))
        } else {
            openWriter(file)
        }
    }

    private fun openWriter(file: File) {
        ensureLogDirectory()
        writer = BufferedWriter(
            OutputStreamWriter(
                FileOutputStream(file, true),
                Charsets.UTF_8
            ),
            DEFAULT_BUFFER_SIZE
        )
        currentFile = file
        currentFileSizeBytes = file.length()
        currentDate = parseLogFile(file)?.date
    }

    private fun flushCurrentWriter() {
        writer?.flush()
    }

    private fun closeCurrentWriter() {
        val activeWriter = writer
        writer = null
        currentFile = null
        currentDate = null
        currentFileSizeBytes = 0L
        activeWriter?.close()
    }

    private fun handleWriterFailure(exception: Exception) {
        reportFailure(exception)
        try {
            closeCurrentWriter()
        } catch (closeException: Exception) {
            reportFailure(closeException)
        }
        try {
            managedSizeBytes = calculateManagedSize()
        } catch (sizeException: Exception) {
            reportFailure(sizeException)
        }
    }

    private fun ensureLogDirectory() {
        if (directory.isDirectory) return
        if (directory.exists() || !directory.mkdirs()) {
            throw IOException("Unable to create log directory: ${directory.absolutePath}")
        }
    }

    private fun deleteOverdueFiles() {
        val now = System.currentTimeMillis()
        val expireTime = TimeUnit.DAYS.toMillis(config.saveDays.toLong())
        val activeFile = currentFile
        managedLogFiles().forEach { file ->
            if (file != activeFile && now - file.lastModified() > expireTime) {
                val fileSize = file.length()
                if (file.delete()) {
                    managedSizeBytes = (managedSizeBytes - fileSize).coerceAtLeast(0L)
                }
            }
        }
    }

    private fun enforceTotalSizeLimit() {
        if (managedSizeBytes <= config.maxTotalSizeBytes) return

        val activeFile = currentFile
        managedLogFiles()
            .asSequence()
            .filter { it != activeFile }
            .sortedWith(compareBy(File::lastModified, File::getName))
            .forEach { file ->
                if (managedSizeBytes <= config.maxTotalSizeBytes) return
                val fileSize = file.length()
                if (file.delete()) {
                    managedSizeBytes = (managedSizeBytes - fileSize).coerceAtLeast(0L)
                }
            }
    }

    private fun calculateManagedSize(): Long {
        return managedLogFiles().sumOf(File::length)
    }

    private fun managedLogFiles(): List<File> {
        return directory.listFiles()
            ?.filter { it.isFile && managedLogFileRegex.matches(it.name) }
            .orEmpty()
    }

    private fun logFile(date: LocalDate, segment: Int): File {
        val datePart = date.format(FILE_DATE_FORMATTER)
        val fileName = if (segment == 0) {
            "$datePart.${config.extension}"
        } else {
            "$datePart.$segment.${config.extension}"
        }
        return File(directory, fileName)
    }

    private fun parseLogFile(file: File): LogFileInfo? {
        val match = managedLogFileRegex.matchEntire(file.name) ?: return null
        val date = runCatching {
            LocalDate.parse(file.name.substring(0, 8), FILE_DATE_FORMATTER)
        }.getOrNull() ?: return null
        val segment = match.groupValues[1].toIntOrNull() ?: 0
        return LogFileInfo(date, segment)
    }

    private fun formatContent(entry: LogEntry): String {
        val normalizedMessage = entry.message
            .replace("\r\n", "\n")
            .replace('\r', '\n')
        return buildString {
            append(entry.timestamp.format(LOG_TIME_FORMATTER))
            append('\n')
            normalizedMessage.split('\n').forEach { line ->
                append("  ")
                append(line)
                append('\n')
            }
        }
    }

    private fun reportFailure(throwable: Throwable) {
        throwable.printStackTrace()
    }

    private sealed interface Command {
        data class Write(val entry: LogEntry) : Command
        data class Flush(val completion: CompletableDeferred<Unit>) : Command
        data object Cleanup : Command
        data class Close(val completion: CompletableDeferred<Unit>) : Command
    }

    private data class LogEntry(
        val timestamp: LocalDateTime,
        val message: String
    )

    private data class LogFileInfo(
        val date: LocalDate,
        val segment: Int
    )

    data class Config(
        val logDir: String,
        val extension: String = "log",
        val saveDays: Int = 10,
        val maxFileSizeBytes: Long = 10L * 1024L * 1024L,
        val maxTotalSizeBytes: Long = 100L * 1024L * 1024L,
        val queueCapacity: Int = 1024,
        val flushIntervalMillis: Long = 1_000L
    )

    companion object {
        private val FILE_DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd")
        private val LOG_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")
    }
}
