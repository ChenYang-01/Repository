package com.candy.preview

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.C
import androidx.media3.common.Player

/**
 * Compose 可观察的播放器状态和控制入口。
 *
 * 本类不创建、持有所有权或释放播放器，由 [ItemVideoPreview] 在组合生命周期内绑定。
 * 一个实例同一时刻只能绑定一个 [Player]，不能由并存的视频页面共享；未绑定时控制方法无操作。
 *
 * @param isAutoPlay 页面变为当前页时是否自动设置播放意图，并非持续强制自动播放。默认为 `true`。
 */
@Stable
class PlayerState(val isAutoPlay: Boolean = true) {
    private var player: Player? = null
    private var hasHandledEnd = false
    private var isSeeking = false

    /** 当前播放位置，单位为毫秒；拖动时先乐观更新，播放期间约每 500 ms 同步。 */
    var progress by mutableLongStateOf(0L)
        private set

    /** 当前播放器是否处于 [Player.STATE_READY]。 */
    var isPrepared by mutableStateOf(false)
        private set

    /** 播放器当前是否正在播放，不等同于 [playWhenReady]，受缓冲等条件影响。 */
    var isPlaying by mutableStateOf(false)
        private set

    /** 当前页面激活周期是否收到首帧回调；重新激活或重新绑定时会重置。 */
    var isFirstFrameRendered by mutableStateOf(false)
        private set

    /** 是否刚到达结尾；到达结尾后实现会回到起点并清除播放意图。 */
    var isEnded by mutableStateOf(false)
        private set

    /** 播放器的播放意图，不等同于缓冲等条件影响后的 [isPlaying]。 */
    /** 播放器的播放意图，不等同于缓冲等条件影响后的 [isPlaying]。 */
    var playWhenReady by mutableStateOf(false)
        private set

    /** 当前播放器状态，对应 [Player.getPlaybackState] 返回值。 */
    var playbackState by mutableIntStateOf(Player.STATE_IDLE)
        private set

    /** 当前播放器是否处于错误状态。 */
    var hasError by mutableStateOf(false)
        private set

    /** 媒体时长，单位为毫秒；未绑定或时长未知时为 `0`。 */
    val duration: Long
        get() = player?.duration?.takeIf { it != C.TIME_UNSET } ?: 0L

    internal fun attach(player: Player) {
        if (this.player !== player) {
            isFirstFrameRendered = false
        }
        this.player = player
        sync()
    }

    internal fun onRenderedFirstFrame() {
        isFirstFrameRendered = true
    }

    internal fun resetRenderedFrame() {
        isFirstFrameRendered = false
    }

    internal fun detach(player: Player) {
        // 只清除仍由该播放器持有的状态，避免旧页面销毁时擦除新的绑定。
        if (this.player == player) {
            this.player = null
            progress = 0L
            isPrepared = false
            isPlaying = false
            isFirstFrameRendered = false
            isEnded = false
            hasHandledEnd = false
            isSeeking = false
            playWhenReady = false
            playbackState = Player.STATE_IDLE
            hasError = false
        }
    }

    internal fun sync() {
        val player = player
        if (!isSeeking) {
            progress = player?.currentPosition ?: 0L
            isPlaying = player?.isPlaying == true
        }
        isPrepared = player?.playbackState == Player.STATE_READY
        playbackState = player?.playbackState ?: Player.STATE_IDLE
        playWhenReady = player?.playWhenReady == true
        hasError = player?.playerError != null

        if (isSeeking && player?.playbackState != Player.STATE_BUFFERING) {
            isSeeking = false
            progress = player?.currentPosition ?: 0L
            isPlaying = player?.isPlaying == true
        }

        val justEnded = player?.playbackState == Player.STATE_ENDED
        if (justEnded && !hasHandledEnd) {
            hasHandledEnd = true
            player.seekTo(0L)
            player.playWhenReady = false
        }
        if (!justEnded) {
            hasHandledEnd = false
        }
        isEnded = justEnded
    }

    /** 切换播放/暂停：正在播放则暂停，否则开始播放。 */
    fun togglePlay() {
        if (isPlaying) pause() else play()
    }

    /** 跳转到毫秒位置；已知时长时约束到媒体范围，否则只约束为非负数。 */
    fun seekTo(positionMillis: Long) {
        val player = player ?: return
        val duration = duration
        val target = if (duration > 0L) {
            positionMillis.coerceIn(0L, duration)
        } else {
            positionMillis.coerceAtLeast(0L)
        }
        isSeeking = true
        progress = target
        player.seekTo(target)
    }

    /**
     * 开始播放。空闲或错误状态会先重新准备，已结束的媒体会从头开始。
     */
    fun play() {
        val player = player ?: return
        if (player.playerError != null) {
            player.prepare()
        } else if (player.playbackState == Player.STATE_IDLE) {
            player.prepare()
        }
        if (player.playbackState == Player.STATE_ENDED) {
            player.seekTo(0L)
        }
        player.play()
    }

    /** 暂停播放但不释放播放器。 */
    fun pause() {
        player?.pause()
    }

    /** 停止但不释放播放器。 */
    fun stop() {
        player?.stop()
    }

    /** [stop] 的别名，不表示跳转到媒体末尾。 */
    fun end() {
        stop()
    }

    /** 将播放位置移到媒体起点。 */
    fun seekToStart() {
        player?.seekTo(0L)
    }

    /** 将播放位置移到媒体末尾。 */
    fun seekToEnd() {
        val duration = duration
        if (duration > 0L) {
            player?.seekTo(duration)
        }
    }

    /** 快进指定毫秒数；调用方应传非负值，已知时长时不会超过末尾。 */
    fun fastForward(durationMillis: Long) {
        val player = player ?: return
        val targetPosition = player.currentPosition + durationMillis
        val duration = duration
        player.seekTo(if (duration > 0L) targetPosition.coerceAtMost(duration) else targetPosition)
    }

    /** 后退指定毫秒数；调用方应传非负值，结果不会早于起点。 */
    fun rewind(durationMillis: Long) {
        val player = player ?: return
        player.seekTo((player.currentPosition - durationMillis).coerceAtLeast(0L))
    }

    /** 静音，等同于 [setVolume]\(0f\)。 */
    fun mute() {
        setVolume(0f)
    }

    /** 设置音量，并将值约束到 `0f..1f`。 */
    fun setVolume(volume: Float) {
        player?.volume = volume.coerceIn(0f, 1f)
    }
}
