package com.candy.preview

import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * 横向媒体预览的颜色配置。
 *
 * @param backgroundColor 预览及拖动淡出时的背景色，默认为黑色。
 * @param scrimColor 顶部栏、底部栏和视频进度条等控件的遮罩背景色。
 * @param chromeColor 文字、图标和进度条活动轨道的颜色。
 * @param progressTrackInactive 进度条未激活轨道的颜色，默认为半透明白色。
 * @param centerPlayButtonBg 视频中央播放按钮的半透明背景色。
 * @param thumbnailVideoBadge 缩略图条中视频播放图标的半透明背景色。
 * @param selectedBorderOuter 缩略图选中态的外层边框色。
 * @param selectedBorderInner 缩略图选中态的内层边框色。
 */
data class HorizontalPreviewTheme(
    val backgroundColor: Color = Color.Black,
    val scrimColor: Color = Color.Black,
    val chromeColor: Color = Color.White,
    val progressTrackInactive: Color = Color.White.copy(alpha = 0.3f),
    val centerPlayButtonBg: Color = Color.Black.copy(alpha = 0.35f),
    val thumbnailVideoBadge: Color = Color.Black.copy(alpha = 0.4f),
    val selectedBorderOuter: Color = Color.White,
    val selectedBorderInner: Color = Color.Black.copy(0.5f),
)

/**
 * 当前预览主题的 CompositionLocal。[HorizontalPreview] 会自动提供此值，
 * 独立使用内部组件（如 [VideoControlBar]、[ThumbnailStrip]）时可自行覆盖。
 */
val LocalHorizontalPreviewTheme = staticCompositionLocalOf { HorizontalPreviewTheme() }
