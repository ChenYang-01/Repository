package com.candy.preview

import androidx.annotation.OptIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import candy.zoomable.zoomable.DoubleClickToZoomListener
import candy.zoomable.zoomable.ZoomableState
import candy.zoomable.zoomable.rememberZoomableState
import candy.zoomable.zoomable.zoomable
import coil3.ImageLoader
import coil3.compose.AsyncImage
import coil3.imageLoader
import coil3.request.ImageRequest
import coil3.video.VideoFrameDecoder
import coil3.video.videoFrameMillis
import kotlinx.coroutines.delay

private const val FIRST_FRAME_COVER_DELAY_MILLIS = 50L

/**
 * 显示单个可缩放视频页面。
 *
 * 每个 [IPreview.uri] 在当前组合生命周期创建一个 ExoPlayer。当前页会按需准备并依据
 * [PlayerState.isAutoPlay] 设置播放意图；非当前页会暂停并从 PlayerView 解绑，但保留进度，
 * 直到离开组合或 URI 改变才释放播放器。缩略图为空时不会自动生成封面。
 *
 * @param item 待播放的视频媒体项，[IPreview.uri] 用作播放地址和播放器实例键。
 * @param modifier 应用于视频页面根容器的修饰符。
 * @param zoomableState 当前页面的缩放状态，不应与其他同时显示的页面共享。
 * @param onClick 单击视频时调用，参数为页面局部坐标。
 * @param onLongClick 长按视频时调用，参数为页面局部坐标。
 * @param onDoubleClick 双击视频时使用的缩放处理器。
 * @param isCurrentPage 是否为 Pager 当前页。非当前页会暂停播放并从 PlayerView 解绑。
 * @param playerState 视频的可观察播放状态。同一实例不得同时绑定多个视频页面。
 * @param backgroundColor PlayerView 在视频帧显示前使用的 shutter 颜色。
 * @param imageLoader 视频封面使用的 Coil 加载器。
 */
@OptIn(UnstableApi::class)
@Composable
fun ItemVideoPreview(
    item: IPreview,
    modifier: Modifier = Modifier,
    zoomableState: ZoomableState = rememberZoomableState(),
    onClick: ((Offset) -> Unit)? = null,
    onLongClick: ((Offset) -> Unit)? = null,
    onDoubleClick: DoubleClickToZoomListener = DoubleClickToZoomListener.cycle(),
    isCurrentPage: Boolean = true,
    playerState: PlayerState = remember { PlayerState(isAutoPlay = false) },
    backgroundColor: Color = Color.Black,
    imageLoader: ImageLoader = LocalContext.current.imageLoader
) {
    val context = LocalContext.current
    val playerViewHolder = remember(item.uri) { PlayerViewHolder() }

    val exoPlayer = remember(item.uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(item.uri))
        }
    }

    // PlayerState 不拥有播放器；此 effect 负责完整的绑定、监听、解绑和释放生命周期。
    DisposableEffect(exoPlayer, playerState) {
        playerState.attach(exoPlayer)
        val listener = object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) {
                playerState.sync()
            }

            override fun onRenderedFirstFrame() {
                playerState.onRenderedFirstFrame()
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            playerViewHolder.view?.player = null
            playerViewHolder.view = null
            exoPlayer.clearVideoSurface()
            exoPlayer.removeListener(listener)
            playerState.detach(exoPlayer)
            exoPlayer.release()
        }
    }

    LaunchedEffect(exoPlayer, playerState, isCurrentPage) {
        if (isCurrentPage) {
            playerState.resetRenderedFrame()
            if (exoPlayer.playbackState == Player.STATE_IDLE) {
                exoPlayer.prepare()
            }
            exoPlayer.playWhenReady = playerState.isAutoPlay
        } else {
            exoPlayer.pause()
            playerState.resetRenderedFrame()
        }
    }

    LaunchedEffect(exoPlayer, playerState) {
        while (true) {
            playerState.sync()
            delay(500)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .zoomable(
                state = zoomableState,
                onClick = onClick,
                onLongClick = onLongClick,
                onDoubleClick = onDoubleClick
            )
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    controllerAutoShow = false
                    setKeepContentOnPlayerReset(true)
                    hideController()
                    playerViewHolder.view = this
                }
            },
            modifier = Modifier.fillMaxSize(),
            onRelease = { playerView ->
                if (playerView.player === exoPlayer) {
                    playerView.player = null
                }
                if (playerViewHolder.view === playerView) {
                    playerViewHolder.view = null
                }
            },
            update = { playerView ->
                playerView.setShutterBackgroundColor(backgroundColor.toArgb())
                playerViewHolder.view = playerView
                if (isCurrentPage) {
                    if (playerView.player !== exoPlayer) {
                        playerView.player = exoPlayer
                    }
                } else {
                    exoPlayer.pause()
                    if (playerView.player === exoPlayer) {
                        playerView.player = null
                    }
                }
            }
        )

        var keepThumbnailVisible by remember(item.uri) { mutableStateOf(true) }
        LaunchedEffect(isCurrentPage, playerState.isFirstFrameRendered) {
            keepThumbnailVisible = when {
                !isCurrentPage || !playerState.isFirstFrameRendered -> true
                else -> {
                    // 首帧回调可能早于 View 稳定显示，短暂保留封面以避免切换闪烁。
                    delay(FIRST_FRAME_COVER_DELAY_MILLIS)
                    false
                }
            }
        }

        val showThumbnail = item.thumbnail != null && (!isCurrentPage || keepThumbnailVisible)
        if (showThumbnail) {
            val imageRequest = remember(
                item.uri, item.thumbnail, item.thumbnailWidth, item.thumbnailHeight
            ) {
                when (val thumbnail = item.thumbnail) {
                    is ImageRequest -> thumbnail
                    item.uri -> ImageRequest.Builder(context)
                        .data(item.uri)
                        .decoderFactory(VideoFrameDecoder.Factory())
                        .videoFrameMillis(1)
                        .apply {
                            if (item.thumbnailWidth > 0 && item.thumbnailHeight > 0) {
                                size(item.thumbnailWidth, item.thumbnailHeight)
                            }
                        }
                        .build()
                    else -> ImageRequest.Builder(context)
                        .data(thumbnail)
                        .apply {
                            if (item.thumbnailWidth > 0 && item.thumbnailHeight > 0) {
                                size(item.thumbnailWidth, item.thumbnailHeight)
                            }
                        }
                        .build()
                }
            }
            AsyncImage(
                model = imageRequest,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                imageLoader = imageLoader,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

private class PlayerViewHolder(var view: PlayerView? = null)
