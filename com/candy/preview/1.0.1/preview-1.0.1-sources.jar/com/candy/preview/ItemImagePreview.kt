package com.candy.preview

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import candy.zoomable.zoomable.DoubleClickToZoomListener
import candy.zoomable.zoomable.ZoomableState
import candy.zoomable.zoomable.coil3.ZoomableAsyncImage
import candy.zoomable.zoomable.rememberZoomableImageState
import candy.zoomable.zoomable.rememberZoomableState
import coil3.ImageLoader
import coil3.compose.AsyncImage
import coil3.imageLoader
import coil3.request.ImageRequest

/**
 * 显示单个可缩放图片页面。
 *
 * 非空缩略图只在原图尚未显示时作为占位。
 *
 * @param item 待显示的图片媒体项，原图从 [IPreview.uri] 加载。
 * @param modifier 应用于图片页面根容器的修饰符。
 * @param zoomableState 当前页面的缩放状态，不应与其他同时显示的页面共享。
 * @param onClick 单击图片时调用，参数为页面局部坐标。
 * @param onLongClick 长按图片时调用，参数为页面局部坐标。
 * @param onDoubleClick 双击图片时使用的缩放处理器。
 * @param imageLoader 原图和缩略图使用的 Coil 加载器。
 */
@Composable
fun ItemImagePreview(
    item: IPreview,
    modifier: Modifier = Modifier,
    zoomableState: ZoomableState = rememberZoomableState(),
    onClick: ((Offset) -> Unit)? = null,
    onLongClick: ((Offset) -> Unit)? = null,
    onDoubleClick: DoubleClickToZoomListener = DoubleClickToZoomListener.cycle(),
    imageLoader: ImageLoader = LocalContext.current.imageLoader
) {
    val zoomableImageState = rememberZoomableImageState(zoomableState)
    val context = LocalContext.current

    Box(modifier = modifier.fillMaxSize()) {
        if (!zoomableImageState.isImageDisplayed && item.thumbnail != null) {
            val thumbRequest = remember(item.thumbnail, item.thumbnailWidth, item.thumbnailHeight) {
                when (val thumbnail = item.thumbnail) {
                    is ImageRequest -> thumbnail
                    else -> ImageRequest.Builder(context)
                        .data(thumbnail)
                        .apply {
                            if (item.thumbnailWidth > 0 && item.thumbnailHeight > 0) {
                                size(item.thumbnailWidth, item.thumbnailHeight)
                            }
                        }
                        .build()
                }
            }
            AsyncImage(
                model = thumbRequest,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize(),
                imageLoader = imageLoader,
                alignment = Alignment.Center
            )
        }

        ZoomableAsyncImage(
            model = item.uri,
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            state = zoomableImageState,
            imageLoader = imageLoader,
            contentScale = ContentScale.Fit,
            onClick = onClick,
            onLongClick = onLongClick,
            onDoubleClick = onDoubleClick,
            alignment = Alignment.Center
        )
    }
}
