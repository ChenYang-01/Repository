package com.candy.preview

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import candy.zoomable.zoomable.DoubleClickToZoomListener
import coil3.ImageLoader
import coil3.compose.AsyncImage
import coil3.imageLoader
import coil3.request.ImageRequest
import coil3.video.VideoFrameDecoder
import coil3.video.videoFrameMillis
import kotlinx.coroutines.launch

/**
 * 提供顶部/底部控件的完整横向媒体预览。
 *
 * 空列表不显示内容；单击媒体会切换控件可见性，向下拖动达到容器高度的 18% 后离场并调用
 * [onDismiss]。[onBack] 非空时才注册系统返回处理并显示返回入口，[onDismiss] 不替代返回处理。
 *
 * @param items 待预览的媒体列表。URI 必须稳定且唯一；空列表不生成 UI。
 * @param modifier 应用于预览根容器的修饰符。
 * @param theme 顶部栏、底部栏、背景、进度条和缩略图使用的颜色配置。
 * @param pagerState Pager 状态，其 `pageCount` 应与 [items] 大小一致。
 * @param showThumbnails 是否在底部控件中显示媒体缩略图条。
 * @param imageLoader 图片、视频封面和缩略图使用的 Coil 加载器。
 * @param onBack 返回回调。非空时注册系统返回处理并显示顶部返回入口。
 * @param onDismiss 下拉离场动画完成后的回调，不会替代 [onBack]。
 * @param title 根据从零开始的页面位置和当前媒体项生成顶部标题。
 * @param topBarActions 显示在顶部栏尾部的自定义操作。
 * @param bottomBarActions 根据从零开始的页面位置和当前媒体项显示底部自定义操作。
 */
@Composable
fun HorizontalPreview(
    items: List<IPreview>,
    modifier: Modifier = Modifier,
    theme: HorizontalPreviewTheme = HorizontalPreviewTheme(),
    pagerState: PagerState = rememberPagerState { items.size },
    showThumbnails: Boolean = true,
    imageLoader: ImageLoader = LocalContext.current.imageLoader,
    onBack: (() -> Unit)? = null,
    onDismiss: (() -> Unit)? = null,
    title: (position: Int, item: IPreview) -> String = { position, _ -> "${position + 1}/${items.size}" },
    topBarActions: @Composable () -> Unit = {},
    bottomBarActions: @Composable (position: Int, item: IPreview) -> Unit = { _, _ -> }
) {
    if (items.isEmpty()) return

    BackHandler(enabled = onBack != null) {
        onBack?.invoke()
    }

    var chromeVisible by remember { mutableStateOf(true) }
    var dragProgress by remember { mutableStateOf(0f) }
    val scope = rememberCoroutineScope()
    val playerStates = remember { mutableStateMapOf<String, PlayerState>() }
    val currentPage = pagerState.currentPage.coerceIn(0, items.lastIndex)
    val currentItem = items[currentPage]

    // 只在向下拖动超过 1% 后隐藏顶部和底部控件。
    val effectiveChromeVisible = chromeVisible && dragProgress <= 0.01f

    CompositionLocalProvider(LocalHorizontalPreviewTheme provides theme) {
        Box(modifier = modifier.fillMaxSize()) {
            HorizontalPreviewContent(
                items = items,
                modifier = Modifier.fillMaxSize(),
                pagerState = pagerState,
                backgroundColor = theme.backgroundColor,
                playerState = { _, item ->
                    if (item.isVideo) {
                        val key = item.uri.toString()
                        remember(key) {
                            playerStates.getOrPut(key) {
                                PlayerState(
                                    isAutoPlay = false
                                )
                            }
                        }
                    } else null
                },
                imageLoader = imageLoader,
                onClick = { chromeVisible = !chromeVisible },
                onVerticalSwipe = { state ->
                    dragProgress = if (state.isDownward) state.progress else 0f
                },
                onVerticalSwipeEnd = { state ->
                    if (state.isDownward && state.progress >= 0.18f) {
                        VerticalSwipeEndAction.Continue
                    } else {
                        VerticalSwipeEndAction.Reset
                    }
                },
                onVerticalSwipeAnimationEnd = { _, action ->
                    if (action == VerticalSwipeEndAction.Continue) {
                        onDismiss?.invoke()
                    }
                },
                previewItem = { position, item, zoomState, playerState, isCurrentPage, imageLoader ->
                    Box(modifier = Modifier.fillMaxSize()) {
                        PreviewPagerDefaults.PreviewItem(
                            position = position,
                            item = item,
                            zoomState = zoomState,
                            isCurrentPage = isCurrentPage,
                            playerState = playerState,
                            onClick = { chromeVisible = !chromeVisible },
                            onDoubleClick = { DoubleClickToZoomListener.cycle() },
                            onLongClick = null,
                            imageLoader = imageLoader
                        )

                        AnimatedVisibility(
                            visible = item.isVideo && playerState != null && (!playerState.playWhenReady || playerState.isEnded || playerState.hasError) && dragProgress == 0f,
                            enter = fadeIn(),
                            exit = fadeOut(),
                            modifier = Modifier.align(Alignment.Center)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(theme.centerPlayButtonBg)
                                    .clickable { playerState?.play() },
                                contentAlignment = Alignment.Center
                            ) {
                                Image(
                                    painter = painterResource(
                                        if (playerState?.isEnded == true) R.drawable.ic_replay else R.drawable.ic_play_arrow
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                        }
                    }
                }
            )

            // 顶部控件：纯色背景、返回入口和标题/计数。
            AnimatedVisibility(
                visible = effectiveChromeVisible,
                enter = fadeIn() + slideInVertically { -it },
                exit = fadeOut() + slideOutVertically { -it },
                modifier = Modifier.align(Alignment.TopCenter)
            ) {
                PreviewTopBar(
                    title = title(currentPage, currentItem),
                    onBack = onBack,
                    actions = topBarActions
                )
            }

            // 底部控件：按条件显示视频控制、调用方操作和缩略图。
            AnimatedVisibility(
                visible = effectiveChromeVisible,
                enter = fadeIn() + slideInVertically { it },
                exit = fadeOut() + slideOutVertically { it },
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(theme.scrimColor)
                        .windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    val playerState = playerStates[currentItem.uri.toString()]
                    if (currentItem.isVideo && playerState != null) {
                        VideoControlBar(playerState = playerState)
                    }
                    bottomBarActions(currentPage, currentItem)
                    if (showThumbnails) {
                        ThumbnailStrip(
                            items = items,
                            selectedIndex = currentPage,
                            imageLoader = imageLoader,
                            onSelect = { index ->
                                scope.launch { pagerState.animateScrollToPage(index) }
                            }
                        )
                    }
                }
            }
        }
    }
}

/**
 * 顶部栏的内部实现，包含纯色遮罩背景、标题和可选的返回入口。
 *
 * @param title 居中显示的单行标题，超长时省略。
 * @param onBack 返回入口的点击回调，为 `null` 时不显示此入口。
 * @param actions 右对齐的自定义尾部操作。
 */
@Composable
private fun PreviewTopBar(
    title: String,
    onBack: (() -> Unit)?,
    actions: @Composable () -> Unit
) {
    val theme = LocalHorizontalPreviewTheme.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(theme.scrimColor)
            .windowInsetsPadding(WindowInsets.statusBars)
            .height(56.dp)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(R.drawable.ic_arrow_back),
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
            }
        } else {
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = title,
            color = theme.chromeColor,
            fontSize = 16.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp)
        )
        actions()
    }
}

/**
 * 视频底部控制条的内部实现，包含播放/暂停按钮、可拖动的进度条和剩余时间。
 *
 * @param playerState 当前视频的可观察播放状态。
 */
@Composable
private fun VideoControlBar(playerState: PlayerState) {
    val theme = LocalHorizontalPreviewTheme.current
    val duration = playerState.duration
    val progress = playerState.progress
    var scrubValue by remember { mutableStateOf<Float?>(null) }
    var displayIsPlaying by remember { mutableStateOf(playerState.isPlaying) }
    val sliderValue = scrubValue ?: if (duration > 0L) {
        (progress.toFloat() / duration).coerceIn(0f, 1f)
    } else 0f

    LaunchedEffect(playerState.isPlaying, scrubValue) {
        if (scrubValue == null) {
            displayIsPlaying = playerState.isPlaying
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(20.dp))
                .clickable { playerState.togglePlay() },
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(
                    if (displayIsPlaying) R.drawable.ic_pause else R.drawable.ic_play_arrow
                ),
                contentDescription = null,
                modifier = Modifier.size(24.dp)
            )
        }
        VideoProgressBar(
            value = sliderValue,
            onValueChange = { scrubValue = it },
            onValueChangeFinished = {
                scrubValue?.let { v ->
                    if (duration > 0L) playerState.seekTo((v * duration).toLong())
                }
                scrubValue = null
            },
            modifier = Modifier.weight(1f)
        )
        Text(
            text = formatDuration((duration - (sliderValue * duration).toLong()).coerceAtLeast(0L)),
            color = theme.chromeColor,
            fontSize = 12.sp,
            modifier = Modifier.width(44.dp)
        )
    }
}

/**
 * 视频进度条的内部实现，支持拖动和点击跳转到目标位置。
 *
 * 使用 [animateFloatAsState] 平滑过渡进度值，绘制三部分：未激活轨道、已播放轨道和圆形滑块。
 *
 * @param value 当前进度比例，`0f..1f`，用于绘制和动画目标。
 * @param onValueChange 拖动时持续回调新的进度比例。
 * @param onValueChangeFinished 拖动或点击完成后的回调，用于提交最终位置。
 * @param modifier 应用于进度条画布的修饰符。
 */
@Composable
private fun VideoProgressBar(
    value: Float,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val theme = LocalHorizontalPreviewTheme.current
    var widthPx by remember { mutableIntStateOf(0) }
    val currentWidthPx by rememberUpdatedState(widthPx)
    val currentOnValueChange by rememberUpdatedState(onValueChange)
    val currentOnValueChangeFinished by rememberUpdatedState(onValueChangeFinished)

    val smoothValue by animateFloatAsState(
        targetValue = value,
        animationSpec = tween(durationMillis = 32),
        label = "ProgressSmooth"
    )

    fun toProgress(x: Float): Float {
        val w = currentWidthPx
        return if (w > 0) (x / w).coerceIn(0f, 1f) else 0f
    }

    Canvas(
        modifier = modifier
            .height(24.dp)
            .onSizeChanged { widthPx = it.width }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = { currentOnValueChangeFinished() },
                    onDragCancel = { currentOnValueChangeFinished() },
                    onDragStart = { offset -> currentOnValueChange(toProgress(offset.x)) },
                    onDrag = { change, _ -> currentOnValueChange(toProgress(change.position.x)) }
                )
            }
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    currentOnValueChange(toProgress(offset.x))
                    currentOnValueChangeFinished()
                }
            }
    ) {
        val trackHeight = 4.dp.toPx()
        val thumbRadius = 6.dp.toPx()
        val centerY = size.height / 2f
        val progress = smoothValue.coerceIn(0f, 1f)
        val thumbX = thumbRadius + (size.width - thumbRadius * 2f) * progress
        val activeWidth = size.width * progress

        drawRoundRect(
            color = theme.progressTrackInactive,
            topLeft = Offset(0f, centerY - trackHeight / 2f),
            size = Size(size.width, trackHeight),
            cornerRadius = CornerRadius(
                trackHeight / 2f, trackHeight / 2f
            )
        )
        drawRoundRect(
            color = theme.chromeColor,
            topLeft = Offset(0f, centerY - trackHeight / 2f),
            size = Size(activeWidth, trackHeight),
            cornerRadius = CornerRadius(
                trackHeight / 2f, trackHeight / 2f
            )
        )
        drawCircle(
            color = theme.chromeColor,
            radius = thumbRadius,
            center = Offset(thumbX, centerY)
        )
    }
}

/**
 * 底部缩略图条的内部实现，水平排列预览缩略图并自动滚动到选中项。
 *
 * 每项为 48dp 的正方形缩略图，视频项叠加半透明播放图标，选中项有双层圆角边框。
 *
 * @param items 预览媒体列表，用于生成每项缩略图。
 * @param selectedIndex 当前选中页面的索引，决定滚动位置和选中样式。
 * @param imageLoader Coil 图片加载器。
 * @param onSelect 点击缩略图时的跳转回调。
 */
@Composable
private fun ThumbnailStrip(
    items: List<IPreview>,
    selectedIndex: Int,
    imageLoader: ImageLoader,
    onSelect: (Int) -> Unit
) {
    val theme = LocalHorizontalPreviewTheme.current
    val context = LocalContext.current
    val listState = rememberLazyListState()
    val density = LocalDensity.current
    LaunchedEffect(selectedIndex) {
        val viewportWidth = listState.layoutInfo.viewportSize.width
        val itemSizePx = with(density) { 48.dp.roundToPx() }
        if (viewportWidth > 0) {
            listState.animateScrollToItem(
                index = selectedIndex.coerceAtLeast(0),
                scrollOffset = -(viewportWidth / 2 - itemSizePx / 2)
            )
        } else {
            listState.animateScrollToItem(selectedIndex.coerceAtLeast(0))
        }
    }
    LazyRow(
        state = listState,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        contentPadding = PaddingValues(horizontal = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        itemsIndexed(items) { index, item ->
            val selected = index == selectedIndex
            val thumbnailModel = remember(
                item.uri,
                item.thumbnail,
                item.thumbnailWidth,
                item.thumbnailHeight,
                item.isVideo,
            ) {
                previewThumbnailModel(context, item)
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .border(
                        width = if (selected) 1.dp else 0.dp,
                        color = if (selected) theme.selectedBorderOuter else Color.Transparent,
                        shape = RoundedCornerShape(6.dp)
                    )
                    .then(
                        if (selected) {
                            Modifier.border(
                                2.dp, theme.selectedBorderInner, RoundedCornerShape(6.dp)
                            )
                        } else {
                            Modifier
                        }
                    )
                    .clickable { onSelect(index) }
            ) {
                AsyncImage(
                    model = thumbnailModel,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    imageLoader = imageLoader,
                    modifier = Modifier.fillMaxSize(),
                )
                if (item.isVideo) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(20.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(theme.thumbnailVideoBadge),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(R.drawable.ic_play_arrow),
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * 根据 [IPreview] 的属性构建缩略图加载模型。
 *
 * 优先使用 [IPreview.thumbnail] 中的 [ImageRequest]，其次直接使用原始数据。
 * 若为视频且无独立缩略图数据，则使用 [VideoFrameDecoder] 提取首帧。
 *
 * @param context 用于构建 [ImageRequest] 的 Android Context。
 * @param item 包含缩略图、URI 和尺寸信息的媒体项。
 * @return 可直接传入 [AsyncImage] 的加载模型（[ImageRequest] 或原始数据）。
 */
private fun previewThumbnailModel(context: Context, item: IPreview): Any {
    val thumbnail = item.thumbnail
    if (thumbnail is ImageRequest) return thumbnail

    val data = thumbnail ?: item.uri
    val needsVideoFrameDecoder = item.isVideo && (thumbnail == null || thumbnail == item.uri)
    if (
        !needsVideoFrameDecoder &&
        item.thumbnailWidth <= 0 &&
        item.thumbnailHeight <= 0
    ) {
        return data
    }

    return ImageRequest.Builder(context)
        .data(data)
        .apply {
            if (needsVideoFrameDecoder) {
                decoderFactory(VideoFrameDecoder.Factory())
                videoFrameMillis(1)
            }
            if (item.thumbnailWidth > 0 && item.thumbnailHeight > 0) {
                size(item.thumbnailWidth, item.thumbnailHeight)
            }
        }
        .build()
}

/** 将毫秒值格式化为 `MM:SS` 字符串，非正数返回 `"00:00"`。 */
private fun formatDuration(millis: Long): String {
    if (millis <= 0L) return "00:00"
    val totalSeconds = millis / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return "%02d:%02d".format(minutes, seconds)
}
