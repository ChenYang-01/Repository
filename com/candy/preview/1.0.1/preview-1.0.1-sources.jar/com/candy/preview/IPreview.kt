package com.candy.preview

import android.net.Uri
import androidx.compose.runtime.Stable

/**
 * 可由横向预览组件展示的图片或视频。
 *
 * 当前实现使用 [uri] 的字符串值作为 Pager 和页面状态的稳定键，因此同一列表内的 URI
 * 必须稳定且唯一。实现还应遵守 Compose [Stable] 契约：属性保持不变，或通过可观察状态更新。
 *
 * @param uri 原始媒体加载地址，同时作为当前实现中的页面身份。
 * @param isVideo 是否使用 Media3 视频预览；组件不会根据 MIME 自动推断。
 * @param thumbnail 可由 Coil 加载的缩略图数据或完整 [ImageRequest]。图片加载完成前将其作为
 * 占位，视频仅在非空时显示。
 * @param thumbnailWidth 缩略图请求宽度，单位为像素；宽高均大于零且缩略图不是完整请求时生效。
 * @param thumbnailHeight 缩略图请求高度，单位为像素；宽高均大于零且缩略图不是完整请求时生效。
 */
@Stable
interface IPreview {
    /** 原始媒体加载地址，同时作为当前实现中的页面身份。 */
    val uri: Uri

    /** 是否使用 Media3 视频预览；组件不会根据 MIME 自动推断。 */
    val isVideo: Boolean

    /**
     * 可由 Coil 加载的缩略图数据或完整 [ImageRequest]。
     * 图片加载完成前将其作为占位，视频仅在非空时显示。
     */
    val thumbnail: Any? get() = null

    /** 缩略图请求宽度，单位为像素；宽高均大于零且缩略图不是完整请求时生效。 */
    val thumbnailWidth: Int get() = 0

    /** 缩略图请求高度，单位为像素；宽高均大于零且缩略图不是完整请求时生效。 */
    val thumbnailHeight: Int get() = 0
}
