package com.candy.preview

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.PointerInputScope
import kotlin.math.abs
import kotlin.math.pow

/**
 * 纵向手势的回调参数集。
 *
 * 手势开始时提供初始偏移，进行中提供增量，结束时提供释放点的瞬时速度。
 */
class VerticalSwipeCallbacks(
    val canStartSwipe: () -> Boolean,
    val onSwipeStart: () -> Unit,
    val onSwipe: (dragAmountX: Float, dragAmountY: Float) -> Unit,
    val onSwipeEnd: (velocityX: Float, velocityY: Float) -> Unit,
    val onSwipeCancel: () -> Unit,
)

/**
 * 在纵向累计位移超过 touch slop 且大于横向位移后取得手势。
 *
 * 取得前不消费事件，取得后消费活动指针，并将包含 slop 的累计纵向位移作为首个增量。
 * 多指、活动指针丢失或手势竞争会取消；[canStartSwipe] 只决定是否取得手势。
 *
 * @param canStartSwipe 在每次纵向位移超过阈值后调用，返回 `true` 时取得手势所有权。
 * @param onSwipeStart 手势取得所有权时调用一次。
 * @param onSwipe 每次位移变化时调用（含初始累积值），参数为横向和纵向增量。手势触发后可任意方向拖动。
 * @param onSwipeEnd 手势正常结束时调用（活动指针抬起），参数为释放点的横向和纵向像素/秒速度。
 * @param onSwipeCancel 手势因多指、指针丢失或竞争取消时调用。
 */
internal suspend fun PointerInputScope.detectVerticalSwipeGestures(
    callbacks: VerticalSwipeCallbacks,
) {
    val touchSlop = viewConfiguration.touchSlop

    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        var activePointerId = down.id
        var accumulatedX = 0f
        var accumulatedY = 0f
        var isDragging = false
        var previousUptimeMillis = down.uptimeMillis
        // 为消除噪声，用最后几帧的速度做指数移动平均
        var velocityX = 0f
        var velocityY = 0f
        val velocitySmoothingFactor = 0.5f

        while (true) {
            val event = awaitPointerEvent()
            if (event.changes.count { it.pressed } > 1) {
                if (isDragging) {
                    callbacks.onSwipeCancel()
                }
                break
            }

            val change = event.changes.firstOrNull { it.id == activePointerId }
            if (change == null) {
                if (isDragging) {
                    callbacks.onSwipeCancel()
                }
                break
            }
            val delta = change.position - change.previousPosition
            val currentUptimeMillis = change.uptimeMillis
            val dtMillis = (currentUptimeMillis - previousUptimeMillis).coerceAtLeast(1)
            previousUptimeMillis = currentUptimeMillis

            if (!isDragging) {
                accumulatedX += delta.x
                accumulatedY += delta.y

                val passedVerticalSlop = abs(accumulatedY) > touchSlop && abs(accumulatedY) > abs(
                    accumulatedX
                )
                val shouldStartSwipe = passedVerticalSlop && callbacks.canStartSwipe()

                if (shouldStartSwipe) {
                    isDragging = true
                    callbacks.onSwipeStart()
                    change.consume()
                    callbacks.onSwipe(accumulatedX, accumulatedY)
                }
            } else {
                if (delta.x != 0f || delta.y != 0f) {
                    // 指数移动平均速度：pixels/ms → pixels/s
                    val instantVx = delta.x / dtMillis * 1000f
                    val instantVy = delta.y / dtMillis * 1000f
                    val dtSec = dtMillis / 1000f
                    val alpha = if (dtSec > 0f) {
                        (1f - velocitySmoothingFactor).toDouble().pow(dtSec.toDouble()).toFloat()
                    } else {
                        0f
                    }
                    velocityX = velocityX * alpha + instantVx * (1f - alpha)
                    velocityY = velocityY * alpha + instantVy * (1f - alpha)

                    callbacks.onSwipe(delta.x, delta.y)
                    change.consume()
                }
            }

            if (!change.pressed) {
                if (isDragging) {
                    callbacks.onSwipeEnd(velocityX, velocityY)
                } else if (event.changes.any { it.isConsumed }) {
                    callbacks.onSwipeCancel()
                }
                break
            }
            activePointerId = change.id
        }
    }
}
