package com.candy.preview

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.SnapSpec
import androidx.compose.animation.core.tween
import androidx.compose.foundation.OverscrollEffect
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.TargetedFlingBehavior
import androidx.compose.foundation.gestures.snapping.SnapPosition
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.PagerDefaults
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberOverscrollEffect
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import candy.zoomable.zoomable.DoubleClickToZoomListener
import candy.zoomable.zoomable.ZoomSpec
import candy.zoomable.zoomable.ZoomableState
import candy.zoomable.zoomable.rememberZoomableState
import coil3.ImageLoader
import coil3.imageLoader
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/** 纵向手势结束后的动画行为，由 onVerticalSwipeEnd 返回。 */
enum class VerticalSwipeEndAction {
    /** 沿当前方向动画至至少一个容器高度，常用于触发离场。 */
    Continue,

    /** 动画回到初始位置，取消本次拖动。 */
    Reset,

    /** 保持当前偏移不变，不执行任何动画。 */
    Stay
}

/**
 * 下拉交互在某一时刻的不可变快照。
 *
 * [offsetY] 是相对静止位置的像素偏移，正值向下、负值向上且不限制在容器范围内。
 * [progress] 是偏移距离除以容器高度并约束到 `0f..1f` 的结果，不表示方向。
 */
data class VerticalSwipeState(
    val position: Int,
    val item: IPreview,
    val progress: Float,
    val offsetY: Float
) {
    val isUpward: Boolean
        get() = offsetY < 0f

    val isDownward: Boolean
        get() = offsetY > 0f
}

/** 预览点击信息；[offset] 是预览内容局部坐标中的像素位置。 */
data class PreviewClickState(
    val position: Int,
    val item: IPreview,
    val offset: Offset
)

/**
 * 显示支持缩放、横向翻页和纵向拖动的媒体预览内容。
 *
 * 页面完全离开可视区域后会立即重置缩放。纵向手势仅能在页面处于最小缩放附近时开始，
 * 手势期间会暂停横向翻页。
 *
 * @param items 待预览的媒体列表。URI 必须稳定且唯一；空列表不生成 UI。
 * @param modifier 应用于横向 Pager 的修饰符。
 * @param pagerState Pager 状态，其 `pageCount` 应与 [items] 大小一致。
 * @param backgroundColor 页面背景色，纵向拖动时会随进度逐渐透明。
 * @param zoomSpec 根据页面位置和媒体项创建该页的缩放配置。
 * @param playerState 根据页面位置和媒体项提供播放器状态。每个并存视频应返回独立且稳定的
 * 实例，图片应返回 `null`。
 * @param imageLoader 图片和视频缩略图使用的 Coil 加载器。
 * @param contentPadding Pager 内容区域的内边距。
 * @param pageSize Pager 中每页的尺寸策略。
 * @param beyondViewportPageCount 可视区域前后保留组合的页面数量。
 * @param pageSpacing 相邻页面之间的间距。
 * @param verticalAlignment 页面内容在 Pager 中的垂直对齐方式。
 * @param flingBehavior 横向翻页的惯性滚动行为。
 * @param pageNestedScrollConnection Pager 使用的嵌套滚动连接。
 * @param snapPosition 页面停止滚动时的吸附位置。
 * @param overscrollEffect Pager 的越界滚动效果；传入 `null` 可禁用。
 * @param onClick 单击预览项时调用，参数包含页面、媒体项和局部点击坐标。
 * @param onDoubleClick 根据双击信息返回该次双击使用的缩放处理器。
 * @param onLongClick 长按预览项时调用；传入 `null` 不处理长按。
 * @param verticalSwipeScale 根据纵向手势状态计算内容缩放比例，结果只会被约束为非负数。
 * @param canVerticalSwipe 手势取得所有权后，针对每个纵向增量判断是否接受该次位移。
 * @param onVerticalSwipeStart 纵向手势开始时调用。
 * @param onVerticalSwipe 纵向偏移变化时调用；由 Compose effect 分发，不保证与指针事件一一对应。
 * @param onVerticalSwipeEnd 纵向手势正常结束或取消时调用，返回结束动画行为。
 * @param onVerticalSwipeAnimationEnd 结束动画完成后调用。状态参数是动画开始前的快照；
 * 动画被新手势取消时不保证调用。
 * @param previewItem 页面内容。参数依次为页面位置、媒体项、该页缩放状态、播放器状态、
 * 是否为当前页及图片加载器。
 */
@Composable
fun HorizontalPreviewContent(
    items: List<IPreview>,
    modifier: Modifier = Modifier,
    pagerState: PagerState = rememberPagerState { items.size },
    backgroundColor: Color = Color.Black,
    zoomSpec: (position: Int, item: IPreview) -> ZoomSpec = { _, _ -> ZoomSpec() },
    playerState: @Composable (position: Int, item: IPreview) -> PlayerState? = { _, item ->
        if (item.isVideo) remember(item.previewKey) { PlayerState(isAutoPlay = true) } else null
    },
    imageLoader: ImageLoader = LocalContext.current.imageLoader,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    pageSize: PageSize = PageSize.Fill,
    beyondViewportPageCount: Int = 1,
    pageSpacing: Dp = 0.dp,
    verticalAlignment: Alignment.Vertical = Alignment.CenterVertically,
    flingBehavior: TargetedFlingBehavior = PagerDefaults.flingBehavior(state = pagerState),
    pageNestedScrollConnection: NestedScrollConnection = PagerDefaults.pageNestedScrollConnection(
        pagerState, Orientation.Horizontal
    ),
    snapPosition: SnapPosition = SnapPosition.Start,
    overscrollEffect: OverscrollEffect? = rememberOverscrollEffect(),
    onClick: ((PreviewClickState) -> Unit)? = null,
    onDoubleClick: (PreviewClickState) -> DoubleClickToZoomListener = { DoubleClickToZoomListener.cycle() },
    onLongClick: ((PreviewClickState) -> Unit)? = null,
    verticalSwipeScale: (VerticalSwipeState) -> Float = { if (it.isDownward) 1f - it.progress * 0.45f else 1f },
    canVerticalSwipe: (state: VerticalSwipeState, dragAmountY: Float) -> Boolean = { state, dragAmountY -> state.offsetY > 0 || dragAmountY > 0 },
    onVerticalSwipeStart: (VerticalSwipeState) -> Unit = {},
    onVerticalSwipe: (VerticalSwipeState) -> Unit = {},
    onVerticalSwipeEnd: (VerticalSwipeState) -> VerticalSwipeEndAction = {
        if (it.progress >= 0.05) {
            VerticalSwipeEndAction.Continue
        } else {
            VerticalSwipeEndAction.Reset
        }
    },
    onVerticalSwipeAnimationEnd: (VerticalSwipeState, VerticalSwipeEndAction) -> Unit = { _, _ -> },
    previewItem: @Composable (
        position: Int,
        item: IPreview,
        zoomState: ZoomableState,
        playerState: PlayerState?,
        isCurrentPage: Boolean,
        imageLoader: ImageLoader
    ) -> Unit = { position, item, state, statePlayer, isCurrentPage, loader ->
        PreviewPagerDefaults.PreviewItem(
            position = position,
            item = item,
            modifier = Modifier,
            zoomState = state,
            playerState = statePlayer,
            isCurrentPage = isCurrentPage,
            onClick = onClick,
            onDoubleClick = onDoubleClick,
            onLongClick = onLongClick,
            backgroundColor = backgroundColor,
            imageLoader = loader
        )
    }
) {
    if (items.isEmpty()) return

    var isDismissGestureInProgress by remember { mutableStateOf(false) }

    HorizontalPager(
        state = pagerState,
        modifier = modifier.fillMaxSize(),
        userScrollEnabled = !isDismissGestureInProgress,
        key = { index -> items[index].previewKey },
        beyondViewportPageCount = beyondViewportPageCount,
        contentPadding = contentPadding,
        pageSize = pageSize,
        pageSpacing = pageSpacing,
        verticalAlignment = verticalAlignment,
        flingBehavior = flingBehavior,
        reverseLayout = false,
        pageNestedScrollConnection = pageNestedScrollConnection,
        snapPosition = snapPosition,
        overscrollEffect = overscrollEffect,
    ) { page ->
        val item = items[page]
        val pageZoomState = rememberZoomableState(zoomSpec = zoomSpec(page, item))
        val pagePlayerState = playerState(page, item)

        LaunchedEffect(pagerState, page, item.previewKey) {
            var wasVisible = pagerState.isPageVisibleInViewport(page)
            snapshotFlow { pagerState.isPageVisibleInViewport(page) }
                .distinctUntilChanged()
                .collect { isVisible ->
                    if (wasVisible && !isVisible) {
                        pageZoomState.resetZoom(animationSpec = SnapSpec())
                    }
                    wasVisible = isVisible
                }
        }

        HorizontalPreviewGestureSurface(
            modifier = Modifier.fillMaxSize(),
            position = page,
            item = item,
            zoomState = pageZoomState,
            backgroundColor = backgroundColor,
            verticalSwipeScale = verticalSwipeScale,
            canVerticalSwipe = canVerticalSwipe,
            onVerticalSwipeGestureChange = { isDismissGestureInProgress = it },
            onVerticalSwipeStart = onVerticalSwipeStart,
            onVerticalSwipe = onVerticalSwipe,
            onVerticalSwipeEnd = onVerticalSwipeEnd,
            onVerticalSwipeAnimationEnd = onVerticalSwipeAnimationEnd
        ) {
            previewItem(
                page,
                item,
                pageZoomState,
                pagePlayerState,
                page == pagerState.currentPage,
                imageLoader
            )
        }
    }
}

/** 预览页面的默认组件集合。 */
object PreviewPagerDefaults {
    /**
     * 根据 [IPreview.isVideo] 分派到默认图片或视频预览组件。
     *
     * @param position 当前页面在预览列表中的索引，传递给底层组件。
     * @param item 待显示的媒体项。
     * @param modifier 应用于页面根容器的修饰符。
     * @param zoomState 当前页面的缩放状态，不应与其他页面共享。
     * @param isCurrentPage 是否为 Pager 当前页，非当前页的视频会暂停并解绑。
     * @param playerState 视频的可观察播放状态；图片页面可传 `null`。
     * @param onClick 单击页面时调用，参数为页面局部坐标。
     * @param onDoubleClick 根据双击信息返回该次双击使用的缩放处理器。
     * @param onLongClick 长按页面时调用，参数为页面局部坐标。
     * @param backgroundColor PlayerView 在视频帧显示前使用的背景色。
     * @param imageLoader 图片和视频封面的 Coil 加载器。
     */
    @Composable
    fun PreviewItem(
        position: Int,
        item: IPreview,
        modifier: Modifier = Modifier,
        zoomState: ZoomableState,
        isCurrentPage: Boolean,
        playerState: PlayerState? = null,
        onClick: ((PreviewClickState) -> Unit)? = null,
        onDoubleClick: (PreviewClickState) -> DoubleClickToZoomListener = { DoubleClickToZoomListener.cycle() },
        onLongClick: ((PreviewClickState) -> Unit)? = null,
        backgroundColor: Color = Color.Black,
        imageLoader: ImageLoader = LocalContext.current.imageLoader
    ) {
        val onItemClick = onClick?.let { callback ->
            { offset: Offset -> callback(PreviewClickState(position, item, offset)) }
        }
        val onItemLongClick = onLongClick?.let { callback ->
            { offset: Offset -> callback(PreviewClickState(position, item, offset)) }
        }
        val onItemDoubleClick = DoubleClickToZoomListener { state, offset ->
            onDoubleClick(PreviewClickState(position, item, offset))
                .onDoubleClick(state, offset)
        }

        if (item.isVideo) {
            ItemVideoPreview(
                item = item,
                zoomableState = zoomState,
                onClick = onItemClick,
                onLongClick = onItemLongClick,
                onDoubleClick = onItemDoubleClick,
                modifier = modifier,
                isCurrentPage = isCurrentPage,
                playerState = playerState ?: remember(item.previewKey) {
                    PlayerState(isAutoPlay = true)
                },
                backgroundColor = backgroundColor,
                imageLoader = imageLoader
            )
        } else {
            ItemImagePreview(
                item = item,
                zoomableState = zoomState,
                onClick = onItemClick,
                onLongClick = onItemLongClick,
                onDoubleClick = onItemDoubleClick,
                modifier = modifier,
                imageLoader = imageLoader
            )
        }
    }
}

/**
 * 处理单页纵向拖动的低层容器。
 *
 * 仅当页面尚未测量缩放值或处于最小缩放附近时才能取得纵向手势。取得手势后不会因缩放
 * 状态变化而中途移交；偏移本身不设边界，仅进度和背景透明度约束到 `0f..1f`。
 *
 * @param position 当前页面在预览列表中的索引。
 * @param item 当前页面对应的媒体项，其 URI 用于保存该页拖动状态。
 * @param zoomState 当前页面的缩放状态，用于判断能否开始纵向手势。
 * @param backgroundColor 页面背景色，透明度会随拖动进度降低。
 * @param verticalSwipeScale 根据当前手势状态计算内容缩放比例，结果会被约束为非负数。
 * @param canVerticalSwipe 手势开始后，判断是否接受当前纵向位移增量。
 * @param onVerticalSwipeGestureChange 纵向手势开始或结束时调用，用于协调外部横向滚动。
 * @param onVerticalSwipeStart 纵向手势取得所有权时调用。
 * @param onVerticalSwipe 纵向偏移发生变化时调用。
 * @param onVerticalSwipeEnd 手势正常结束或取消时调用，并返回结束动画行为。
 * @param onVerticalSwipeAnimationEnd 结束动画完成后调用，状态参数为动画开始前的快照。
 * @param modifier 应用于手势容器的修饰符。
 * @param content 参与缩放和平移的页面内容。
 */
@Composable
fun HorizontalPreviewGestureSurface(
    position: Int,
    item: IPreview,
    zoomState: ZoomableState,
    backgroundColor: Color,
    verticalSwipeScale: (VerticalSwipeState) -> Float,
    canVerticalSwipe: (state: VerticalSwipeState, dragAmountY: Float) -> Boolean,
    onVerticalSwipeGestureChange: (Boolean) -> Unit,
    onVerticalSwipeStart: (VerticalSwipeState) -> Unit,
    onVerticalSwipe: (VerticalSwipeState) -> Unit,
    onVerticalSwipeEnd: (VerticalSwipeState) -> VerticalSwipeEndAction,
    onVerticalSwipeAnimationEnd: (VerticalSwipeState, VerticalSwipeEndAction) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val dismissOffset = remember(item.previewKey) { Animatable(0f) }
    var containerHeight by remember(item.previewKey) { mutableIntStateOf(0) }
    val dismissOffsetY = dismissOffset.value
    val dismissProgress = if (containerHeight > 0) {
        (abs(dismissOffsetY) / containerHeight).coerceIn(0f, 1f)
    } else {
        0f
    }
    val verticalSwipeState = VerticalSwipeState(position, item, dismissProgress, dismissOffsetY)
    val dismissScale = verticalSwipeScale(verticalSwipeState).coerceAtLeast(0f)
    val backgroundAlpha = 1f - dismissProgress
    val canDragToDismiss = (zoomState.zoomFraction ?: 0f) <= MinZoomFractionEpsilon
    val currentCanDragToDismiss by rememberUpdatedState(canDragToDismiss)
    val currentVerticalSwipeState by rememberUpdatedState(verticalSwipeState)
    val currentContainerHeight by rememberUpdatedState(containerHeight)
    val currentCanVerticalSwipe by rememberUpdatedState(canVerticalSwipe)
    val currentOnVerticalSwipeStart by rememberUpdatedState(onVerticalSwipeStart)
    val currentOnVerticalSwipeEnd by rememberUpdatedState(onVerticalSwipeEnd)
    val currentOnVerticalSwipeAnimationEnd by rememberUpdatedState(onVerticalSwipeAnimationEnd)

    LaunchedEffect(position, item, dismissOffsetY, onVerticalSwipe) {
        onVerticalSwipe(verticalSwipeState)
    }

    val verticalSwipeModifier = Modifier.pointerInput(item.previewKey, zoomState) {
        detectVerticalSwipeGestures(
            canStartSwipe = { currentCanDragToDismiss },
            onSwipeStart = {
                onVerticalSwipeGestureChange(true)
                currentOnVerticalSwipeStart(currentVerticalSwipeState)
                coroutineScope.launch {
                    dismissOffset.stop()
                    dismissOffset.snapTo(dismissOffset.value)
                }
            },
            onSwipe = { dragAmount ->
                if (currentCanVerticalSwipe(currentVerticalSwipeState, dragAmount)) {
                    coroutineScope.launch {
                        dismissOffset.snapTo(dismissOffset.value + dragAmount)
                    }
                }
            },
            onSwipeEnd = {
                onVerticalSwipeGestureChange(false)
                val state = currentVerticalSwipeState
                val action = currentOnVerticalSwipeEnd(state)
                val height = currentContainerHeight
                coroutineScope.launch {
                    dismissOffset.applyEndAction(action, height)
                    currentOnVerticalSwipeAnimationEnd(state, action)
                }
            },
            onSwipeCancel = {
                onVerticalSwipeGestureChange(false)
                val state = currentVerticalSwipeState
                val action = currentOnVerticalSwipeEnd(state)
                val height = currentContainerHeight
                coroutineScope.launch {
                    dismissOffset.applyEndAction(action, height)
                    currentOnVerticalSwipeAnimationEnd(state, action)
                }
            }
        )
    }

    Box(
        modifier = modifier
            .background(backgroundColor.copy(alpha = backgroundColor.alpha * backgroundAlpha))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .onSizeChanged { containerHeight = it.height }
                .then(verticalSwipeModifier)
                .layout { measurable, constraints ->
                    val width = (constraints.maxWidth * dismissScale).roundToInt()
                    val height = (constraints.maxHeight * dismissScale).roundToInt()
                    val placeable = measurable.measure(
                        androidx.compose.ui.unit.Constraints.fixed(width, height)
                    )
                    layout(constraints.maxWidth, constraints.maxHeight) {
                        placeable.placeRelative(
                            x = (constraints.maxWidth - width) / 2,
                            y = (constraints.maxHeight - height) / 2 + dismissOffsetY.roundToInt()
                        )
                    }
                }
        ) {
            content()
        }
    }
}

/** URI 同时标识 Pager 页面及其缩放、拖动和播放器状态，列表内必须唯一。 */
private val IPreview.previewKey: Any
    get() = uri.toString()

private const val MinZoomFractionEpsilon = 0.001f
private const val VerticalSwipeAnimationDurationMillis = 250

/**
 * 根据 [action] 对纵向拖动的偏移动画执行结束处理。
 */
private suspend fun Animatable<Float, *>.applyEndAction(
    action: VerticalSwipeEndAction,
    containerHeight: Int
) {
    when (action) {
        VerticalSwipeEndAction.Continue -> {
            val direction = if (value < 0f) -1f else 1f
            animateTo(
                targetValue = direction * max(abs(value), containerHeight.toFloat()),
                animationSpec = tween(VerticalSwipeAnimationDurationMillis)
            )
        }

        VerticalSwipeEndAction.Reset -> animateTo(
            targetValue = 0f,
            animationSpec = tween(VerticalSwipeAnimationDurationMillis)
        )

        VerticalSwipeEndAction.Stay -> Unit
    }
}

/** 判断指定页面是否仍在 Pager 视口内，离开视口后应立即重置其缩放状态。 */
private fun PagerState.isPageVisibleInViewport(page: Int): Boolean {
    val pageInfo = layoutInfo.visiblePagesInfo.firstOrNull { it.index == page } ?: return false
    return pageInfo.offset < layoutInfo.viewportEndOffset &&
           pageInfo.offset + layoutInfo.pageSize > layoutInfo.viewportStartOffset
}
