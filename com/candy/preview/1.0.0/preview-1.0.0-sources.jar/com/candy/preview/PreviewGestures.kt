package com.candy.preview

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.PointerInputScope
import kotlin.math.abs

/**
 * 在纵向累计位移超过 touch slop 且大于横向位移后取得手势。
 *
 * 取得前不消费事件，取得后消费活动指针，并将包含 slop 的累计纵向位移作为首个增量。
 * 多指、活动指针丢失或手势竞争会取消；[canStartSwipe] 只决定是否取得手势。
 *
 * @param canStartSwipe 在每次纵向位移超过阈值后调用，返回 `true` 时取得手势所有权。
 * @param onSwipeStart 手势取得所有权时调用一次。
 * @param onSwipe 每次纵向位移变化时调用，包括初始的累积值。
 * @param onSwipeEnd 手势正常结束时调用（活动指针抬起）。
 * @param onSwipeCancel 手势因多指、指针丢失或竞争取消时调用。
 */
internal suspend fun PointerInputScope.detectVerticalSwipeGestures(
    canStartSwipe: () -> Boolean,
    onSwipeStart: () -> Unit,
    onSwipe: (dragAmount: Float) -> Unit,
    onSwipeEnd: () -> Unit,
    onSwipeCancel: () -> Unit
) {
    val touchSlop = viewConfiguration.touchSlop

    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        var activePointerId = down.id
        var accumulatedX = 0f
        var accumulatedY = 0f
        var isDragging = false

        while (true) {
            val event = awaitPointerEvent()
            if (event.changes.count { it.pressed } > 1) {
                if (isDragging) {
                    onSwipeCancel()
                }
                break
            }

            val change = event.changes.firstOrNull { it.id == activePointerId }
            if (change == null) {
                if (isDragging) {
                    onSwipeCancel()
                }
                break
            }
            val delta = change.position - change.previousPosition
            if (!isDragging) {
                accumulatedX += delta.x
                accumulatedY += delta.y

                val passedVerticalSlop = abs(accumulatedY) > touchSlop && abs(accumulatedY) > abs(
                    accumulatedX
                )
                val shouldStartSwipe = passedVerticalSlop && canStartSwipe()

                if (shouldStartSwipe) {
                    isDragging = true
                    onSwipeStart()
                    change.consume()
                    if (accumulatedY != 0f) {
                        onSwipe(accumulatedY)
                    }
                }
            } else if (delta.y != 0f) {
                onSwipe(delta.y)
                change.consume()
            }

            if (!change.pressed) {
                if (isDragging) {
                    onSwipeEnd()
                } else if (event.changes.any { it.isConsumed }) {
                    onSwipeCancel()
                }
                break
            }
            activePointerId = change.id
        }
    }
}
