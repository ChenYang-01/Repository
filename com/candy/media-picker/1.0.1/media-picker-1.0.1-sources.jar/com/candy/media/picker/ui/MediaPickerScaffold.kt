package com.candy.media.picker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import com.candy.media.picker.model.MediaType

/**
 * 持有并提供可保存 [MediaPickerState] 的媒体选择器布局骨架。
 *
 * 所有 slot 可通过 [LocalMediaPickerProvider] 访问同一状态；[overlay] 覆盖在顶部栏、内容和
 * 底部栏之上。本组件不处理媒体读取权限。
 */
@Composable
fun MediaPickerScaffold(
    modifier: Modifier = Modifier,
    mediaType: MediaType = MediaType.ALL,
    maxSelectCount: Int = Int.MAX_VALUE,
    selectedList: List<String> = emptyList(),
    topBar: @Composable () -> Unit = {},
    bottomBar: @Composable () -> Unit = {},
    overlay: @Composable BoxScope.(provider: MediaPickerProvider) -> Unit = {},
    content: @Composable BoxScope.() -> Unit,
) {
    val state = rememberMediaPickerState(
        maxSelectCount = maxSelectCount,
        mediaType = mediaType,
        selectedList = selectedList,
    )
    val colors = LocalMediaPickerTheme.current

    CompositionLocalProvider(LocalMediaPickerProvider provides state) {
        Box(modifier = modifier.background(colors.statusBarBackground)) {
            Column(modifier = Modifier.fillMaxSize()) {
                topBar()
                Box(modifier = Modifier.weight(1f).background(colors.gridBackground)) {
                    content()
                }
                bottomBar()
            }
            overlay(state)
        }
    }
}
