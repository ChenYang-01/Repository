package com.candy.media.picker.compression

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import androidx.core.content.FileProvider
import androidx.core.graphics.createBitmap
import androidx.core.graphics.scale
import androidx.exifinterface.media.ExifInterface
import com.candy.media.picker.model.MediaData
import com.candy.media.picker.model.MediaPickerResult
import com.candy.media.picker.util.appDirectoryName
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * 媒体选择完成后的压缩器。
 *
 * 回调在调用 [compress] 的协程上下文执行，取消必须继续抛出 [CancellationException]。
 * 回调抛出的异常会终止本次压缩，此时不保证调用 [onCompressionComplete]。
 */
fun interface MediaCompressionEngine {

    val onCompressionStart: (items: List<MediaData>) -> Unit
        get() = {}

    val onCompressionProgress: (progress: MediaCompressionProgress) -> Unit
        get() = {}

    val onCompressionComplete: (result: MediaPickerResult) -> Unit
        get() = {}

    suspend fun compress(context: Context, items: List<MediaData>): MediaPickerResult
}

/**
 * 单个媒体处理完成后的压缩进度。
 *
 * [completed] 是已处理项数；[output] 可能与 [source] 相同，表示该项被跳过或回退。
 * [failure] 仅在压缩发生异常时非空。[fraction] 在空任务时为 `1f`。
 */
data class MediaCompressionProgress(
    val completed: Int,
    val total: Int,
    val source: MediaData,
    val output: MediaData,
    val failure: MediaCompressionFailure? = null,
) {

    val fraction: Float
        get() = if (total == 0) 1f else completed.toFloat() / total
}

/** 压缩失败项及其原始异常；失败项仍应以原媒体出现在最终结果中。 */
data class MediaCompressionFailure(
    val item: MediaData,
    val cause: Throwable,
)

/**
 * 微信风格的串行图片压缩器。
 *
 * 非 GIF 图片会先应用 EXIF 方向，再按长边缩放：普通图片限制为 1280 px，宽高比大于 3
 * 的长图限制为 1920 px。大小已知且不超过 200 KiB、长边不超过 1280 px 的图片，
 * 以及视频和 GIF 均保持原样。输出统一为 JPEG，透明区域使用白色填充；若输出不小于
 * 已知的原文件，则删除输出并回退原媒体。
 */
class WeChatMediaCompressionEngine(
    override val onCompressionStart: (items: List<MediaData>) -> Unit = {},
    override val onCompressionProgress: (progress: MediaCompressionProgress) -> Unit = {},
    override val onCompressionComplete: (result: MediaPickerResult) -> Unit = {},
) : MediaCompressionEngine {

    private companion object {

        const val SMALL_IMAGE_BYTES = 200L * 1024L
        const val NORMAL_LONG_EDGE = 1280
        const val PANORAMA_LONG_EDGE = 1920
        const val PANORAMA_RATIO = 3f
    }

    override suspend fun compress(
        context: Context,
        items: List<MediaData>,
    ): MediaPickerResult {
        onCompressionStart(items)
        val outputItems = ArrayList<MediaData>(items.size)
        val compressedItems = mutableListOf<MediaData>()
        val failures = mutableListOf<MediaCompressionFailure>()

        items.forEachIndexed { index, item ->
            var failure: MediaCompressionFailure? = null
            val output = if (!item.shouldCompress()) {
                item
            } else try {
                val compressed = withContext(Dispatchers.IO) {
                    compressImage(context, item)
                }
                val output = compressed ?: item
                if (compressed != null) compressedItems += compressed
                output
            } catch (cause: CancellationException) {
                throw cause
            } catch (cause: Exception) {
                val compressionFailure = MediaCompressionFailure(item, cause)
                failure = compressionFailure
                failures += compressionFailure
                item
            }
            outputItems += output
            onCompressionProgress(
                MediaCompressionProgress(
                    completed = index + 1,
                    total = items.size,
                    source = item,
                    output = output,
                    failure = failure,
                )
            )
        }

        return MediaPickerResult(
            items = outputItems,
            compressedItems = compressedItems,
            compressedFailures = failures,
        ).also(onCompressionComplete)
    }

    private fun MediaData.shouldCompress(): Boolean {
        val normalizedMimeType = mimeType.lowercase()
        return normalizedMimeType.startsWith("image/") &&
               normalizedMimeType != "image/gif"
    }

    private fun compressImage(
        context: Context,
        item: MediaData,
    ): MediaData? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().also { options ->
            options.inJustDecodeBounds = true
            val input = resolver.openInputStream(item.uri)
                        ?: throw IOException("Cannot open media: ${item.uri}")
            input.use {
                BitmapFactory.decodeStream(input, null, options)
            }
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw IOException("Cannot read image bounds: ${item.uri}")
        }

        val orientation = resolver.openInputStream(item.uri)?.use(::ExifInterface)
                              ?.getAttributeInt(
                                  ExifInterface.TAG_ORIENTATION,
                                  ExifInterface.ORIENTATION_NORMAL,
                              ) ?: ExifInterface.ORIENTATION_NORMAL
        val swapsSides = orientation == ExifInterface.ORIENTATION_ROTATE_90 ||
                         orientation == ExifInterface.ORIENTATION_ROTATE_270 ||
                         orientation == ExifInterface.ORIENTATION_TRANSPOSE ||
                         orientation == ExifInterface.ORIENTATION_TRANSVERSE
        val orientedWidth = if (swapsSides) bounds.outHeight else bounds.outWidth
        val orientedHeight = if (swapsSides) bounds.outWidth else bounds.outHeight
        val shortEdge = minOf(orientedWidth, orientedHeight).coerceAtLeast(1)
        val longEdge = max(orientedWidth, orientedHeight)
        val longEdgeLimit = if (longEdge.toFloat() / shortEdge > PANORAMA_RATIO) {
            PANORAMA_LONG_EDGE
        } else {
            NORMAL_LONG_EDGE
        }
        if (item.size in 1..SMALL_IMAGE_BYTES && longEdge <= NORMAL_LONG_EDGE) {
            return null
        }

        val targetScale = minOf(1f, longEdgeLimit.toFloat() / longEdge)
        val targetWidth = (orientedWidth * targetScale).roundToInt().coerceAtLeast(1)
        val targetHeight = (orientedHeight * targetScale).roundToInt().coerceAtLeast(1)
        val decodeOptions = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inSampleSize = calculateSampleSize(
                width = bounds.outWidth,
                height = bounds.outHeight,
                targetLongEdge = longEdgeLimit,
            )
        }
        val decoded = resolver.openInputStream(item.uri)?.use { input ->
            BitmapFactory.decodeStream(input, null, decodeOptions)
        } ?: throw IOException("Cannot decode image: ${item.uri}")
        val oriented = decoded.applyOrientation(orientation)
        val scaled = if (oriented.width != targetWidth || oriented.height != targetHeight) {
            oriented.scale(targetWidth, targetHeight)
        } else {
            oriented
        }
        val jpegBitmap = scaled.flattenAlpha()
        // 输出位于应用缓存并通过 FileProvider 暴露，可能被系统清理；调用方需要及时消费。
        val outputDirectory = File(
            context.cacheDir,
            "${context.appDirectoryName()}/compressed",
        ).apply { mkdirs() }
        if (!outputDirectory.isDirectory) {
            recycleDistinct(decoded, oriented, scaled, jpegBitmap)
            throw IOException("Cannot create compression cache directory")
        }
        val outputFile = File(
            outputDirectory,
            "CMP_${System.currentTimeMillis()}_${UUID.randomUUID()}.jpg",
        )

        try {
            FileOutputStream(outputFile).use { output ->
                if (!jpegBitmap.compress(Bitmap.CompressFormat.JPEG, item.jpegQuality(), output)) {
                    throw IOException("Cannot compress image: ${item.uri}")
                }
            }
        } catch (cause: Throwable) {
            outputFile.delete()
            throw cause
        } finally {
            recycleDistinct(decoded, oriented, scaled, jpegBitmap)
        }

        if (item.size > 0L && outputFile.length() >= item.size) {
            outputFile.delete()
            return null
        }
        val outputUri = try {
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.candy.media.picker.fileprovider",
                outputFile,
            )
        } catch (cause: Exception) {
            outputFile.delete()
            throw cause
        }
        return item.copy(
            uri = outputUri,
            mimeType = "image/jpeg",
            size = outputFile.length(),
            width = targetWidth,
            height = targetHeight,
            dateModified = System.currentTimeMillis() / 1000L,
        )
    }

    private fun MediaData.jpegQuality(): Int = when {
        size > 5L * 1024L * 1024L -> 70
        size > 2L * 1024L * 1024L -> 75
        else -> 80
    }

    private fun calculateSampleSize(
        width: Int,
        height: Int,
        targetLongEdge: Int,
    ): Int {
        var sampleSize = 1
        while (max(width / (sampleSize * 2), height / (sampleSize * 2)) >= targetLongEdge) {
            sampleSize *= 2
        }
        return sampleSize
    }

    private fun Bitmap.applyOrientation(orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.setScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.setRotate(90f)
                matrix.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.setRotate(-90f)
                matrix.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(-90f)
            else -> return this
        }
        return Bitmap.createBitmap(this, 0, 0, width, height, matrix, true)
    }

    private fun Bitmap.flattenAlpha(): Bitmap {
        if (!hasAlpha()) return this
        return createBitmap(width, height).also { output ->
            Canvas(output).apply {
                drawColor(Color.WHITE)
                drawBitmap(this@flattenAlpha, 0f, 0f, null)
            }
        }
    }

    private fun recycleDistinct(vararg bitmaps: Bitmap) {
        bitmaps.distinctBy(System::identityHashCode).forEach { bitmap ->
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

}
