package com.candy.media.picker.model

import com.candy.media.picker.compression.MediaCompressionFailure

/**
 * 媒体选择结果及可选的压缩明细。
 *
 * [items] 与压缩输入一一对应并保持顺序，每项为压缩输出或原媒体回退。
 * [compressedItems] 只包含实际生成并采用的新文件；跳过压缩或输出未变小时不会加入。
 * [compressedFailures] 只记录异常失败，正常跳过和因输出未变小而回退不算失败。
 */
data class MediaPickerResult(
    val items: List<MediaData>,
    val compressedItems: List<MediaData> = emptyList(),
    val compressedFailures: List<MediaCompressionFailure> = emptyList(),
) {

    companion object {
        /** 创建未经压缩的选择结果。 */
        fun original(items: List<MediaData>): MediaPickerResult = MediaPickerResult(items = items)

        /**
         * 将同一个顶层异常关联到每个输入项，同时保留全部原媒体作为最终 [items]。
         */
        fun compressFailed(
            items: List<MediaData>,
            cause: Throwable,
        ): MediaPickerResult = MediaPickerResult(
            items = items,
            compressedFailures = items.map { item -> MediaCompressionFailure(item, cause) },
        )
    }
}
