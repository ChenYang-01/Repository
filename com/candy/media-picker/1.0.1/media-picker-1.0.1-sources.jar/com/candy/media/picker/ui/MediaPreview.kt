package com.candy.media.picker.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import candy.zoomable.zoomable.DoubleClickToZoomListener
import candy.zoomable.zoomable.Viewport
import candy.zoomable.zoomable.spatial.CoordinateSpace
import coil3.ImageLoader
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import com.candy.media.picker.R
import com.candy.media.picker.model.MediaData
import com.candy.preview.FlingDismissProgressThreshold
import com.candy.preview.FlingDismissVelocityThreshold
import com.candy.preview.HorizontalPreviewContent
import com.candy.preview.IPreview
import com.candy.preview.PlayerState
import com.candy.preview.PreviewPagerDefaults
import com.candy.preview.VerticalSwipeEndAction
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** 顶部栏的状态数据，由 [MediaPreview] 传递给 [MediaPreviewDefaults.TopBar]。 */
data class MediaPreviewTopBarState(
    /** 页面标题，通常为当前页码与总数。 */
    val title: String,
    /** 是否显示选择按钮。 */
    val showSelect: Boolean,
    /** 当前页面是否已被选中。 */
    val selected: Boolean,
    /** 选择按钮的文本标签。 */
    val selectText: String,
    /** 当前页面是否可被选择（受最大选择数量限制）。 */
    val canSelect: Boolean,
    /** 顶部栏的主题配置。 */
    val theme: MediaPreviewTheme,
    /** 点击返回按钮的回调。 */
    val onBack: () -> Unit,
    /** 点击选择按钮的回调。 */
    val onSelect: () -> Unit
)

/** 底部栏的状态数据，由 [MediaPreview] 传递给 [MediaPreviewDefaults.BottomBar]。 */
data class MediaPreviewBottomBarState(
    /** 当前已选择的媒体项列表。 */
    val selectedItems: List<MediaData>,
    /** 已选择数量。 */
    val selectedCount: Int,
    /** 最大可选数量。 */
    val maxCount: Int,
    /** 是否选中原图选项。 */
    val isOriginal: Boolean,
    /** 是否显示原图切换入口。 */
    val showOriginal: Boolean,
    /** 是否显示原图总大小。 */
    val showOriginalSize: Boolean,
    /** 是否显示确认按钮。 */
    val showConfirm: Boolean,
    /** 确认按钮是否显示加载中状态。 */
    val showConfirmProgress: Boolean,
    /** 原图选项的文本标签。 */
    val originalText: String,
    /** 确认按钮的文本标签。 */
    val confirmText: String,
    /** 底部栏的主题配置。 */
    val theme: MediaPreviewTheme,
    /** 点击原图切换的回调。 */
    val onToggleOriginal: () -> Unit,
    /** 点击确认按钮的回调。 */
    val onConfirm: () -> Unit
)

/** 已选缩略图条的状态数据，由 [MediaPreview] 传递给 [MediaPreviewDefaults.SelectedThumbnailStrip]。 */
data class MediaPreviewSelectedThumbnailStripState(
    /** 已选媒体项列表。 */
    val items: List<MediaData>,
    /** 当前正在预览的媒体项，用于高亮。 */
    val currentItem: MediaData,
    /** 缩略图加载器。 */
    val imageLoader: ImageLoader,
    /** 缩略图条的主题配置。 */
    val theme: MediaPreviewTheme,
    /** 点击某项跳转到对应页面的回调。 */
    val onSelect: (MediaData) -> Unit
)

/** [MediaPreview] 的默认配置和预设组件实现。 */
object MediaPreviewDefaults {
    /** 默认预览主题。 */
    val defaultTheme = MediaPreviewTheme()

    /** 默认顶部栏：返回图标 + 居中标题 + 选择按钮。 */
    val TopBar: @Composable (MediaPreviewTopBarState) -> Unit = { state ->
        MediaPreviewTopBar(
            title = state.title,
            showSelect = state.showSelect,
            selected = state.selected,
            selectText = state.selectText,
            canSelect = state.canSelect,
            onBack = state.onBack,
            onSelect = state.onSelect,
            theme = state.theme
        )
    }

    /** 默认底部栏：原图选项 + 确认按钮。 */
    val BottomBar: @Composable (MediaPreviewBottomBarState) -> Unit = { state ->
        MediaPreviewBottomBar(
            selectedItems = state.selectedItems,
            selectedCount = state.selectedCount,
            maxCount = state.maxCount,
            isOriginal = state.isOriginal,
            showOriginal = state.showOriginal,
            showOriginalSize = state.showOriginalSize,
            showConfirm = state.showConfirm,
            showConfirmProgress = state.showConfirmProgress,
            originalText = state.originalText,
            confirmText = state.confirmText,
            theme = state.theme,
            onToggleOriginal = state.onToggleOriginal,
            onConfirm = state.onConfirm
        )
    }

    /** 默认已选缩略图条：水平滚动列表，选中项高亮。 */
    val SelectedThumbnailStrip: @Composable (
        MediaPreviewSelectedThumbnailStripState
    ) -> Unit = { state ->
        DefaultSelectedThumbnailStrip(
            items = state.items,
            currentItem = state.currentItem,
            imageLoader = state.imageLoader,
            theme = state.theme,
            onSelect = state.onSelect
        )
    }

    /**
     * 在“铺满宽度”、最大倍率和初始倍率之间循环。
     *
     * 若铺满宽度与两端倍率过近，则使用初始与最大倍率的几何平均值作为中间级；
     * 5% 容差用于避免浮点误差导致缩放级反复跳动。
     */
    val DoubleClickToZoom = DoubleClickToZoomListener { state, centroid ->
        val transformation = state.contentTransformation.takeIf { it.isSpecified }
                             ?: return@DoubleClickToZoomListener
        val initialScale = transformation.scaleMetadata.initialScale.scaleX
        val currentScale = transformation.scale.scaleX
        val maximumScale = state.zoomSpec.maximum.factor
        val viewportWidth = state.coordinateSystem.viewportSize.width
        val initialContentWidth = with(state.coordinateSystem) {
            unscaledContentBounds(clipToViewport = false)
                .sizeIn(CoordinateSpace.Viewport)
                .width
        }
        if (
            !initialScale.isFinite() ||
            !currentScale.isFinite() ||
            !maximumScale.isFinite() ||
            !viewportWidth.isFinite() ||
            !initialContentWidth.isFinite() ||
            initialScale <= 0f ||
            maximumScale <= initialScale ||
            viewportWidth <= 0f ||
            initialContentWidth <= 0f
        ) {
            return@DoubleClickToZoomListener
        }

        val fillWidthScale = initialScale * viewportWidth / initialContentWidth
        val hasDistinctFillWidthStep =
            fillWidthScale > initialScale * (1f + ZoomStepTolerance) &&
            fillWidthScale < maximumScale * (1f - ZoomStepTolerance)
        val middleScale = if (hasDistinctFillWidthStep) {
            fillWidthScale
        } else {
            sqrt(initialScale * maximumScale)
        }

        when {
            currentScale < middleScale * (1f - ZoomStepTolerance) -> {
                state.zoomTo(zoomFactor = middleScale, centroid = centroid)
            }

            currentScale < maximumScale * (1f - ZoomStepTolerance) -> {
                state.zoomTo(zoomFactor = maximumScale, centroid = centroid)
            }

            else -> state.resetZoom()
        }
    }

    private const val ZoomStepTolerance = 0.05f
}

/**
 * 显示媒体选择器配套的全屏预览。
 *
 * 空列表不生成 UI；外部 [pagerState] 的页数应与 [items] 大小一致。[selectedItems] 和
 * [isOriginal] 是受控状态，相关回调不会直接修改它们。[onConfirm] 传入当前预览项，
 * 而不是完整选择结果。
 *
 * 共享转场仅在 [sharedTransitionScope]、[animatedVisibilityScope] 和当前项非空稳定 key
 * 同时提供时启用，同一列表中的 key 应保持唯一。
 *
 * @param items 待预览的媒体列表。空列表不生成 UI。
 * @param modifier 应用于预览根容器的修饰符。
 * @param initialPage 初始展示的页面索引，超出范围时自动约束。
 * @param pagerState 横向 Pager 状态，其 `pageCount` 应与 [items] 大小一致。
 * @param selectedItems 当前已选择的媒体项列表，受控于外部。
 * @param isOriginal 是否选中原图选项，受控于外部。
 * @param maxSelectCount 最大可选数量，超出后不可继续选择。
 * @param imageLoader 图片和缩略图使用的 Coil 加载器。
 * @param theme 预览的颜色和图标主题配置。
 * @param topBar 顶部栏的自定义实现，接收 [MediaPreviewTopBarState]。
 * @param bottomBar 底部栏的自定义实现，接收 [MediaPreviewBottomBarState]。
 * @param selectedThumbnailStrip 已选缩略图条的自定义实现，接收
 * [MediaPreviewSelectedThumbnailStripState]。
 * @param chromeEnterDelayMillis 控件入场动画的延迟毫秒数。
 * @param chromeModifier 应用于顶部栏和底部栏 AnimatedVisibility 容器的修饰符。
 * @param sharedTransitionScope 共享转场作用域，非空且满足条件时启用共享元素动画。
 * @param animatedVisibilityScope 当前页面在导航图中的 AnimatedVisibilityScope。
 * @param sharedElementKey 根据媒体项生成共享元素的稳定 key，返回非空值且在其他条件满足时启用。
 * @param onDoubleClick 双击预览项时使用的缩放处理器。
 * @param onBack 返回或下拉离场时调用。顶部栏返回和系统返回键均触发此回调。
 * @param onPageChanged 页面切换完成时调用，参数为新页面索引。
 * @param onToggleSelection 选择/取消选择当前页面的回调，参数为当前预览的媒体项。
 * @param onToggleOriginal 切换原图选项的回调。
 * @param onConfirm 确认选择的回调，参数为当前预览的媒体项，不包含完整选择列表。
 */
@Composable
fun MediaPreview(
    items: List<MediaData>,
    modifier: Modifier = Modifier,
    initialPage: Int = 0,
    pagerState: PagerState = rememberPagerState(
        initialPage = safeInitialPage(initialPage, items.size)
    ) { items.size },
    selectedItems: List<MediaData> = emptyList(),
    isOriginal: Boolean = false,
    maxSelectCount: Int = Int.MAX_VALUE,
    imageLoader: ImageLoader = rememberMediaPickerImageLoader(),
    theme: MediaPreviewTheme = MediaPreviewDefaults.defaultTheme,
    topBar: @Composable (MediaPreviewTopBarState) -> Unit = MediaPreviewDefaults.TopBar,
    bottomBar: @Composable (MediaPreviewBottomBarState) -> Unit = MediaPreviewDefaults.BottomBar,
    selectedThumbnailStrip: @Composable (
        MediaPreviewSelectedThumbnailStripState
    ) -> Unit = MediaPreviewDefaults.SelectedThumbnailStrip,
    chromeEnterDelayMillis: Long = 250L,
    chromeModifier: Modifier = Modifier,
    sharedTransitionScope: SharedTransitionScope? = null,
    animatedVisibilityScope: AnimatedVisibilityScope? = null,
    sharedElementKey: ((item: MediaData) -> Any?)? = null,
    onDoubleClick: DoubleClickToZoomListener = MediaPreviewDefaults.DoubleClickToZoom,
    onBack: () -> Unit = {},
    onPageChanged: (page: Int) -> Unit = {},
    onToggleSelection: (item: MediaData) -> Unit = {},
    onToggleOriginal: () -> Unit = {},
    onConfirm: (currentItem: MediaData) -> Unit = {}
) {
    if (items.isEmpty()) return

    val context = LocalContext.current
    val previewItems = remember(context, items) {
        items.map { item ->
            MediaPreviewItem(
                media = item,
                thumbnailRequest = mediaThumbnailRequest(context, item.toMediaThumbnail())
            )
        }
    }
    val currentPage = pagerState.currentPage.coerceIn(0, items.lastIndex)

    LaunchedEffect(pagerState.currentPage) {
        onPageChanged(pagerState.currentPage)
    }

    val currentItem = items[currentPage]
    val selectedCount = selectedItems.size
    val currentSelected = selectedItems.any { it.uri == currentItem.uri }
    val scope = rememberCoroutineScope()
    var chromeVisible by remember { mutableStateOf(false) }
    var chromeHiddenByDrag by remember { mutableStateOf(false) }
    var dragProgress by remember { mutableFloatStateOf(0f) }

    BackHandler {
        chromeVisible = false
        onBack()
    }

    LaunchedEffect(Unit) {
        delay(chromeEnterDelayMillis)
        chromeVisible = true
    }

    LaunchedEffect(items.size, pagerState.currentPage) {
        if (pagerState.currentPage !in items.indices) {
            pagerState.scrollToPage(items.lastIndex.coerceAtLeast(0))
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
    ) {
        HorizontalPreviewContent(
            items = previewItems,
            modifier = Modifier.fillMaxSize(),
            pagerState = pagerState,
            backgroundColor = theme.background,
            playerState = { _, item ->
                if (item.isVideo) {
                    remember(item.uri) { PlayerState(isAutoPlay = false) }
                } else {
                    null
                }
            },
            imageLoader = imageLoader,
            onClick = { chromeVisible = !chromeVisible },
            canVerticalSwipe = { _, _ -> true },
            onVerticalSwipe = { state ->
                dragProgress = if (state.isDownward) state.progress else 0f
                if (state.isDownward && state.progress > 0f && chromeVisible) {
                    chromeHiddenByDrag = true
                    chromeVisible = false
                }
            },
            onVerticalSwipeEnd = { state ->
                dragProgress = 0f
                // 快速向下滑动 或 进度超过阈值 → 退出
                val shouldDismiss = state.isDownward && (
                        state.velocityY >= FlingDismissVelocityThreshold ||
                        state.progress >= FlingDismissProgressThreshold
                                                        )
                if (shouldDismiss) {
                    chromeHiddenByDrag = false
                    onBack()
                    VerticalSwipeEndAction.Stay
                } else {
                    if (chromeHiddenByDrag) {
                        chromeHiddenByDrag = false
                        chromeVisible = true
                    }
                    VerticalSwipeEndAction.Reset
                }
            },
            previewItem = { position, item, zoomState, playerState, isCurrentPage, loader ->
                val mediaItem = items.getOrNull(position)
                val key = if (isCurrentPage && mediaItem != null) {
                    sharedElementKey?.invoke(mediaItem)
                } else {
                    null
                }
                val hasSharedElement = sharedTransitionScope != null &&
                                       animatedVisibilityScope != null &&
                                       key != null
                val isSharedTransitionActive = hasSharedElement && sharedTransitionScope.isTransitionActive
                val isPreviewVisibilityTransitionRunning =
                    animatedVisibilityScope?.transition?.run {
                        currentState != targetState
                    } == true
                val showSharedElement = hasSharedElement &&
                                        (isSharedTransitionActive || isPreviewVisibilityTransitionRunning)
                var sharedElementModifier: Modifier = Modifier
                if (sharedTransitionScope != null && animatedVisibilityScope != null && key != null) {
                    with(sharedTransitionScope) {
                        sharedElementModifier = Modifier.sharedBounds(
                            sharedContentState = rememberSharedContentState(key = key),
                            animatedVisibilityScope = animatedVisibilityScope,
                            enter = EnterTransition.None,
                            exit = fadeOut(tween(1, delayMillis = 299)),
                            boundsTransform = { _, _ ->
                                tween(
                                    durationMillis = 300,
                                    easing = FastOutSlowInEasing
                                )
                            },
                            resizeMode = SharedTransitionScope.ResizeMode.RemeasureToBounds,
                            clipInOverlayDuringTransition = OverlayClip(RectangleShape)
                        )
                    }
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    if (hasSharedElement && mediaItem != null) {
                        MediaPreviewSharedElement(
                            item = mediaItem,
                            modifier = sharedElementModifier,
                            visible = showSharedElement,
                            imageLoader = loader
                        )
                    }

                    if (!item.isVideo || !showSharedElement) {
                        PreviewPagerDefaults.PreviewItem(
                            position = position,
                            item = item,
                            zoomState = zoomState,
                            isCurrentPage = isCurrentPage,
                            modifier = Modifier.alpha(if (showSharedElement) 0f else 1f),
                            playerState = playerState,
                            onClick = { chromeVisible = !chromeVisible },
                            onDoubleClick = { onDoubleClick },
                            onLongClick = null,
                            backgroundColor = theme.background,
                            imageLoader = loader
                        )
                    }

                    AnimatedVisibility(
                        visible = item.isVideo &&
                                  !showSharedElement &&
                                  playerState != null &&
                                  (!playerState.playWhenReady || playerState.isEnded || playerState.hasError) &&
                                  dragProgress == 0f,
                        enter = fadeIn(),
                        exit = fadeOut(),
                        modifier = Modifier.align(Alignment.Center)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(
                                    theme.centerPlayButtonBackground
                                )
                                .clickable { playerState?.play() },
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(
                                    if (playerState?.isEnded == true) {
                                        theme.icons.replay
                                    } else {
                                        theme.icons.play
                                    }
                                ),
                                contentDescription = null,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                }
            }
        )

        AnimatedVisibility(
            visible = chromeVisible,
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it },
            modifier = chromeModifier.align(Alignment.TopCenter)
        ) {
            topBar(
                MediaPreviewTopBarState(
                    title = "${currentPage + 1}/${items.size}",
                    showSelect = true,
                    selected = currentSelected,
                    selectText = stringResource(R.string.picker_select),
                    canSelect = currentSelected || selectedCount < maxSelectCount,
                    theme = theme,
                    onBack = {
                        chromeVisible = false
                        onBack()
                    },
                    onSelect = { onToggleSelection(currentItem) }
                )
            )
        }

        AnimatedVisibility(
            visible = chromeVisible,
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it },
            modifier = chromeModifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(theme.barBackground)
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                if (selectedItems.isNotEmpty()) {
                    selectedThumbnailStrip(
                        MediaPreviewSelectedThumbnailStripState(
                            items = selectedItems,
                            currentItem = currentItem,
                            imageLoader = imageLoader,
                            theme = theme,
                            onSelect = { item ->
                                val index = items.indexOfFirst { it.uri == item.uri }
                                if (index >= 0) {
                                    scope.launch { pagerState.animateScrollToPage(index) }
                                }
                            }
                        )
                    )
                }

                bottomBar(
                    MediaPreviewBottomBarState(
                        selectedItems = selectedItems,
                        selectedCount = selectedCount,
                        maxCount = maxSelectCount,
                        isOriginal = isOriginal,
                        showOriginal = true,
                        showOriginalSize = true,
                        showConfirm = true,
                        showConfirmProgress = false,
                        originalText = stringResource(R.string.picker_original),
                        confirmText = stringResource(R.string.picker_send),
                        theme = theme,
                        onToggleOriginal = onToggleOriginal,
                        onConfirm = {
                            chromeVisible = false
                            onConfirm(currentItem)
                        }
                    )
                )
            }
        }
    }
}

/**
 * 全屏预览的顶部栏。
 *
 * 左侧返回图标、居中标题、右侧选择按钮（可选）。选择按钮在达到最大数量且当前未选中时禁用。
 *
 * @param title 居中显示的标题文本。
 * @param showSelect 是否显示右侧选择按钮。
 * @param selected 当前项是否已选中，控制选择图标的样式。
 * @param selectText 选择按钮的文本标签。
 * @param canSelect 当前项是否可被选中（未达最大数量或已选中）。
 * @param onBack 点击返回图标时的回调。
 * @param onSelect 点击选择按钮时的回调。
 * @param theme 顶部栏的颜色和图标主题。
 * @param modifier 应用于顶部栏根容器的修饰符。
 */
@Composable
fun MediaPreviewTopBar(
    title: String,
    showSelect: Boolean,
    selected: Boolean,
    selectText: String,
    canSelect: Boolean,
    onBack: () -> Unit,
    onSelect: () -> Unit,
    theme: MediaPreviewTheme,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(theme.barBackground)
            .windowInsetsPadding(WindowInsets.statusBars)
            .height(46.dp)
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .fillMaxHeight()
                .clickable(onClick = onBack),
            contentAlignment = Alignment.CenterStart
        ) {
            Icon(
                painter = painterResource(theme.icons.back),
                contentDescription = "Back",
                tint = theme.barContent,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }

        Text(
            text = title,
            color = theme.barContent,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.Center)
        )

        if (showSelect) {
            Row(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .clickable(enabled = canSelect, onClick = onSelect)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    painter = painterResource(
                        if (selected) {
                            theme.icons.originalSelected
                        } else {
                            theme.icons.originalUnselected
                        }
                    ),
                    contentDescription = "Select",
                    tint = when {
                        !canSelect -> theme.disabled
                        selected -> theme.accent
                        else -> theme.disabled
                    },
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = selectText,
                    color = if (canSelect) theme.barContent else theme.disabled,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

/**
 * 全屏预览的底部栏。
 *
 * 左侧可展开区域、中间原图切换入口（可选，选中时显示总大小）、右侧确认按钮。
 *
 * @param selectedItems 当前已选择的媒体项列表，用于计算原图总大小。
 * @param selectedCount 已选择数量。
 * @param maxCount 最大可选数量，显示在确认按钮文本中。
 * @param isOriginal 是否选中原图选项。
 * @param showOriginal 是否显示原图切换入口。
 * @param showOriginalSize 是否为 `true` 且选中原图且有选中项时显示原图总大小。
 * @param showConfirm 是否显示确认按钮。
 * @param showConfirmProgress 确认按钮是否显示 `文本(数量/最大数量)` 格式。
 * @param originalText 原图选项的文本标签。
 * @param confirmText 确认按钮的文本标签。
 * @param theme 底部栏的颜色和图标主题。
 * @param onToggleOriginal 点击原图选项时的回调。
 * @param onConfirm 点击确认按钮时的回调。
 */
@Composable
fun MediaPreviewBottomBar(
    selectedItems: List<MediaData>,
    selectedCount: Int,
    maxCount: Int,
    isOriginal: Boolean,
    showOriginal: Boolean,
    showOriginalSize: Boolean,
    showConfirm: Boolean,
    showConfirmProgress: Boolean,
    originalText: String,
    confirmText: String,
    theme: MediaPreviewTheme,
    onToggleOriginal: () -> Unit,
    onConfirm: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
        )

        if (showOriginal) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .clickable(onClick = onToggleOriginal)
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        painter = painterResource(
                            if (isOriginal) {
                                theme.icons.originalSelected
                            } else {
                                theme.icons.originalUnselected
                            }
                        ),
                        contentDescription = "Original",
                        tint = if (isOriginal) theme.accent else theme.disabled,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.size(4.dp))
                    Text(
                        text = originalText,
                        color = theme.barContent,
                        fontSize = 14.sp
                    )
                }

                if (showOriginalSize && isOriginal && selectedCount > 0) {
                    Text(
                        text = stringResource(
                            R.string.picker_all_size,
                            (selectedItems.sumOf { it.size } / 1024f / 1024f).roundToInt()
                        ),
                        color = theme.barContent,
                        fontSize = 11.sp,
                        maxLines = 1,
                        style = TextStyle(
                            platformStyle = PlatformTextStyle(
                                includeFontPadding = false
                            )
                        ),
                        modifier = Modifier.align(Alignment.BottomCenter)
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
            contentAlignment = Alignment.CenterEnd
        ) {
            if (showConfirm) {
                MediaPreviewConfirmButton(
                    text = confirmText,
                    count = selectedCount,
                    maxCount = maxCount,
                    showConfirmProgress = showConfirmProgress,
                    theme = theme,
                    onClick = onConfirm
                )
            }
        }
    }
}

/**
 * 确认按钮的内部实现。
 *
 * 选中数量为 `0` 时禁用，[showConfirmProgress] 为 `true` 时显示 `文本(数量/最大数量)` 格式。
 *
 * @param text 按钮文本标签。
 * @param count 当前已选数量，为 `0` 时按钮禁用。
 * @param maxCount 最大可选数量。
 * @param showConfirmProgress 是否在按钮文本中显示进度 `(数量/最大数量)`。
 * @param theme 按钮的颜色主题。
 * @param onClick 点击按钮时的回调。
 */
@Composable
private fun MediaPreviewConfirmButton(
    text: String,
    count: Int,
    maxCount: Int,
    showConfirmProgress: Boolean,
    theme: MediaPreviewTheme,
    onClick: () -> Unit,
) {
    Button(
        onClick = onClick,
        enabled = count > 0,
        colors = ButtonDefaults.buttonColors(
            containerColor = theme.accent,
            contentColor = theme.confirmContent,
            disabledContainerColor = theme.accentDisabled,
            disabledContentColor = theme.confirmContent,
        ),
        shape = RoundedCornerShape(4.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        modifier = Modifier.height(32.dp),
    ) {
        val buttonText = if (showConfirmProgress) {
            if (count > 0) "$text($count/$maxCount)" else text
        } else {
            if (count > 0) "$text($count)" else text
        }
        Text(text = buttonText, fontSize = 14.sp)
    }
}

/**
 * 已选媒体项的默认水平缩略图条。
 *
 * 居中滚动到当前预览项，每项 44dp 方形缩略图，视频项叠加播放图标。
 *
 * @param items 已选媒体项列表。
 * @param currentItem 当前预览项，用于高亮和居中滚动。
 * @param imageLoader Coil 图片加载器。
 * @param theme 缩略图条的颜色主题。
 * @param onSelect 点击某项时跳转到对应页面的回调。
 */
@Composable
private fun DefaultSelectedThumbnailStrip(
    items: List<MediaData>,
    currentItem: MediaData,
    imageLoader: ImageLoader,
    theme: MediaPreviewTheme,
    onSelect: (MediaData) -> Unit
) {
    val listState = rememberLazyListState()
    val density = LocalDensity.current
    val selectedIndex = items.indexOfFirst { it.uri == currentItem.uri }

    LaunchedEffect(selectedIndex, items.size) {
        if (selectedIndex >= 0) {
            val viewportWidth = listState.layoutInfo.viewportSize.width
            val itemSizePx = with(density) { 44.dp.roundToPx() }
            if (viewportWidth > 0) {
                listState.animateScrollToItem(
                    index = selectedIndex,
                    scrollOffset = -(viewportWidth / 2 - itemSizePx / 2)
                )
            } else {
                listState.animateScrollToItem(selectedIndex)
            }
        }
    }

    LazyRow(
        state = listState,
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .background(theme.barBackground.copy(alpha = 0.9f))
            .border(width = 0.5.dp, color = theme.divider),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        itemsIndexed(
            items = items,
            key = { _, item -> item.uri }
        ) { _, item ->
            val selected = item.uri == currentItem.uri
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .border(
                        width = if (selected) 2.dp else 0.dp,
                        color = if (selected) theme.accent else Color.Transparent
                    )
                    .padding(if (selected) 2.dp else 0.dp)
                    .clip(RoundedCornerShape(1.dp))
                    .clickable { onSelect(item) }
            ) {
                MediaPreviewThumbnail(
                    item = item,
                    imageLoader = imageLoader,
                    theme = theme,
                    modifier = Modifier.fillMaxSize()
                )
                if (item.isVideo) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(theme.centerPlayButtonBackground),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            painter = painterResource(theme.icons.play),
                            contentDescription = null,
                            tint = theme.onAccent,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MediaPreviewThumbnail(
    item: MediaData,
    imageLoader: ImageLoader,
    theme: MediaPreviewTheme,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val imageRequest = remember(item) {
        mediaThumbnailRequest(context, item.toMediaThumbnail())
    }

    AsyncImage(
        imageLoader = imageLoader,
        model = imageRequest,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = modifier.background(theme.thumbnailBackground)
    )
}

@Composable
private fun MediaPreviewSharedElement(
    item: MediaData,
    modifier: Modifier,
    visible: Boolean,
    imageLoader: ImageLoader
) {
    val context = LocalContext.current
    val imageRequest = remember(item) {
        mediaThumbnailRequest(context, item.toMediaThumbnail())
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val imageAspectRatio = if (item.width > 0 && item.height > 0) {
            item.width.toFloat() / item.height
        } else {
            null
        }
        val imageBoundsModifier =
            imageAspectRatio?.takeIf { it.isFinite() && it > 0f && maxHeight.value > 0f }
                ?.let { aspectRatio ->
                    val viewportAspectRatio = maxWidth.value / maxHeight.value
                    if (aspectRatio >= viewportAspectRatio) {
                        Modifier
                            .align(Alignment.Center)
                            .fillMaxWidth()
                            .aspectRatio(aspectRatio)
                    } else {
                        Modifier
                            .align(Alignment.Center)
                            .fillMaxHeight()
                            .aspectRatio(
                                aspectRatio,
                                matchHeightConstraintsFirst = true
                            )
                    }
                } ?: Modifier.fillMaxSize()

        AsyncImage(
            model = imageRequest,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = imageBoundsModifier.then(modifier),
            imageLoader = imageLoader,
            alignment = Alignment.Center,
            alpha = if (visible) 1f else 0f
        )
    }
}

private data class MediaPreviewItem(
    val media: MediaData,
    val thumbnailRequest: ImageRequest
) : IPreview {
    override val uri = media.uri
    override val isVideo = media.isVideo
    override val thumbnail: Any
        get() = thumbnailRequest
    override val thumbnailWidth: Int
        get() = 256
    override val thumbnailHeight: Int
        get() = 256
}

private fun safeInitialPage(index: Int, size: Int): Int {
    return if (size <= 0) 0 else index.coerceIn(0, size - 1)
}
