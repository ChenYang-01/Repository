package com.candy.media.picker.ui

import androidx.annotation.DrawableRes
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color
import com.candy.media.picker.R

@Immutable
data class MediaPreviewIcons(
    @param:DrawableRes val back: Int = R.drawable.ic_arrow_back_ios_new,
    @param:DrawableRes val play: Int = R.drawable.ic_play_arrow,
    @param:DrawableRes val replay: Int = R.drawable.ic_replay,
    @param:DrawableRes val check: Int = R.drawable.ic_check,
    @param:DrawableRes val originalSelected: Int = R.drawable.ic_check_circle,
    @param:DrawableRes val originalUnselected: Int = R.drawable.ic_radio_button_unchecked,
)

@Immutable
data class MediaPreviewTheme(
    val icons: MediaPreviewIcons = MediaPreviewIcons(),
    val background: Color = Color.Black,
    val barBackground: Color = Color(0xFF1F1F1F),
    val barContent: Color = Color.White,
    val accent: Color = Color(0xFF07C160),
    val disabled: Color = Color(0xFF8C8C8C),
    val divider: Color = Color(0xFF3A3A3A),
    val unselectedBorder: Color = Color.White,
    val onAccent: Color = Color.White,
    val confirmContent: Color = Color.White,
    val accentDisabled: Color = Color(0x8007C160),
    val centerPlayButtonBackground: Color = Color.Black.copy(alpha = 0.35f),
    val thumbnailBackground: Color = Color.Black,
)
