package com.candy.media.picker.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.provider.MediaStore
import com.candy.media.picker.R
import com.candy.media.picker.model.Album
import com.candy.media.picker.model.MediaData
import com.candy.media.picker.model.MediaType

/**
 * 对外部 MediaStore 和通用 `content://` URI 的同步查询封装。
 *
 * 本类不会切换线程或申请权限；调用方应在后台线程调用，并预先取得对应媒体读取权限。
 * 查询结果受系统授予应用的媒体访问范围限制。
 */
class MediaRepository(private val context: Context) {

    private val contentResolver: ContentResolver
        get() = context.contentResolver

    /**
     * 返回当前媒体类型下的非空相册。
     *
     * 有媒体时，首项是 ID 为 `-1` 的“全部”虚拟相册，其封面为按添加时间倒序后的首个媒体；
     * 其余真实相册按名称排序。[MediaType.ALL] 仅包含图片和视频。
     */
    fun getAlbums(mediaType: MediaType = MediaType.ALL): List<Album> {
        val albumsMap = LinkedHashMap<Long, Album>()
        var allMediaCount = 0
        var firstMediaUri: Uri? = null
        var firstMedia: MediaData? = null

        val uri = when (mediaType) {
            MediaType.IMAGE -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            MediaType.VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            MediaType.ALL -> MediaStore.Files.getContentUri("external")
        }

        val selection = buildSelection(mediaType)
        val selectionArgs = buildSelectionArgs(mediaType)
        val sortOrder = "${MediaStore.Files.FileColumns.DATE_ADDED} DESC"

        contentResolver.query(
            uri,
            PROJECTION,
            selection,
            selectionArgs,
            sortOrder
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                val media = cursor.toMediaItem() ?: continue

                // 记录全部媒体的总数和排序后的首个媒体封面。
                allMediaCount++
                if (firstMediaUri == null) {
                    firstMediaUri = media.uri
                    firstMedia = media
                }

                // 归类到具体相册
                val existingAlbum = albumsMap[media.bucketId]
                if (existingAlbum == null) {
                    albumsMap[media.bucketId] = Album(
                        id = media.bucketId,
                        name = media.bucketName.ifEmpty {
                            context.getString(R.string.picker_album_unknown)
                        },
                        coverUri = media.uri,
                        count = 1,
                        mediaType = mediaType,
                        coverMedia = media
                    )
                } else {
                    albumsMap[media.bucketId] = existingAlbum.copy(count = existingAlbum.count + 1)
                }
            }
        }

        val resultAlbums = mutableListOf<Album>()
        // 添加"全部"虚拟相册
        if (allMediaCount > 0) {
            resultAlbums.add(
                Album(
                    id = -1L,
                    name = context.getString(R.string.picker_album_all),
                    coverUri = firstMediaUri,
                    count = allMediaCount,
                    mediaType = mediaType,
                    coverMedia = firstMedia
                )
            )
        }

        // 其他相册按名称排序后加入
        resultAlbums.addAll(albumsMap.values.sortedBy { it.name })
        return resultAlbums
    }

    /**
     * 按添加时间倒序返回指定相册的媒体。
     *
     * [bucketId] 为 `null` 或 `-1` 时不限制相册；[offset] 和 [limit] 会直接传给
     * ContentResolver，调用方应传入非负 offset 和正数 limit。
     */
    fun getMediaList(
        mediaType: MediaType = MediaType.ALL,
        bucketId: Long? = null,
        offset: Int = 0,
        limit: Int = Int.MAX_VALUE
    ): List<MediaData> {
        val items = mutableListOf<MediaData>()
        val uri = when (mediaType) {
            MediaType.IMAGE -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            MediaType.VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            MediaType.ALL -> MediaStore.Files.getContentUri("external")
        }

        // 如果是虚拟的"全部"相册(id=-1)，则忽略 bucketId 过滤
        val actualBucketId = if (bucketId == -1L) null else bucketId

        val selection = buildSelection(mediaType, actualBucketId)
        val selectionArgs = buildSelectionArgs(mediaType, actualBucketId)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val queryArgs = android.os.Bundle().apply {
                putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection)
                putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, selectionArgs)
                putStringArray(
                    ContentResolver.QUERY_ARG_SORT_COLUMNS,
                    arrayOf(MediaStore.Files.FileColumns.DATE_ADDED)
                )
                putInt(
                    ContentResolver.QUERY_ARG_SORT_DIRECTION,
                    ContentResolver.QUERY_SORT_DIRECTION_DESCENDING
                )
                putInt(ContentResolver.QUERY_ARG_OFFSET, offset)
                putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
            }
            contentResolver.query(uri, PROJECTION, queryArgs, null)?.use { cursor ->
                while (cursor.moveToNext()) {
                    cursor.toMediaItem()?.let { items.add(it) }
                }
            }
        } else {
            val sortOrder = "${MediaStore.Files.FileColumns.DATE_ADDED} DESC LIMIT $limit OFFSET $offset"
            contentResolver.query(
                uri,
                PROJECTION,
                selection,
                selectionArgs,
                sortOrder
            )?.use { cursor ->
                while (cursor.moveToNext()) {
                    cursor.toMediaItem()?.let { items.add(it) }
                }
            }
        }
        return items
    }

    /**
     * 根据 URI 解析单个 [MediaData]。
     *
     * 方法优先读取 MediaStore 投影，失败后按通用 ContentProvider 回退。通用回退通常只能
     * 获取 MIME、大小和图片边界，视频时长和相册信息等字段会使用默认值；MIME 未知时返回空。
     */
    fun getMediaItem(uri: Uri): MediaData? {
        val mediaStoreItem = runCatching {
            contentResolver.query(uri, PROJECTION, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.toMediaItem() else null
            }
        }.getOrNull()
        return mediaStoreItem ?: getGenericMediaItem(uri)
    }

    private fun getGenericMediaItem(uri: Uri): MediaData? {
        val mimeType = contentResolver.getType(uri) ?: return null
        var size = 0L
        runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) {
                        size = cursor.getLong(sizeIndex)
                    }
                }
            }
        }

        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        runCatching {
            contentResolver.openInputStream(uri)?.use { input ->
                BitmapFactory.decodeStream(input, null, options)
            }
        }

        return MediaData(
            uri = uri,
            mimeType = mimeType,
            size = size,
            width = options.outWidth.coerceAtLeast(0),
            height = options.outHeight.coerceAtLeast(0),
            dateModified = System.currentTimeMillis() / 1000L,
        )
    }

    private fun buildSelection(mediaType: MediaType, bucketId: Long? = null): String? {
        val parts = mutableListOf<String>()
        when (mediaType) {
            MediaType.IMAGE,
            MediaType.VIDEO -> Unit
            MediaType.ALL -> {
                parts.add(
                    "(${MediaStore.Files.FileColumns.MEDIA_TYPE}=? OR ${MediaStore.Files.FileColumns.MEDIA_TYPE}=?)"
                )
            }
        }
        if (bucketId != null) {
            parts.add("${MediaStore.Files.FileColumns.BUCKET_ID}=?")
        }
        return parts.takeIf { it.isNotEmpty() }?.joinToString(" AND ")
    }

    private fun buildSelectionArgs(mediaType: MediaType, bucketId: Long? = null): Array<String>? {
        val args = mutableListOf<String>()
        when (mediaType) {
            MediaType.IMAGE,
            MediaType.VIDEO -> Unit
            MediaType.ALL -> {
                args.add(MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE.toString())
                args.add(MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO.toString())
            }
        }
        if (bucketId != null) {
            args.add(bucketId.toString())
        }
        return if (args.isEmpty()) null else args.toTypedArray()
    }

    private fun Cursor.toMediaItem(): MediaData? {
        val idIdx = getColumnIndex(MediaStore.Files.FileColumns._ID)
        val mimeIdx = getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE)
        val sizeIdx = getColumnIndex(MediaStore.Files.FileColumns.SIZE)
        val dateModifiedIdx = getColumnIndex(MediaStore.Files.FileColumns.DATE_MODIFIED)
        val bucketIdIdx = getColumnIndex(MediaStore.Files.FileColumns.BUCKET_ID)
        val bucketNameIdx = getColumnIndex(MediaStore.Files.FileColumns.BUCKET_DISPLAY_NAME)
        val widthIdx = getColumnIndex(MediaStore.Files.FileColumns.WIDTH)
        val heightIdx = getColumnIndex(MediaStore.Files.FileColumns.HEIGHT)
        val orientationIdx = getColumnIndex(MediaStore.MediaColumns.ORIENTATION)
        val durationIdx = getColumnIndex(MediaStore.Files.FileColumns.DURATION)

        if (idIdx < 0) return null

        val id = getLong(idIdx)
        val mimeType = if (mimeIdx >= 0) getString(mimeIdx) ?: "image/jpeg" else "image/jpeg"
        val uri = when {
            mimeType.startsWith("video/") -> ContentUris.withAppendedId(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id
            )
            else -> ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
        }
        val rawWidth = if (widthIdx >= 0) getInt(widthIdx) else 0
        val rawHeight = if (heightIdx >= 0) getInt(heightIdx) else 0
        val orientation = if (orientationIdx >= 0) getInt(orientationIdx) else 0
        // MediaStore 尺寸可能尚未应用方向元数据，只交换 90/270 度媒体的展示宽高。
        val normalizedOrientation = ((orientation % 360) + 360) % 360
        val swapsDimensions = normalizedOrientation == 90 || normalizedOrientation == 270

        return MediaData(
            uri = uri,
            mimeType = mimeType,
            size = if (sizeIdx >= 0) getLong(sizeIdx) else 0L,
            bucketId = if (bucketIdIdx >= 0) getLong(bucketIdIdx) else 0L,
            bucketName = if (bucketNameIdx >= 0) getString(bucketNameIdx) ?: "" else "",
            width = if (swapsDimensions) rawHeight else rawWidth,
            height = if (swapsDimensions) rawWidth else rawHeight,
            duration = if (durationIdx >= 0) getLong(durationIdx) else 0L,
            dateModified = if (dateModifiedIdx >= 0) getLong(dateModifiedIdx) else 0L
        )
    }

    companion object {
        private val PROJECTION = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_MODIFIED,
            MediaStore.Files.FileColumns.BUCKET_ID,
            MediaStore.Files.FileColumns.BUCKET_DISPLAY_NAME,
            MediaStore.Files.FileColumns.WIDTH,
            MediaStore.Files.FileColumns.HEIGHT,
            MediaStore.MediaColumns.ORIENTATION,
            MediaStore.Files.FileColumns.DURATION,
        )
    }
}
