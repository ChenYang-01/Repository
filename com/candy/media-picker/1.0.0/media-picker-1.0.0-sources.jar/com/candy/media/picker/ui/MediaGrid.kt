package com.candy.media.picker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.Dp
import com.candy.media.picker.model.MediaData
import kotlinx.coroutines.isActive

@Immutable
class MediaGridItemScope(
    val mediaData: MediaData,
    val isSelected: Boolean,
    val selectionOrder: Int,
    val isScrollInProgress: Boolean = false
)

@Composable
fun MediaGrid(
    itemSpacing: Dp,
    dividerColor: Color,
    modifier: Modifier = Modifier,
    columnCount: Int = 3,
    enableGestureMultiSelect: Boolean = true,
    gridState: LazyGridState = rememberLazyGridState(),
    cameraItem: (@Composable () -> Unit)? = null,
    itemContent: @Composable MediaGridItemScope.() -> Unit,
) {
    val scope = LocalMediaPickerProvider.current
    val mediaList by scope.mediaList.collectAsState()
    val selectedItems by scope.selectedItems.collectAsState()

    val selectionMap = remember(selectedItems) {
        selectedItems.withIndex().associate { it.value.uri to (it.index + 1) }
    }

    var lastProcessedIndex by remember { mutableIntStateOf(-1) }
    var isDragging by remember { mutableStateOf(false) }
    var dragPosition by remember { mutableStateOf(Offset.Unspecified) }
    var gridHeight by remember { mutableIntStateOf(0) }
    val mediaItemIndexOffset = if (cameraItem == null) 0 else 1

    LaunchedEffect(isDragging) {
        if (isDragging) {
            val scrollThreshold = 200f
            val maxScrollDelta = 35f
            while (isActive && isDragging) {
                withFrameMillis { }
                if (dragPosition != Offset.Unspecified && gridHeight > 0) {
                    val y = dragPosition.y
                    val scrollDelta = when {
                        y < scrollThreshold -> -((scrollThreshold - y.coerceAtLeast(0f)) / scrollThreshold) * maxScrollDelta
                        y > gridHeight - scrollThreshold -> ((y.coerceAtMost(gridHeight.toFloat()) - (gridHeight - scrollThreshold)) / scrollThreshold) * maxScrollDelta
                        else -> 0f
                    }
                    if (scrollDelta != 0f) {
                        gridState.scrollBy(scrollDelta)
                        val coercedPosition = dragPosition.copy(y = dragPosition.y.coerceIn(0f, gridHeight.toFloat()))
                        val gridIndex = findItemIndexAt(coercedPosition, gridState)
                        val mediaIndex = gridIndex - mediaItemIndexOffset
                        if (mediaIndex >= 0 && mediaIndex != lastProcessedIndex) {
                            lastProcessedIndex = mediaIndex
                            scope.onGestureSelectRange(mediaIndex, mediaIndex)
                        }
                    }
                }
            }
        }
    }

    LazyVerticalGrid(
        state = gridState,
        columns = GridCells.Fixed(columnCount),
        userScrollEnabled = !isDragging,
        horizontalArrangement = Arrangement.spacedBy(itemSpacing),
        verticalArrangement = Arrangement.spacedBy(itemSpacing),
        modifier = modifier
            .fillMaxSize()
            .background(dividerColor)
            .onSizeChanged { gridHeight = it.height }
            .then(
                if (enableGestureMultiSelect) {
                    Modifier.pointerInput(mediaList.size, mediaItemIndexOffset) {
                        detectHorizontalDragGestures(
                            onDragStart = { offset ->
                                dragPosition = offset
                                val gridIndex = findItemIndexAt(offset, gridState)
                                val mediaIndex = gridIndex - mediaItemIndexOffset
                                if (mediaIndex >= 0) {
                                    isDragging = true
                                    lastProcessedIndex = mediaIndex
                                    scope.onGestureSelectRange(mediaIndex, mediaIndex)
                                }
                            },
                            onDragEnd = {
                                isDragging = false
                                dragPosition = Offset.Unspecified
                                lastProcessedIndex = -1
                                scope.onGestureEnd()
                            },
                            onDragCancel = {
                                isDragging = false
                                dragPosition = Offset.Unspecified
                                lastProcessedIndex = -1
                                scope.onGestureEnd()
                            }
                        ) { change, _ ->
                            change.consume()
                            dragPosition = change.position
                            val gridIndex = findItemIndexAt(change.position, gridState)
                            val mediaIndex = gridIndex - mediaItemIndexOffset
                            if (mediaIndex >= 0 && mediaIndex != lastProcessedIndex) {
                                lastProcessedIndex = mediaIndex
                                scope.onGestureSelectRange(mediaIndex, mediaIndex)
                            }
                        }
                    }
                } else Modifier
            )
    ) {
        if (cameraItem != null) {
            item(
                key = CAMERA_ITEM_KEY,
                contentType = CAMERA_ITEM_CONTENT_TYPE,
            ) {
                cameraItem()
            }
        }
        items(
            count = mediaList.size,
            key = { index -> mediaList[index].uri },
            contentType = { index -> if (mediaList[index].isVideo) 1 else 0 }
        ) { index ->
            val item = mediaList[index]
            val order = selectionMap[item.uri] ?: 0
            val isSelected = order > 0
            val isScrollInProgress = gridState.isScrollInProgress

            val itemScope = remember(item, isSelected, order, isScrollInProgress) {
                MediaGridItemScope(item, isSelected, order, isScrollInProgress)
            }
            itemContent(itemScope)
        }
    }
}

private const val CAMERA_ITEM_KEY = "media-picker-camera-item"
private const val CAMERA_ITEM_CONTENT_TYPE = 2

private fun findItemIndexAt(offset: Offset, state: LazyGridState): Int {
    val layoutInfo = state.layoutInfo
    val visibleItems = layoutInfo.visibleItemsInfo
    if (visibleItems.isEmpty()) return -1

    return visibleItems.find { item ->
        val left = item.offset.x
        val right = item.offset.x + item.size.width
        val top = item.offset.y
        val bottom = item.offset.y + item.size.height
        offset.x >= left && offset.x <= right && offset.y >= top && offset.y <= bottom
    }?.index ?: -1
}
