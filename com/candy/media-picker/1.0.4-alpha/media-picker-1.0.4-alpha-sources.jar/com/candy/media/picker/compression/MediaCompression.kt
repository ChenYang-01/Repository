package com.candy.media.picker.compression

import android.content.Context
import android.graphics.BitmapFactory
import androidx.core.content.FileProvider
import com.candy.media.picker.model.MediaData
import com.candy.media.picker.model.MediaPickerResult
import com.candy.media.picker.util.appDirectoryName
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import top.zibin.luban.api.Luban
import java.io.File
import java.io.IOException

/**
 * 媒体选择完成后的压缩器。
 *
 * 回调在调用 [compress] 的协程上下文执行，取消必须继续抛出 [CancellationException]。
 * 回调抛出的异常会终止本次压缩，此时不保证调用 [onCompressionComplete]。
 */
fun interface MediaCompressionEngine {

    val onCompressionStart: (items: List<MediaData>) -> Unit
        get() = {}

    val onCompressionProgress: (progress: MediaCompressionProgress) -> Unit
        get() = {}

    val onCompressionComplete: (result: MediaPickerResult) -> Unit
        get() = {}

    suspend fun compress(context: Context, items: List<MediaData>): MediaPickerResult
}

/**
 * 单个媒体处理完成后的压缩进度。
 *
 * [completed] 是已处理项数；[output] 可能与 [source] 相同，表示该项被跳过或回退。
 * [failure] 仅在压缩发生异常时非空。[fraction] 在空任务时为 `1f`。
 */
data class MediaCompressionProgress(
    val completed: Int,
    val total: Int,
    val source: MediaData,
    val output: MediaData,
    val failure: MediaCompressionFailure? = null,
) {

    val fraction: Float
        get() = if (total == 0) 1f else completed.toFloat() / total
}

/** 压缩失败项及其原始异常；失败项仍应以原媒体出现在最终结果中。 */
data class MediaCompressionFailure(
    val item: MediaData,
    val cause: Throwable,
)

/** 使用 Luban 2 压缩图片的默认媒体压缩器。视频和 GIF 会保持原样。 */
class LubanMediaCompressionEngine(
    override val onCompressionStart: (items: List<MediaData>) -> Unit = {},
    override val onCompressionProgress: (progress: MediaCompressionProgress) -> Unit = {},
    override val onCompressionComplete: (result: MediaPickerResult) -> Unit = {},
) : MediaCompressionEngine {

    override suspend fun compress(
        context: Context,
        items: List<MediaData>,
    ): MediaPickerResult {
        onCompressionStart(items)
        val outputItems = ArrayList<MediaData>(items.size)
        val compressedItems = mutableListOf<MediaData>()
        val failures = mutableListOf<MediaCompressionFailure>()

        items.forEachIndexed { index, item ->
            var failure: MediaCompressionFailure? = null
            val output = if (!item.shouldCompress()) {
                item
            } else try {
                val compressed = withContext(Dispatchers.IO) {
                    compressImage(context, item)
                }
                val output = compressed ?: item
                if (compressed != null) compressedItems += compressed
                output
            } catch (cause: CancellationException) {
                throw cause
            } catch (cause: Exception) {
                val compressionFailure = MediaCompressionFailure(item, cause)
                failure = compressionFailure
                failures += compressionFailure
                item
            }
            outputItems += output
            onCompressionProgress(
                MediaCompressionProgress(
                    completed = index + 1,
                    total = items.size,
                    source = item,
                    output = output,
                    failure = failure,
                )
            )
        }

        return MediaPickerResult(
            items = outputItems,
            compressedItems = compressedItems,
            compressedFailures = failures,
        ).also(onCompressionComplete)
    }

    private fun MediaData.shouldCompress(): Boolean {
        return mimeType.lowercase().startsWith("image/") && mimeType.lowercase() != "image/gif"
    }

    private suspend fun compressImage(context: Context, item: MediaData): MediaData? {
        val outputDirectory = File(
            context.cacheDir,
            "${context.appDirectoryName()}/compressed",
        ).apply { mkdirs() }
        if (!outputDirectory.isDirectory) {
            throw IOException("Cannot create compression cache directory")
        }

        val outputFile = Luban.compress(context, item.uri, outputDirectory).getOrThrow()

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(outputFile.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            outputFile.delete()
            throw IOException("Cannot read compressed image bounds: ${item.uri}")
        }

        val outputUri = try {
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.candy.media.picker.fileprovider",
                outputFile,
            )
        } catch (cause: Exception) {
            outputFile.delete()
            throw cause
        }
        return item.copy(
            uri = outputUri,
            mimeType = "image/jpeg",
            size = outputFile.length(),
            width = bounds.outWidth,
            height = bounds.outHeight,
            dateModified = System.currentTimeMillis() / 1000L,
        )
    }
}