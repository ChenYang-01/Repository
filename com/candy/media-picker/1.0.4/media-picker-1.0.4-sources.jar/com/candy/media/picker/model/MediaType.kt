package com.candy.media.picker.model

enum class MediaType {
    /** 图片 */
    IMAGE,

    /** 视频 */
    VIDEO,

    /** 图片和视频 */
    ALL
}
