package com.candy.media.picker.model

import android.net.Uri
import android.os.Parcelable
import androidx.compose.runtime.Immutable
import kotlinx.parcelize.Parcelize

/**
 * 可供选择的单个媒体项。
 *
 * [size] 的单位为字节，[width] 和 [height] 通常是展示方向下的像素尺寸，[duration]
 * 的单位为毫秒，[dateModified] 是 Unix 秒。无法获取的数值使用 `0`，空相册信息表示来源
 * 不提供该元数据。[uri] 可能来自 MediaStore、其他 ContentProvider 或临时 FileProvider，
 * 其访问期限和授权由 URI 来源决定。
 */
@Parcelize
@Immutable
data class MediaData(
    val uri: Uri,
    val mimeType: String,
    val size: Long = 0,
    val bucketId: Long = 0,
    val bucketName: String = "",
    val width: Int = 0,
    val height: Int = 0,
    val duration: Long = 0L,
    val dateModified: Long = 0L
) : Parcelable {
    val isVideo: Boolean
        get() = mimeType.startsWith("video/")

    val isImage: Boolean
        get() = mimeType.startsWith("image/")
}
