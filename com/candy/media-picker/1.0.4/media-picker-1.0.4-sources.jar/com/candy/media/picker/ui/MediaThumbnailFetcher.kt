package com.candy.media.picker.ui

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import coil3.ImageLoader
import coil3.asImage
import coil3.decode.DataSource
import coil3.decode.ImageSource
import coil3.disk.DiskCache
import coil3.disk.directory
import coil3.fetch.FetchResult
import coil3.fetch.Fetcher
import coil3.fetch.ImageFetchResult
import coil3.fetch.SourceFetchResult
import coil3.request.ImageRequest
import coil3.request.Options
import com.candy.media.picker.model.MediaData
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.roundToInt
import androidx.core.graphics.scale

private const val THUMBNAIL_SIZE = 256
private const val THUMBNAIL_CACHE_VERSION = 2
private const val THUMBNAIL_CACHE_MAX_SIZE = 150L * 1024 * 1024
private const val THUMBNAIL_COMPRESSION_QUALITY = 85
private const val THUMBNAIL_MIME_TYPE = "image/webp"
private const val VIDEO_THUMBNAIL_FRAME_MICROS = 1_000L

internal data class MediaThumbnail(
    val uri: Uri,
    val isVideo: Boolean,
    val dateModified: Long,
    val sourceSize: Long
) {
    /**
     * 缓存键包含 URI、媒体类型、修改秒数、源大小和格式版本；修改时间与大小均未知时，
     * 无法可靠识别同一 URI 的内容替换。
     */
    val cacheKey: String = buildString {
        append("media-picker-thumbnail-v")
        append(THUMBNAIL_CACHE_VERSION)
        append(':')
        append(uri)
        append(':')
        append(isVideo)
        append(':')
        append(dateModified)
        append(':')
        append(sourceSize)
        append(':')
        append(THUMBNAIL_SIZE)
    }
}

internal fun MediaData.toMediaThumbnail() = MediaThumbnail(
    uri = uri,
    isVideo = isVideo,
    dateModified = dateModified,
    sourceSize = size
)

internal fun Uri.toMediaThumbnail(): MediaThumbnail {
    return MediaThumbnail(
        uri = this,
        isVideo = pathSegments.any { it == "video" },
        dateModified = 0L,
        sourceSize = 0L
    )
}

internal fun mediaThumbnailRequest(
    context: Context,
    thumbnail: MediaThumbnail
): ImageRequest = ImageRequest.Builder(context)
    .data(thumbnail)
    .memoryCacheKey(thumbnail.cacheKey)
    .fetcherFactory(MediaThumbnailFetcher.Factory)
    .fetcherCoroutineContext(mediaPickerImageCoroutineContext)
    .size(THUMBNAIL_SIZE)
    .build()

private class MediaThumbnailFetcher(
    private val context: Context,
    private val data: MediaThumbnail,
    private val options: Options
) : Fetcher {

    override suspend fun fetch(): FetchResult {
        val cache = MediaThumbnailDiskCache.get(context)
        val cachePolicy = options.diskCachePolicy

        if (cachePolicy.readEnabled) {
            cache.openSnapshot(data.cacheKey)?.let { return it.toFetchResult(cache) }
        }

        // 32 路 Mutex 避免同一缓存槽重复生成；哈希碰撞只会使不同媒体暂时串行。
        val lock = thumbnailLocks[data.cacheKey.hashCode().and(Int.MAX_VALUE) % thumbnailLocks.size]
        return lock.withLock {
            if (cachePolicy.readEnabled) {
                cache.openSnapshot(data.cacheKey)?.let { return@withLock it.toFetchResult(cache) }
            }

            val bitmap = createThumbnail()
            if (!cachePolicy.writeEnabled) {
                return@withLock bitmap.toFetchResult()
            }

            val editor = cache.openEditor(data.cacheKey)
                ?: return@withLock bitmap.toFetchResult()
            try {
                cache.fileSystem.write(editor.data) {
                    check(
                        bitmap.compress(
                            thumbnailCompressFormat(),
                            THUMBNAIL_COMPRESSION_QUALITY,
                            outputStream()
                        )
                    ) { "Unable to encode thumbnail for '${data.uri}'." }
                }
                val snapshot = editor.commitAndOpenSnapshot()
                if (snapshot == null) {
                    bitmap.toFetchResult()
                } else {
                    bitmap.recycle()
                    snapshot.toFetchResult(cache)
                }
            } catch (throwable: Throwable) {
                editor.abort()
                bitmap.recycle()
                throw throwable
            }
        }
    }

    private fun createThumbnail(): Bitmap {
        val bitmap = if (data.isVideo) {
            createVideoThumbnail()
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            context.contentResolver.loadThumbnail(
                data.uri,
                Size(THUMBNAIL_SIZE, THUMBNAIL_SIZE),
                null
            )
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Thumbnails.getThumbnail(
                context.contentResolver,
                ContentUris.parseId(data.uri),
                MediaStore.Images.Thumbnails.MINI_KIND,
                null
            )
        }

        return checkNotNull(bitmap) { "Unable to create thumbnail for '${data.uri}'." }
            .scaledForCache()
            .copyToSoftwareBitmap()
    }

    private fun createVideoThumbnail(): Bitmap? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, data.uri)
            val rotation = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                ?.toIntOrNull()
                ?: 0
            val rawWidth = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull()
                ?: 0
            val rawHeight = retriever
                .extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull()
                ?: 0
            val sourceWidth = if (rotation == 90 || rotation == 270) rawHeight else rawWidth
            val sourceHeight = if (rotation == 90 || rotation == 270) rawWidth else rawHeight

            if (
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1 &&
                sourceWidth > 0 &&
                sourceHeight > 0
            ) {
                val scale = minOf(
                    THUMBNAIL_SIZE.toFloat() / sourceWidth,
                    THUMBNAIL_SIZE.toFloat() / sourceHeight
                )
                // 优先提取约 1 ms 处的同步帧，并在解码阶段缩小高分辨率视频。
                retriever.getScaledFrameAtTime(
                    VIDEO_THUMBNAIL_FRAME_MICROS,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                    (sourceWidth * scale).roundToInt().coerceAtLeast(1),
                    (sourceHeight * scale).roundToInt().coerceAtLeast(1)
                )
            } else {
                retriever.getFrameAtTime(
                    VIDEO_THUMBNAIL_FRAME_MICROS,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                )
            }
        } finally {
            retriever.release()
        }
    }

    private fun DiskCache.Snapshot.toFetchResult(cache: DiskCache) = SourceFetchResult(
        source = ImageSource(
            file = data,
            fileSystem = cache.fileSystem,
            closeable = this
        ),
        mimeType = THUMBNAIL_MIME_TYPE,
        dataSource = DataSource.DISK
    )

    private fun Bitmap.toFetchResult() = ImageFetchResult(
        image = asImage(),
        isSampled = true,
        dataSource = DataSource.DISK
    )

    object Factory : Fetcher.Factory<MediaThumbnail> {
        override fun create(
            data: MediaThumbnail,
            options: Options,
            imageLoader: ImageLoader
        ): Fetcher = MediaThumbnailFetcher(
            context = options.context.applicationContext,
            data = data,
            options = options
        )
    }
}

private fun Bitmap.scaledForCache(): Bitmap {
    val largestDimension = maxOf(width, height)
    if (largestDimension <= THUMBNAIL_SIZE) return this

    val scale = THUMBNAIL_SIZE.toFloat() / largestDimension
    val scaled = this.scale(
        (width * scale).roundToInt().coerceAtLeast(1),
        (height * scale).roundToInt().coerceAtLeast(1)
    )
    if (scaled !== this) recycle()
    return scaled
}

private fun Bitmap.copyToSoftwareBitmap(): Bitmap {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || config != Bitmap.Config.HARDWARE) {
        return this
    }

    val softwareBitmap = copy(Bitmap.Config.ARGB_8888, false)
    recycle()
    return checkNotNull(softwareBitmap) { "Unable to copy hardware thumbnail to software." }
}

@Suppress("DEPRECATION")
private fun thumbnailCompressFormat(): Bitmap.CompressFormat =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Bitmap.CompressFormat.WEBP_LOSSY
    } else {
        Bitmap.CompressFormat.WEBP
    }

private object MediaThumbnailDiskCache {
    @Volatile
    private var instance: DiskCache? = null

    // 进程级 150 MiB 缓存位于 cacheDir，由系统负责空间回收，本模块不主动关闭。
    fun get(context: Context): DiskCache = instance ?: synchronized(this) {
        instance ?: DiskCache.Builder()
            .directory(context.cacheDir.resolve("media_picker_thumbnails"))
            .maxSizeBytes(THUMBNAIL_CACHE_MAX_SIZE)
            .build()
            .also { instance = it }
    }
}

private val thumbnailLocks = Array(32) { Mutex() }
