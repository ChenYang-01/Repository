package com.candy.media.picker

import androidx.core.content.FileProvider

class CandyMediaPickerProvider : FileProvider()