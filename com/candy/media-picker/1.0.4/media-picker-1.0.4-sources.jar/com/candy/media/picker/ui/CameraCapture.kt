package com.candy.media.picker.ui

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.candy.media.picker.util.appDirectoryName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.UUID

internal enum class MediaCaptureType(
    val filePrefix: String,
    val fileExtension: String,
    val mimeType: String,
    val publicDirectory: String,
    val collectionUri: Uri,
) {
    PHOTO(
        filePrefix = "IMG",
        fileExtension = "jpg",
        mimeType = "image/jpeg",
        publicDirectory = Environment.DIRECTORY_PICTURES,
        collectionUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
    ),
    VIDEO(
        filePrefix = "VID",
        fileExtension = "mp4",
        mimeType = "video/mp4",
        publicDirectory = Environment.DIRECTORY_MOVIES,
        collectionUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
    ),
}

internal data class CameraOutput(
    val uri: Uri,
    val filePath: String,
    val type: MediaCaptureType,
)

internal fun createCameraOutput(
    context: Context,
    type: MediaCaptureType,
): CameraOutput? {
    // 相机先写入应用专属占位文件，再通过 FileProvider 获得临时可写 URI。
    val appDirectoryName = context.appDirectoryName()
    val externalDirectory = context.getExternalFilesDir(type.publicDirectory)
    val directory = if (externalDirectory != null) {
        File(externalDirectory, appDirectoryName)
    } else {
        File(context.filesDir, appDirectoryName)
    }
    if (!directory.exists() && !directory.mkdirs()) return null

    val file = File(directory, cameraFileName(type))
    if (!runCatching { file.createNewFile() }.getOrDefault(false)) return null

    val uri = cameraFileUri(context, file) ?: run {
        file.delete()
        return null
    }
    return CameraOutput(uri = uri, filePath = file.absolutePath, type = type)
}

internal fun discardCameraOutput(localFilePath: String) {
    runCatching { File(localFilePath).delete() }
}

internal suspend fun completeCameraOutput(
    context: Context,
    localFilePath: String,
    type: MediaCaptureType,
): Uri? = withContext(Dispatchers.IO) {
    val file = File(localFilePath)
    if (!file.isFile || file.length() <= 0L) {
        file.delete()
        return@withContext null
    }

    // 成功发布到 MediaStore 后删除本地文件；失败则保留文件并回退 FileProvider URI。
    val mediaStoreUri = copyToMediaStore(context, file, type)
    if (mediaStoreUri != null) {
        file.delete()
        return@withContext mediaStoreUri
    }

    cameraFileUri(context, file)
}

private fun copyToMediaStore(
    context: Context,
    file: File,
    type: MediaCaptureType,
): Uri? {
    val now = System.currentTimeMillis()
    val appDirectoryName = context.appDirectoryName()
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
        put(MediaStore.MediaColumns.MIME_TYPE, type.mimeType)
        put(MediaStore.MediaColumns.DATE_ADDED, now / 1000L)
        put(MediaStore.MediaColumns.DATE_TAKEN, now)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ 先以 pending 状态写入，复制完成后再发布给其他应用。
            put(
                MediaStore.MediaColumns.RELATIVE_PATH,
                cameraRelativePath(type, appDirectoryName),
            )
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        } else {
            @Suppress("DEPRECATION")
            val directory = File(
                Environment.getExternalStoragePublicDirectory(type.publicDirectory),
                appDirectoryName,
            )
            if (!directory.exists() && !directory.mkdirs()) return null
            put(MediaStore.MediaColumns.DATA, File(directory, file.name).absolutePath)
        }
    }

    val resolver = context.contentResolver
    val insertedUri = runCatching {
        resolver.insert(type.collectionUri, values)
    }.getOrNull() ?: return null

    val copied = runCatching {
        resolver.openOutputStream(insertedUri, "w")?.use { output ->
            file.inputStream().use { input ->
                input.copyTo(output)
            }
        } != null
    }.getOrDefault(false)
    if (!copied) {
        runCatching { resolver.delete(insertedUri, null, null) }
        return null
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val publishValues = ContentValues().apply {
            put(MediaStore.MediaColumns.IS_PENDING, 0)
        }
        val published = runCatching {
            resolver.update(insertedUri, publishValues, null, null) > 0
        }.getOrDefault(false)
        if (!published) {
            runCatching { resolver.delete(insertedUri, null, null) }
            return null
        }
    }

    return insertedUri
}

private fun cameraFileUri(context: Context, file: File): Uri? {
    return runCatching {
        FileProvider.getUriForFile(
            context,
            "${context.packageName}.candy.media.picker.fileprovider",
            file,
        )
    }.getOrNull()
}

private fun cameraFileName(type: MediaCaptureType): String {
    val timestamp = LocalDateTime.now().format(CAMERA_TIMESTAMP_FORMAT)
    return "${type.filePrefix}_${timestamp}_${UUID.randomUUID()}.${type.fileExtension}"
}

private fun cameraRelativePath(
    type: MediaCaptureType,
    appDirectoryName: String,
): String {
    return "${type.publicDirectory}/$appDirectoryName"
}

private val CAMERA_TIMESTAMP_FORMAT = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")
