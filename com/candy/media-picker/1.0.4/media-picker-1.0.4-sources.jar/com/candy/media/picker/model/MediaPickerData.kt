package com.candy.media.picker.model

import android.net.Uri
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import java.io.File

/**
 * 单个媒体选择结果及可选的压缩文件。
 *
 * [compressedUri] 和 [compressedFile] 只在实际生成压缩文件时有值。
 */
@Parcelize
data class MediaPickerData(
    val uri: Uri,
    val mimeType: String,
    val size: Long = 0,
    val width: Int = 0,
    val height: Int = 0,
    val duration: Long = 0L,
    val compressedUri: Uri? = null,
    val compressedFile: File? = null,
) : Parcelable
