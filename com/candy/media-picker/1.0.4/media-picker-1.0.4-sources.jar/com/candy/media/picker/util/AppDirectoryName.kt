package com.candy.media.picker.util

import android.content.Context

internal fun Context.appDirectoryName(): String {
    val appName = applicationInfo
        .loadLabel(packageManager)
        .toString()
        .trim()
        .replace(Regex("""[\\/:*?"<>|\u0000-\u001F]"""), "_")
        .trim('.')
    return appName.ifBlank { packageName }
}
