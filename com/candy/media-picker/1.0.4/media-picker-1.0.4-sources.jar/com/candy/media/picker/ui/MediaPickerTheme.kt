package com.candy.media.picker.ui

import androidx.annotation.DrawableRes
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.candy.media.picker.R

@Immutable
data class MediaPickerIcons(
    @param:DrawableRes val back: Int = R.drawable.ic_arrow_back_ios_new,
    @param:DrawableRes val camera: Int = R.drawable.ic_photo_camera,
    @param:DrawableRes val albumExpanded: Int = R.drawable.ic_keyboard_arrow_up,
    @param:DrawableRes val albumCollapsed: Int = R.drawable.ic_keyboard_arrow_down,
    @param:DrawableRes val check: Int = R.drawable.ic_check,
    @param:DrawableRes val originalSelected: Int = R.drawable.ic_check_circle,
    @param:DrawableRes val originalUnselected: Int = R.drawable.ic_radio_button_unchecked,
)

@Immutable
data class MediaPickerTheme(
    /** 顶部栏、底部栏和相册列表背景。 */
    val statusBarBackground: Color = Color.White,
    /** 顶部栏、底部栏的文字和图标颜色。 */
    val statusBarContent: Color = Color(0xFF1A1A1A),
    /** 媒体网格背景。 */
    val gridBackground: Color = Color(0xFFF2F2F2),
    /** 选中状态、确认按钮等强调元素的颜色。 */
    val accent: Color = Color(0xFF07C160),
    /** 禁用或未选中元素的颜色。 */
    val disabled: Color = Color(0xFF8C8C8C),
    /** 图片加载占位颜色。 */
    val placeholder: Color = Color(0xFFE5E5E5),
    /** 相机入口网格项的背景颜色。 */
    val cameraBackground: Color = placeholder,
    /** 相册列表遮罩颜色。 */
    val overlay: Color = Color(0x80000000),
    /** 未选中圆圈的描边颜色。 */
    val unselectedBorder: Color = Color.White,
    /** 未选中圆圈的背景颜色。 */
    val unselectedBackground: Color = Color(0x33000000),
    /** 强调色之上的文字和图标颜色。 */
    val onAccent: Color = Color.White,
    /** 相册列表次要文字颜色。 */
    val albumSecondaryText: Color = Color(0xFF737373),
    /** 相册列表分割线颜色。 */
    val albumDivider: Color = Color(0xFFE5E5E5),
    /** 确认按钮文字颜色。 */
    val onAccentButton: Color = Color.White,
    /** 确认按钮禁用状态的背景颜色。 */
    val accentDisabled: Color = Color(0x8007C160),
    val icons: MediaPickerIcons = MediaPickerIcons(),
    val previewTheme: MediaPreviewTheme = MediaPreviewTheme(
        icons = MediaPreviewIcons(
            back = icons.back,
            check = icons.check,
            originalSelected = icons.originalSelected,
            originalUnselected = icons.originalUnselected,
        ),
        background = gridBackground,
        barBackground = statusBarBackground,
        barContent = statusBarContent,
        accent = accent,
        disabled = disabled,
        divider = albumDivider,
        unselectedBorder = unselectedBorder,
        onAccent = onAccent,
        onAccentButton = onAccentButton,
        accentDisabled = accentDisabled,
        thumbnailBackground = placeholder,
    ),
)

val LocalMediaPickerTheme = staticCompositionLocalOf { MediaPickerDefaults.darkTheme }
