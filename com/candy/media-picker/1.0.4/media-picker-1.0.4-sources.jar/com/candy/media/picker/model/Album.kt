package com.candy.media.picker.model

import android.net.Uri

/**
 * 媒体相册摘要。
 *
 * [id] 为 `-1` 时表示虚拟“全部”相册。[mediaType] 是生成相册列表时使用的过滤条件；
 * [coverMedia] 提供完整封面元数据，[coverUri] 是仅需地址时的兼容字段。
 */
data class Album(
    val id: Long,
    val name: String,
    val coverUri: Uri?,
    val count: Int,
    val mediaType: MediaType,
    val coverMedia: MediaData? = null
)
