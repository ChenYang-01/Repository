package com.candy.media.picker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.res.painterResource
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.ColorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.ImageLoader
import coil3.compose.AsyncImage
import com.candy.media.picker.R
import com.candy.media.picker.model.MediaData

@Composable
fun CameraGridItem(
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {},
) {
    val colors = LocalMediaPickerTheme.current
    Box(
        modifier = modifier
            .aspectRatio(1f)
            .background(colors.cameraBackground)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(colors.icons.camera),
            contentDescription = stringResource(R.string.picker_camera),
            tint = colors.statusBarContent,
            modifier = Modifier.size(32.dp),
        )
    }
}

/**
 * 显示媒体网格中的单个方形项目，包括缩略图、视频时长和选择指示器。
 *
 * @param item 待显示的媒体数据。
 * @param selected 当前项目是否已选中。
 * @param selectionOrder 当前项目的选择顺序，通常从 1 开始。
 * @param modifier 应用于整个方形网格项目的修饰符。
 * @param imageModifier 仅应用于缩略图或占位层的修饰符。
 * @param imageLoader 缩略图使用的 Coil 加载器。
 * @param showSelectionOrder 选中时是否显示 [selectionOrder]；为 `false` 时显示勾选图标。
 * @param onClick 点击网格项目主体时调用。
 * @param onSelectionClick 点击右上角选择指示器时调用。
 * @param deferVideoFrameLoading 是否延迟加载视频帧；为 `true` 时显示占位，直到参数变为
 * `false` 后才开始加载。
 */
@Composable
fun MediaGridItem(
    item: MediaData,
    selected: Boolean,
    selectionOrder: Int,
    modifier: Modifier = Modifier,
    imageModifier: Modifier = Modifier,
    imageLoader: ImageLoader = rememberMediaPickerImageLoader(),
    showSelectionOrder: Boolean = true,
    onClick: () -> Unit = {},
    onSelectionClick: () -> Unit = {},
    deferVideoFrameLoading: Boolean = false
) {
    val context = LocalContext.current
    val colors = LocalMediaPickerTheme.current
    var thumbnailLoaded by rememberSaveable(item.uri) {
        mutableStateOf(false)
    }
    var thumbnailLoadStarted by rememberSaveable(item.uri) {
        mutableStateOf(!item.isVideo || !deferVideoFrameLoading)
    }

    LaunchedEffect(item.uri, deferVideoFrameLoading) {
        if (!deferVideoFrameLoading) {
            thumbnailLoadStarted = true
        }
    }

    val imageRequest = remember(item) {
        mediaThumbnailRequest(context, item.toMediaThumbnail())
    }

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clickable(onClick = onClick)
    ) {
        // 缩略图层
        if (thumbnailLoadStarted) {
            AsyncImage(
                imageLoader = imageLoader,
                model = imageRequest,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                placeholder = if (thumbnailLoaded) null else ColorPainter(colors.placeholder),
                onSuccess = { thumbnailLoaded = true },
                modifier = imageModifier.fillMaxSize()
            )
        } else {
            Box(
                modifier = imageModifier
                    .fillMaxSize()
                    .background(colors.placeholder)
            )
        }

        // 视频时长
        if (item.mimeType.startsWith("video/")) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color(0x66000000)),
                            startY = 0.6f
                        )
                    )
            ) {
                val durationText = remember(item.duration) {
                    val totalSeconds = item.duration / 1000
                    val minutes = totalSeconds / 60
                    val seconds = totalSeconds % 60
                    "%02d:%02d".format(minutes, seconds)
                }
                Text(
                    text = durationText,
                    color = colors.onAccent,
                    fontSize = 10.sp,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 6.dp, bottom = 4.dp)
                )
            }
        }

        // 选中状态层
        SelectionIndicator(
            selected = selected,
            order = selectionOrder,
            showSelectionOrder = showSelectionOrder,
            onClick = onSelectionClick,
            modifier = Modifier.align(Alignment.TopEnd)
        )
    }
}

@Composable
private fun SelectionIndicator(
    selected: Boolean,
    order: Int,
    showSelectionOrder: Boolean,
    onClick: () -> Unit,
    modifier: Modifier
) {
    val colors = LocalMediaPickerTheme.current
    Box(
        modifier = modifier
            .padding(6.dp)
            .size(24.dp)
            .clickable(onClick = onClick)
            .clip(CircleShape)
            .background(if (selected) colors.accent else colors.unselectedBackground)
            .then(
                if (!selected) Modifier.border(
                    1.5.dp, colors.unselectedBorder, CircleShape
                ) else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            if (showSelectionOrder) {
                Text(
                    text = order.toString(),
                    color = colors.onAccent,
                    style = MaterialTheme.typography.labelSmall
                )
            } else {
                Icon(
                    painter = painterResource(colors.icons.check),
                    contentDescription = null,
                    tint = colors.onAccent,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}
