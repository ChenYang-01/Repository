package com.candy.media.picker.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import coil3.ImageLoader
import coil3.video.VideoFrameDecoder
import kotlinx.coroutines.Dispatchers

val videoFrameDecoder = VideoFrameDecoder.Factory()
internal val mediaPickerImageCoroutineContext = Dispatchers.IO.limitedParallelism(2)

@Composable
fun rememberMediaPickerImageLoader(): ImageLoader {
    val context = LocalContext.current
    return remember(context) {
        ImageLoader.Builder(context)
            .decoderCoroutineContext(mediaPickerImageCoroutineContext)
            .components {
                add(videoFrameDecoder)
            }
            .build()
    }
}
