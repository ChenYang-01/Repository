package com.candy.media.picker.ui

import android.net.Uri
import androidx.compose.runtime.Stable
import androidx.compose.runtime.staticCompositionLocalOf
import com.candy.media.picker.model.Album
import com.candy.media.picker.model.MediaData
import com.candy.media.picker.model.MediaType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

val LocalMediaPickerProvider = staticCompositionLocalOf { EmptyMediaPickerProvider }

/**
 * 媒体选择器的可观察状态与操作入口。
 *
 * 操作应从 UI 线程串行调用。[selectedItems] 按选择顺序排列且 URI 唯一，
 * [selectedUris] 始终是同一批项目的 URI 集合，数量不会超过 [maxSelectCount]。
 */
@Stable
interface MediaPickerProvider {
    /** 当前媒体类型和相册过滤后的媒体列表。 */
    val mediaList: StateFlow<List<MediaData>>

    /** 所有相册 */
    val albums: StateFlow<List<Album>>

    /** 当前选中的相册 */
    val currentAlbum: StateFlow<Album?>

    /** 已选中的媒体列表 */
    val selectedItems: StateFlow<List<MediaData>>

    /** 已选中的媒体 URI 集合，用于高效查找 */
    val selectedUris: StateFlow<Set<Uri>>

    /** 已选中数量 */
    val selectedCount: StateFlow<Int>

    /** 当前相册是否还有更多媒体待分页加载。 */
    val hasMoreMedia: StateFlow<Boolean>

    /** 是否正在加载更多媒体（分页进行中）。 */
    val isLoadingMore: StateFlow<Boolean>

    /** 是否原图 */
    val isOriginal: StateFlow<Boolean>

    /** 当前媒体类型过滤 */
    val mediaType: StateFlow<MediaType>

    /** 最大可选数量 */
    val maxSelectCount: StateFlow<Int>

    /** 切换单个媒体选中状态 */
    fun toggleSelection(item: MediaData)

    /**
     * 更新一次滑动多选会话中的范围。
     *
     * 首次调用确定锚点和选中/取消模式，索引对应当前 [mediaList]；会话结束必须调用
     * [onGestureEnd]，以免下一次手势复用旧锚点。
     */
    fun onGestureSelectRange(fromIndex: Int, toIndex: Int)

    /** 手势结束 */
    fun onGestureEnd()

    /** 切换相册 */
    fun switchAlbum(album: Album)

    /** 切换媒体类型（图片/视频/全部） */
    fun switchMediaType(type: MediaType)

    /** 切换原图 */
    fun toggleOriginal()

    /**
     * 异步刷新当前相册和媒体列表。
     *
     * 类型匹配且可解析的 [createdUri] 会临时置顶，但不会自动选中。
     */
    fun refreshMedia(createdUri: Uri? = null)

    /**
     * 加载当前相册的下一页媒体数据，追加到 [mediaList] 末尾。
     *
     * 调用前应检查 [hasMoreMedia] 与 [isLoadingMore]，避免重复或无效加载。
     */
    fun loadMoreMedia()

    /** 根据 URI 获取已选中项的序号（1-based），未选中返回 0 */
    fun selectionOrderOf(uri: Uri): Int

    /** 判断某个 URI 是否已选中 */
    fun isSelected(uri: Uri): Boolean
}

// CompositionLocal 未提供状态时使用静默空实现，便于独立预览组件。

internal val EmptyMediaPickerProvider: MediaPickerProvider = object : MediaPickerProvider {
    override val mediaList: StateFlow<List<MediaData>> = MutableStateFlow(emptyList())
    override val albums: StateFlow<List<Album>> = MutableStateFlow(emptyList())
    override val currentAlbum: StateFlow<Album?> = MutableStateFlow(null)
    override val selectedItems: StateFlow<List<MediaData>> = MutableStateFlow(emptyList())
    override val selectedUris: StateFlow<Set<Uri>> = MutableStateFlow(emptySet())
    override val selectedCount: StateFlow<Int> = MutableStateFlow(0)
    override val hasMoreMedia: StateFlow<Boolean> = MutableStateFlow(false)
    override val isLoadingMore: StateFlow<Boolean> = MutableStateFlow(false)
    override val isOriginal: StateFlow<Boolean> = MutableStateFlow(false)
    override val mediaType: StateFlow<MediaType> = MutableStateFlow(MediaType.ALL)
    override val maxSelectCount: StateFlow<Int> = MutableStateFlow(9)
    override fun toggleSelection(item: MediaData) {}
    override fun onGestureSelectRange(fromIndex: Int, toIndex: Int) {}
    override fun onGestureEnd() {}
    override fun switchAlbum(album: Album) {}
    override fun switchMediaType(type: MediaType) {}
    override fun toggleOriginal() {}
    override fun refreshMedia(createdUri: Uri?) {}
    override fun loadMoreMedia() {}
    override fun selectionOrderOf(uri: Uri) = 0
    override fun isSelected(uri: Uri) = false
}
