package com.candy.media.picker.ui

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalContext
import androidx.core.net.toUri
import com.candy.media.picker.data.MediaRepository
import com.candy.media.picker.model.Album
import com.candy.media.picker.model.MediaData
import com.candy.media.picker.model.MediaType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.time.Duration.Companion.milliseconds

/**
 * 由 [rememberMediaPickerState] 创建并保存的媒体选择状态。
 *
 * 媒体查询在 IO 调度器执行，公开操作应从 Compose/UI 线程串行调用。选择项按选择顺序排列、
 * URI 唯一，并受当前最大选择数约束。
 */
@Stable
class MediaPickerState internal constructor(
    context: Context,
    private val coroutineScope: CoroutineScope,
    restoredState: Bundle? = null,
) : MediaPickerProvider {

    private val repository = MediaRepository(context.applicationContext)
    private val _mediaList = MutableStateFlow<List<MediaData>>(emptyList())
    private val _albums = MutableStateFlow<List<Album>>(emptyList())
    private val _currentAlbum = MutableStateFlow<Album?>(null)
    private val _selectedItems = MutableStateFlow<List<MediaData>>(emptyList())
    private val _selectedUris = MutableStateFlow<Set<Uri>>(emptySet())
    private val _isOriginal = MutableStateFlow(
        restoredState?.getBoolean(KEY_IS_ORIGINAL) ?: false
    )
    private val _maxSelectCount = MutableStateFlow(DEFAULT_MAX_SELECT_COUNT)
    private val _mediaType = MutableStateFlow(MediaType.ALL)
    private val _hasMoreMedia = MutableStateFlow(false)
    private val _isLoadingMore = MutableStateFlow(false)

    private var dataLoadJob: Job? = null
    private var selectionLoadJob: Job? = null
    private var loadMoreJob: Job? = null
    private var dataGeneration = 0L
    private var selectionGeneration = 0L
    private var loadMoreGeneration = 0L
    private var currentConfig: PickerConfig? = null
    private var restoredAlbumId: Long? = restoredState
        ?.takeIf { it.getBoolean(KEY_HAS_CURRENT_ALBUM) }
        ?.getLong(KEY_CURRENT_ALBUM_ID)
    private var restoredSelectedUris: List<String>? = restoredState
        ?.getStringArrayList(KEY_SELECTED_URIS)
        ?.toList()
    private var pendingSelectionUris: List<String>? = restoredSelectedUris

    private var gestureStartIndex = -1
    private var isGestureSelectMode = true
    private var snapshotSelectedItems: List<MediaData> = emptyList()
    private var snapshotSelectedUris: Set<Uri> = emptySet()

    override val mediaList: StateFlow<List<MediaData>> = _mediaList.asStateFlow()
    override val albums: StateFlow<List<Album>> = _albums.asStateFlow()
    override val currentAlbum: StateFlow<Album?> = _currentAlbum.asStateFlow()
    override val selectedItems: StateFlow<List<MediaData>> = _selectedItems.asStateFlow()
    override val selectedUris: StateFlow<Set<Uri>> = _selectedUris.asStateFlow()
    override val isOriginal: StateFlow<Boolean> = _isOriginal.asStateFlow()
    override val maxSelectCount: StateFlow<Int> = _maxSelectCount.asStateFlow()
    override val mediaType: StateFlow<MediaType> = _mediaType.asStateFlow()
    override val hasMoreMedia: StateFlow<Boolean> = _hasMoreMedia.asStateFlow()
    override val isLoadingMore: StateFlow<Boolean> = _isLoadingMore.asStateFlow()
    override val selectedCount: StateFlow<Int> = _selectedItems
        .map { it.size }
        .stateIn(coroutineScope, SharingStarted.Eagerly, 0)

    internal fun configure(
        maxSelectCount: Int,
        mediaType: MediaType,
        defaultSelected: List<String>,
    ) {
        val normalizedMaxCount = maxSelectCount.coerceAtLeast(0)
        val config = PickerConfig(normalizedMaxCount, mediaType, defaultSelected.toList())
        val previousConfig = currentConfig
        if (previousConfig == config) return

        currentConfig = config
        _maxSelectCount.value = normalizedMaxCount

        val isFirstConfiguration = previousConfig == null
        val mediaTypeChanged = previousConfig?.mediaType != null &&
                               previousConfig.mediaType != mediaType
        if (isFirstConfiguration || mediaTypeChanged) {
            _mediaType.value = mediaType
            if (mediaTypeChanged) {
                cancelPendingSelectionLoad()
                clearSelection()
                _currentAlbum.value = null
                restoredAlbumId = null
            }
            loadAlbumsAndMedia(mediaType, restoredAlbumId)
        }

        // 首次配置优先恢复 saveable 状态；后续只有类型或默认选择变化才替换当前选择。
        val selectionToRestore = when {
            isFirstConfiguration && restoredSelectedUris != null -> restoredSelectedUris
            isFirstConfiguration -> defaultSelected
            mediaTypeChanged -> defaultSelected
            previousConfig.defaultSelected != defaultSelected -> defaultSelected
            else -> null
        }
        restoredSelectedUris = null
        if (selectionToRestore != null) {
            replaceSelection(selectionToRestore, normalizedMaxCount)
        } else if (_selectedItems.value.size > normalizedMaxCount) {
            setSelection(_selectedItems.value.take(normalizedMaxCount))
        }
    }

    override fun toggleSelection(item: MediaData) {
        cancelPendingSelectionLoad()
        val current = _selectedItems.value
        if (_selectedUris.value.contains(item.uri)) {
            setSelection(current.filterNot { it.uri == item.uri })
        } else if (current.size < _maxSelectCount.value) {
            setSelection(current + item)
        }
    }

    override fun onGestureSelectRange(fromIndex: Int, toIndex: Int) {
        cancelPendingSelectionLoad()
        val items = _mediaList.value
        if (gestureStartIndex < 0) {
            gestureStartIndex = fromIndex
            if (gestureStartIndex in items.indices) {
                val targetUri = items[gestureStartIndex].uri
                isGestureSelectMode = !_selectedUris.value.contains(targetUri)
                snapshotSelectedItems = _selectedItems.value
                snapshotSelectedUris = _selectedUris.value
            } else {
                gestureStartIndex = -1
                return
            }
        }

        val range = if (gestureStartIndex <= toIndex) {
            gestureStartIndex..toIndex
        } else {
            gestureStartIndex downTo toIndex
        }
        val newItems = snapshotSelectedItems.toMutableList()
        val newUris = snapshotSelectedUris.toMutableSet()

        for (index in range) {
            if (index !in items.indices) continue
            val item = items[index]
            if (isGestureSelectMode) {
                if (!newUris.contains(item.uri) && newItems.size < _maxSelectCount.value) {
                    newUris += item.uri
                    newItems += item
                }
            } else if (newUris.remove(item.uri)) {
                newItems.removeAll { it.uri == item.uri }
            }
        }

        if (newUris != _selectedUris.value) {
            _selectedUris.value = newUris
            _selectedItems.value = newItems
        }
    }

    override fun onGestureEnd() {
        gestureStartIndex = -1
        snapshotSelectedItems = emptyList()
        snapshotSelectedUris = emptySet()
    }

    override fun switchAlbum(album: Album) {
        _currentAlbum.value = album
        loadAlbumsAndMedia(_mediaType.value, album.id.normalizedBucketId())
    }

    override fun switchMediaType(type: MediaType) {
        if (_mediaType.value == type) return
        currentConfig = currentConfig?.copy(mediaType = type)
        _mediaType.value = type
        cancelPendingSelectionLoad()
        clearSelection()
        _currentAlbum.value = null
        restoredAlbumId = null
        loadAlbumsAndMedia(type, null)
    }

    override fun toggleOriginal() {
        _isOriginal.update { !it }
    }

    override fun refreshMedia(createdUri: Uri?) {
        val requestedType = _mediaType.value
        val requestedAlbumId = _currentAlbum.value?.id
        loadAlbumsAndMedia(requestedType, requestedAlbumId, createdUri)
    }

    override fun loadMoreMedia() {
        if (_isLoadingMore.value || !_hasMoreMedia.value) return
        val type = _mediaType.value
        val bucketId = _currentAlbum.value?.id?.normalizedBucketId()
        val currentItems = _mediaList.value
        val offset = currentItems.size

        val generation = ++loadMoreGeneration
        loadMoreJob?.cancel()
        _isLoadingMore.value = true

        loadMoreJob = coroutineScope.launch {
            val moreItems = withContext(Dispatchers.IO) {
                repository.getMediaList(
                    mediaType = type,
                    bucketId = bucketId,
                    offset = offset,
                    limit = MediaRepository.FIRST_PAGE_SIZE,
                )
            }
            if (
                generation != loadMoreGeneration ||
                type != _mediaType.value ||
                bucketId != _currentAlbum.value?.id?.normalizedBucketId()
            ) {
                _isLoadingMore.value = false
                return@launch
            }
            val merged = _mediaList.value + moreItems
            _mediaList.value = merged
            _hasMoreMedia.value = moreItems.size >= MediaRepository.FIRST_PAGE_SIZE
            _isLoadingMore.value = false
        }
    }

    override fun selectionOrderOf(uri: Uri): Int {
        return _selectedItems.value.indexOfFirst { it.uri == uri } + 1
    }

    override fun isSelected(uri: Uri): Boolean = _selectedUris.value.contains(uri)

    internal fun saveState(): Bundle = Bundle().apply {
        putStringArrayList(
            KEY_SELECTED_URIS,
            ArrayList(
                pendingSelectionUris
                ?: _selectedItems.value.map { it.uri.toString() }
            ),
        )
        putBoolean(KEY_IS_ORIGINAL, _isOriginal.value)
        _currentAlbum.value?.let { album ->
            putBoolean(KEY_HAS_CURRENT_ALBUM, true)
            putLong(KEY_CURRENT_ALBUM_ID, album.id)
        }
    }

    internal fun close() {
        dataGeneration++
        selectionGeneration++
        loadMoreGeneration++
        dataLoadJob?.cancel()
        selectionLoadJob?.cancel()
        loadMoreJob?.cancel()
    }

    // ── 新的合并查询：单次 Cursor 遍历同时返回 albums + 首屏 media ──

    private fun loadAlbumsAndMedia(
        type: MediaType,
        requestedAlbumId: Long?,
        createdUri: Uri? = null,
    ) {
        val generation = beginDataLoad()
        // 加载更多时立刻终止，新数据通道启动时也重置分页状态
        loadMoreGeneration++
        loadMoreJob?.cancel()
        _isLoadingMore.value = false
        _hasMoreMedia.value = false

        dataLoadJob = coroutineScope.launch {
            val result = withContext(Dispatchers.IO) {
                repository.getAlbumsAndMediaFirstPage(
                    mediaType = type,
                    requestedBucketId = requestedAlbumId,
                )
            }

            // 取消 ContentResolver 查询不一定立即生效，generation 防止旧结果覆盖新配置。
            if (generation != dataGeneration || type != _mediaType.value) return@launch

            _albums.value = result.albums
            _currentAlbum.value = result.currentAlbum
            restoredAlbumId = null

            // 含拍摄占位的新首屏
            val createdItem = createdUri?.let(repository::getMediaItem)
            val firstPageItems = result.mediaItems.withCreatedItem(createdItem, type)

            // ═══ 优化 3：尽早发布 UI ═══
            // 首屏数据立刻写入 _mediaList，LazyVerticalGrid 可立即渲染。
            _mediaList.value = firstPageItems
            _hasMoreMedia.value = result.hasMore
        }
    }

    private fun beginDataLoad(): Long {
        dataLoadJob?.cancel()
        return ++dataGeneration
    }

    private fun replaceSelection(uriStrings: List<String>, maxCount: Int) {
        val generation = ++selectionGeneration
        selectionLoadJob?.cancel()
        if (uriStrings.isEmpty() || maxCount == 0) {
            pendingSelectionUris = null
            clearSelection()
            return
        }
        val requestedUris = uriStrings.distinct().take(maxCount)
        pendingSelectionUris = requestedUris
        selectionLoadJob = coroutineScope.launch {
            val loadedItems = withContext(Dispatchers.IO) {
                requestedUris.mapNotNull { uriString ->
                    repository.getMediaItem(uriString.toUri())
                }
            }
            if (generation == selectionGeneration) {
                pendingSelectionUris = null
                setSelection(loadedItems)
            }
        }
    }

    private fun cancelPendingSelectionLoad() {
        selectionGeneration++
        selectionLoadJob?.cancel()
        selectionLoadJob = null
        pendingSelectionUris = null
    }

    private fun clearSelection() {
        setSelection(emptyList())
        onGestureEnd()
    }

    private fun setSelection(items: List<MediaData>) {
        _selectedItems.value = items
        _selectedUris.value = items.mapTo(LinkedHashSet(), MediaData::uri)
    }

    private fun List<MediaData>.withCreatedItem(
        createdItem: MediaData?,
        type: MediaType,
    ): List<MediaData> {
        val acceptedItem = createdItem?.takeIf { item ->
            when (type) {
                MediaType.IMAGE -> item.isImage
                MediaType.VIDEO -> item.isVideo
                MediaType.ALL -> true
            }
        }
        return if (acceptedItem != null) {
            listOf(acceptedItem) + filterNot { it.uri == acceptedItem.uri }
        } else {
            this
        }
    }

    private data class PickerConfig(
        val maxSelectCount: Int,
        val mediaType: MediaType,
        val defaultSelected: List<String>,
    )

    private companion object {
        const val DEFAULT_MAX_SELECT_COUNT = 9
        const val KEY_SELECTED_URIS = "selected_uris"
        const val KEY_IS_ORIGINAL = "is_original"
        const val KEY_HAS_CURRENT_ALBUM = "has_current_album"
        const val KEY_CURRENT_ALBUM_ID = "current_album_id"
    }
}

/**
 * 创建可保存的 [MediaPickerState]。
 *
 * 保存内容仅包含选择 URI、原图开关和当前相册 ID，配置参数会在恢复后重新应用。
 * 对于需要持久化访问的 SAF URI，读取授权仍由调用方负责。
 */
@Composable
fun rememberMediaPickerState(
    maxSelectCount: Int = Int.MAX_VALUE,
    mediaType: MediaType = MediaType.ALL,
    selectedList: List<String> = emptyList(),
    initialLoadDelayMillis: Long = 0L,
): MediaPickerState {
    val context = LocalContext.current.applicationContext
    val coroutineScope = rememberCoroutineScope()
    val saver = remember(context, coroutineScope) {
        Saver<MediaPickerState, Bundle>(
            save = { state -> state.saveState() },
            restore = { savedState ->
                MediaPickerState(context, coroutineScope, savedState)
            },
        )
    }
    val state = rememberSaveable(saver = saver) {
        MediaPickerState(context, coroutineScope)
    }

    LaunchedEffect(state, maxSelectCount, mediaType, selectedList, initialLoadDelayMillis) {
        if (initialLoadDelayMillis > 0) {
            delay(initialLoadDelayMillis.milliseconds)
        }
        state.configure(maxSelectCount, mediaType, selectedList)
    }
    DisposableEffect(state) {
        onDispose { state.close() }
    }
    return state
}

private fun Long.normalizedBucketId(): Long? = takeUnless { it == -1L }
