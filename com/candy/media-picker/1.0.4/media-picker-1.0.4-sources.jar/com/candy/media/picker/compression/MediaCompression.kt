package com.candy.media.picker.compression

import android.content.Context
import android.graphics.BitmapFactory
import androidx.core.content.FileProvider
import com.candy.media.picker.model.MediaData
import com.candy.media.picker.model.MediaPickerData
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import top.zibin.luban.api.Luban
import java.io.File
import java.io.IOException

/**
 * 媒体选择完成后的压缩器。
 *
 * 回调在调用 [compress] 的协程上下文执行，取消必须继续抛出 [CancellationException]。
 * 回调抛出的异常会终止本次压缩，此时不保证调用 [onCompressionComplete]。
 */
fun interface MediaCompressionEngine {

    val onCompressionStart: (items: List<MediaData>) -> Unit
        get() = {}

    val onCompressionProgress: (source: MediaData, result: MediaPickerData) -> Unit
        get() = { _, _ -> }

    val onCompressionComplete: (result: List<MediaPickerData>) -> Unit
        get() = {}

    suspend fun compress(context: Context, items: List<MediaData>): List<MediaPickerData>
}

/** 使用 Luban 2 压缩图片的默认媒体压缩器。视频和 GIF 会保持原样。 */
class LubanMediaCompressionEngine(
    override val onCompressionStart: (items: List<MediaData>) -> Unit = {},
    override val onCompressionProgress: (source: MediaData, result: MediaPickerData) -> Unit = { _, _ -> },
    override val onCompressionComplete: (result: List<MediaPickerData>) -> Unit = {},
) : MediaCompressionEngine {

    override suspend fun compress(
        context: Context,
        items: List<MediaData>,
    ): List<MediaPickerData> {
        onCompressionStart(items)
        val results = ArrayList<MediaPickerData>(items.size)

        items.forEach { item ->
            val result = if (!item.shouldCompress()) {
                MediaPickerData(
                    uri = item.uri,
                    mimeType = item.mimeType,
                    size = item.size,
                    width = item.width,
                    height = item.height,
                    duration = item.duration,
                )
            } else try {
                withContext(Dispatchers.IO) { compressImage(context, item) }
            } catch (cause: CancellationException) {
                throw cause
            } catch (_: Exception) {
                MediaPickerData(
                    uri = item.uri,
                    mimeType = item.mimeType,
                    size = item.size,
                    width = item.width,
                    height = item.height,
                    duration = item.duration,
                )
            }
            results += result
            onCompressionProgress(item, result)
        }

        return results.also(onCompressionComplete)
    }

    private fun MediaData.shouldCompress(): Boolean {
        return mimeType.lowercase().startsWith("image/") && mimeType.lowercase() != "image/gif"
    }

    private suspend fun compressImage(context: Context, item: MediaData): MediaPickerData {
        val outputDirectory = File(context.cacheDir, "compressed").apply { mkdirs() }
        if (!outputDirectory.isDirectory) {
            throw IOException("Cannot create compression cache directory")
        }

        val outputFile = Luban.compress(context, item.uri, outputDirectory).getOrThrow()

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(outputFile.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            outputFile.delete()
            throw IOException("Cannot read compressed image bounds: ${item.uri}")
        }

        val outputUri = try {
            FileProvider.getUriForFile(
                context,
                "${context.packageName}.candy.media.picker.fileprovider",
                outputFile,
            )
        } catch (cause: Exception) {
            outputFile.delete()
            throw cause
        }
        return MediaPickerData(
            uri = outputUri,
            mimeType = "image/jpeg",
            size = outputFile.length(),
            width = bounds.outWidth,
            height = bounds.outHeight,
            duration = 0L,
            compressedUri = outputUri,
            compressedFile = outputFile,
        )
    }
}
