package com.candy.media.picker.ui

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterExitState
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil3.ImageLoader
import coil3.compose.AsyncImage
import com.candy.media.picker.R
import com.candy.media.picker.compression.MediaCompressionEngine
import com.candy.media.picker.compression.WeChatMediaCompressionEngine
import com.candy.media.picker.model.Album
import com.candy.media.picker.model.MediaData
import com.candy.media.picker.model.MediaPickerResult
import com.candy.media.picker.model.MediaType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * 相机入口点击处理器。
 *
 * 调用方负责根据当前 [MediaPickerProvider.mediaType] 选择拍照或录像，并且一次点击最多启动
 * 一个动作。默认实现会在视频模式调用 `takeVideo`，其他模式调用 `takePhoto`。
 */
typealias MediaPickerCameraClick = (
    provider: MediaPickerProvider,
    takePhoto: () -> Unit,
    takeVideo: () -> Unit,
) -> Unit

/**
 * 自定义预览遮罩在当前组合时刻的状态快照。
 *
 * [initialPage] 是 [items] 中的索引。自定义实现需要转发 [onPageChanged]、[onBack] 和
 * [onPreviewFullyOpenChanged]，以维持页面恢复、共享转场和返回行为。
 */
@Stable
data class MediaPickerOverlayState(
    val provider: MediaPickerProvider,
    val items: List<MediaData>,
    val initialPage: Int,
    val visible: Boolean,
    val imageLoader: ImageLoader,
    val theme: MediaPreviewTheme,
    val showOriginal: Boolean,
    val showOriginalSize: Boolean,
    val showConfirm: Boolean,
    val showConfirmProgress: Boolean,
    val confirmText: String,
    val sharedTransitionScope: SharedTransitionScope,
    val onPreviewFullyOpenChanged: (Boolean) -> Unit,
    val onBack: () -> Unit,
    val onPageChanged: (Int) -> Unit,
    val onCameraClick: MediaPickerCameraClick,
    val onConfirm: () -> Unit,
)

object MediaPickerDefaults {

    private val baseLightTheme = MediaPickerTheme()

    val Overlay: @Composable BoxScope.(MediaPickerOverlayState) -> Unit = { state ->
        MediaPickerOverlay(state)
    }

    val CameraClick: MediaPickerCameraClick = { provider, takePhoto, takeVideo ->
        if (provider.mediaType.value == MediaType.VIDEO) {
            takeVideo()
        } else {
            takePhoto()
        }
    }

    val CompressionEngine: MediaCompressionEngine = WeChatMediaCompressionEngine()

    /** MediaPicker 默认亮色主题。 */
    val lightTheme = baseLightTheme.copy(
        previewTheme = baseLightTheme.previewTheme.copy(background = Color.White)
    )

    /** MediaPicker 默认暗色主题。 */
    val darkTheme = MediaPickerTheme(
        statusBarBackground = Color(0xFF1F1F1F),
        statusBarContent = Color.White,
        gridBackground = Color(0xFF111111),
        accent = Color(0xFF07C160),
        disabled = Color(0xFF8C8C8C),
        placeholder = Color(0xFF2C2C2C),
        overlay = Color(0xA6000000),
        unselectedBorder = Color.White,
        unselectedBackground = Color(0x66000000),
        onAccent = Color.White,
        albumSecondaryText = Color(0xFF999999),
        albumDivider = Color(0xFF3A3A3A),
        onAccentButton = Color.White,
        accentDisabled = Color(0x8007C160),
    )
}

/**
 * 显示完整的媒体选择器，包括相册切换、媒体网格、相机入口、预览和确认操作。
 *
 * 调用方负责按 Android 版本申请媒体读取权限。媒体类型变化会清空当前选择；关闭压缩或
 * 选择“原图”时不会调用压缩器。
 *
 * @param modifier 应用于选择器根布局的修饰符。
 * @param mediaType 初始及受控的媒体类型过滤条件，支持图片、视频或两者。
 * @param maxSelectCount 最大可选数量，小于零时按零处理。
 * @param selectedList 默认或待恢复的媒体 URI 字符串列表。列表会异步解析、去重并按
 * [maxSelectCount] 截断，无法读取的 URI 会被忽略。
 * @param columnCount 媒体网格列数，必须大于零。
 * @param imageLoader 网格缩略图、相册封面和预览使用的 Coil 加载器。
 * @param theme 选择器及内置预览使用的颜色和图标配置。
 * @param itemSpacing 网格项目之间的水平和垂直间距。
 * @param showSelectOrder 选中指示器是否显示选择顺序；否则显示勾选图标。
 * @param showCamera 是否在媒体网格首项显示相机入口。
 * @param showPreview 是否在底部栏显示预览入口。
 * @param showOriginal 是否在底部栏和内置预览中显示“原图”选项。
 * @param showOriginalSize 是否在“原图”选项旁显示当前选择的总大小。
 * @param showConfirm 是否显示确认操作。
 * @param showConfirmProgress 压缩期间是否在确认按钮中显示进度指示器。
 * @param enableCompression 确认非原图选择时是否执行压缩。
 * @param compressionEngine 媒体压缩器。抛出的整体异常会转换为所有已选项失败的结果。
 * @param initialLoadDelayMillis 初始化延迟加载时间。
 * @param previewText 底部栏预览入口的文字。
 * @param confirmText 底部栏及预览确认按钮的文字。
 * @param enableGestureMultiSelect 是否允许在媒体网格中通过拖动进行范围多选。
 * @param overlay 覆盖在选择器内容之上的预览层，可使用 [MediaPickerOverlayState] 接入自定义 UI。
 * @param onBackClick 顶部返回入口及无内部弹层时的系统返回回调；为 `null` 时不显示返回入口。
 * @param onCameraClick 相机入口点击处理器，可选择启动拍照或录像。
 * @param onItemClick 网格项目点击处理器。非空时完全替代内置预览行为。
 * @param onPreviewClick 底部预览入口点击处理器。非空时完全替代内置预览行为。
 * @param onConfirmClick 确认后的结果回调；压缩启用时在压缩完成后调用。
 */
@Composable
fun MediaPicker(
    modifier: Modifier = Modifier,
    mediaType: MediaType = MediaType.ALL,
    maxSelectCount: Int = Int.MAX_VALUE,
    selectedList: List<String> = emptyList(),
    columnCount: Int = 4,
    imageLoader: ImageLoader = rememberMediaPickerImageLoader(),
    theme: MediaPickerTheme = if (isSystemInDarkTheme()) {
        MediaPickerDefaults.darkTheme
    } else {
        MediaPickerDefaults.lightTheme
    },
    itemSpacing: Dp = 2.dp,
    showSelectOrder: Boolean = maxSelectCount > 1,
    showCamera: Boolean = true,
    showPreview: Boolean = true,
    showOriginal: Boolean = true,
    showOriginalSize: Boolean = true,
    showConfirm: Boolean = true,
    showConfirmProgress: Boolean = false,
    enableCompression: Boolean = true,
    compressionEngine: MediaCompressionEngine = MediaPickerDefaults.CompressionEngine,
    initialLoadDelayMillis: Long = 0L,
    previewText: String = stringResource(R.string.picker_preview),
    confirmText: String = stringResource(R.string.picker_confirm),
    enableGestureMultiSelect: Boolean = true,
    overlay: @Composable BoxScope.(MediaPickerOverlayState) -> Unit = MediaPickerDefaults.Overlay,
    onBackClick: (() -> Unit)? = null,
    onCameraClick: MediaPickerCameraClick = MediaPickerDefaults.CameraClick,
    onItemClick: ((provider: MediaPickerProvider, itemScope: MediaGridItemScope) -> Unit)? = null,
    onPreviewClick: ((provider: MediaPickerProvider) -> Unit)? = null,
    onConfirmClick: (MediaPickerResult) -> Unit = { },
) {
    val context = LocalContext.current
    val confirmScope = rememberCoroutineScope()
    var showAlbumList by remember { mutableStateOf(false) }
    var previewItems by remember { mutableStateOf<List<MediaData>>(emptyList()) }
    var previewVisible by rememberSaveable { mutableStateOf(false) }
    var previewInitialPage by rememberSaveable { mutableIntStateOf(0) }
    var previewFromSelection by rememberSaveable { mutableStateOf(false) }
    var previewSharedElementUri by rememberSaveable { mutableStateOf<Uri?>(null) }
    var previewCurrentUri by rememberSaveable { mutableStateOf<Uri?>(null) }
    var isPreviewFullyOpen by remember { mutableStateOf(false) }
    var isCompressing by remember { mutableStateOf(false) }
    val closePreview: () -> Unit = {
        previewVisible = false
        previewSharedElementUri = null
        previewCurrentUri = null
    }

    BackHandler(
        enabled = previewVisible || showAlbumList || onBackClick != null
    ) {
        when {
            previewVisible -> closePreview()
            showAlbumList -> showAlbumList = false
            else -> onBackClick?.invoke()
        }
    }

    val confirmSelection: (MediaPickerProvider) -> Unit = confirmSelection@{ provider ->
        if (isCompressing) return@confirmSelection
        val selectedItems = provider.selectedItems.value
        if (!enableCompression) {
            onConfirmClick(MediaPickerResult.original(selectedItems))
            return@confirmSelection
        }
        if (provider.isOriginal.value) {
            onConfirmClick(MediaPickerResult.original(selectedItems))
            return@confirmSelection
        }

        isCompressing = true
        confirmScope.launch {
            val result = try {
                compressionEngine.compress(context, selectedItems)
            } catch (cause: CancellationException) {
                isCompressing = false
                throw cause
            } catch (cause: Exception) {
                MediaPickerResult.compressFailed(selectedItems, cause)
            }
            isCompressing = false
            onConfirmClick(result)
        }
    }

    SharedTransitionLayout(modifier = modifier.fillMaxSize()) {
        CompositionLocalProvider(LocalMediaPickerTheme provides theme) {
            MediaPickerScaffold(
                modifier = Modifier.fillMaxSize(),
                mediaType = mediaType,
                maxSelectCount = maxSelectCount,
                selectedList = selectedList,
                initialLoadDelayMillis = initialLoadDelayMillis,
                topBar = {
                    MediaPickerTopBar(
                        showAlbumList = showAlbumList,
                        onAlbumClick = { showAlbumList = !showAlbumList },
                        onBack = { onBackClick?.invoke() }
                    )
                },
                bottomBar = {
                    MediaPickerBottomBar(
                        showPreview = showPreview,
                        showOriginal = showOriginal,
                        showOriginalSize = showOriginalSize,
                        showConfirm = showConfirm,
                        confirmText = confirmText,
                        previewText = previewText,
                        showConfirmProgress = showConfirmProgress,
                        onPreview = { provider ->
                            if (onPreviewClick != null) {
                                onPreviewClick(provider)
                            } else {
                                val selectedItems = provider.selectedItems.value
                                previewItems = selectedItems
                                previewInitialPage = 0
                                previewFromSelection = true
                                previewSharedElementUri = selectedItems.firstOrNull()?.uri
                                previewCurrentUri = previewSharedElementUri
                                previewVisible = true
                            }
                        },
                        onConfirm = confirmSelection
                    )
                },
                overlay = { provider ->
                    val mediaItems by provider.mediaList.collectAsState()
                    val selectedItems by provider.selectedItems.collectAsState()
                    val restoredPreviewItems = when {
                        previewItems.isNotEmpty() -> previewItems
                        !previewVisible -> emptyList()
                        previewFromSelection -> selectedItems
                        else -> mediaItems
                    }

                    LaunchedEffect(previewVisible, restoredPreviewItems) {
                        if (
                            previewVisible &&
                            previewItems.isEmpty() &&
                            restoredPreviewItems.isNotEmpty()
                        ) {
                            previewItems = restoredPreviewItems
                        }
                    }

                    overlay(
                        MediaPickerOverlayState(
                            provider = provider,
                            items = restoredPreviewItems,
                            initialPage = previewInitialPage,
                            visible = previewVisible,
                            imageLoader = imageLoader,
                            theme = theme.previewTheme,
                            showOriginal = showOriginal,
                            showOriginalSize = showOriginalSize,
                            showConfirm = showConfirm,
                            showConfirmProgress = showConfirmProgress,
                            confirmText = confirmText,
                            sharedTransitionScope = this@SharedTransitionLayout,
                            onPreviewFullyOpenChanged = { isPreviewFullyOpen = it },
                            onBack = closePreview,
                            onPageChanged = { page ->
                                previewInitialPage = page
                                val uri = restoredPreviewItems.getOrNull(page)?.uri
                                previewCurrentUri = uri
                                previewSharedElementUri = uri
                            },
                            onCameraClick = onCameraClick,
                            onConfirm = {
                                closePreview()
                                confirmSelection(provider)
                            }
                        )
                    )
                }
            ) {
                val provider = LocalMediaPickerProvider.current
                val context = LocalContext.current
                val shouldShowCamera = showCamera
                val cameraItemIndexOffset = if (shouldShowCamera) 1 else 0
                val gridState = rememberLazyGridState()
                val cameraScope = rememberCoroutineScope()
                var cameraOutputFilePath by rememberSaveable { mutableStateOf<String?>(null) }
                var cameraOutputTypeName by rememberSaveable { mutableStateOf<String?>(null) }
                var pendingPermissionTypeName by rememberSaveable {
                    mutableStateOf<String?>(null)
                }
                val discardPendingCapture: () -> Unit = {
                    cameraOutputFilePath?.let(::discardCameraOutput)
                    cameraOutputFilePath = null
                    cameraOutputTypeName = null
                }
                val completeCapture: () -> Unit = completeCapture@{
                    val filePath = cameraOutputFilePath ?: return@completeCapture
                    val captureType = cameraOutputTypeName?.let { typeName ->
                        runCatching { MediaCaptureType.valueOf(typeName) }.getOrNull()
                    }
                    if (captureType == null) {
                        discardPendingCapture()
                        return@completeCapture
                    }
                    cameraScope.launch {
                        val finalUri = completeCameraOutput(
                            context = context,
                            localFilePath = filePath,
                            type = captureType,
                        )
                        cameraOutputFilePath = null
                        cameraOutputTypeName = null
                        if (finalUri != null) {
                            provider.refreshMedia(finalUri)
                        }
                    }
                }
                val photoLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.TakePicture()
                ) { succeeded ->
                    if (succeeded) completeCapture() else discardPendingCapture()
                }
                val videoLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.CaptureVideo()
                ) { succeeded ->
                    if (succeeded) completeCapture() else discardPendingCapture()
                }

                val launchCapture: (MediaCaptureType) -> Unit = launchCapture@{ type ->
                    if (cameraOutputFilePath != null) return@launchCapture
                    createCameraOutput(context, type)?.let { output ->
                        cameraOutputFilePath = output.filePath
                        cameraOutputTypeName = output.type.name
                        runCatching {
                            when (type) {
                                MediaCaptureType.PHOTO -> photoLauncher.launch(output.uri)
                                MediaCaptureType.VIDEO -> videoLauncher.launch(output.uri)
                            }
                        }
                            .onFailure {
                                discardPendingCapture()
                            }
                    }
                }
                val writePermissionLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.RequestPermission()
                ) { granted ->
                    val captureType = pendingPermissionTypeName?.let { typeName ->
                        runCatching { MediaCaptureType.valueOf(typeName) }.getOrNull()
                    }
                    pendingPermissionTypeName = null
                    if (granted && captureType != null) {
                        launchCapture(captureType)
                    }
                }

                val requestCapture: (MediaCaptureType) -> Unit = requestCapture@{ type ->
                    if (cameraOutputFilePath != null) return@requestCapture
                    val needsWritePermission =
                        Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
                        ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        ) != PackageManager.PERMISSION_GRANTED
                    if (needsWritePermission) {
                        pendingPermissionTypeName = type.name
                        writePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    } else {
                        launchCapture(type)
                    }
                }
                val takePhoto = { requestCapture(MediaCaptureType.PHOTO) }
                val takeVideo = { requestCapture(MediaCaptureType.VIDEO) }

                LaunchedEffect(previewCurrentUri, previewVisible, cameraItemIndexOffset) {
                    if (previewVisible) {
                        val uri = previewCurrentUri ?: return@LaunchedEffect
                        val index = provider.mediaList.value.indexOfFirst { it.uri == uri }
                        if (index >= 0) {
                            val gridIndex = index + cameraItemIndexOffset
                            val visibleItems = gridState.layoutInfo.visibleItemsInfo
                            val isVisible = visibleItems.any { it.index == gridIndex }
                            if (!isVisible) {
                                gridState.scrollToItem(gridIndex)
                            }
                        }
                    }
                }

                MediaGrid(
                    modifier = Modifier.fillMaxSize(),
                    itemSpacing = itemSpacing,
                    dividerColor = theme.gridBackground,
                    columnCount = columnCount,
                    enableGestureMultiSelect = enableGestureMultiSelect,
                    gridState = gridState,
                    cameraItem = if (shouldShowCamera) {
                        {
                            CameraGridItem(
                                modifier = Modifier.fillMaxSize(),
                                onClick = {
                                    onCameraClick(provider, takePhoto, takeVideo)
                                },
                            )
                        }
                    } else {
                        null
                    },
                ) mediaItem@{
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .aspectRatio(1f)
                    ) {
                        AnimatedVisibility(
                            visible = mediaData.uri != previewSharedElementUri,
                            enter = fadeIn(
                                animationSpec = tween(
                                    durationMillis = 300,
                                    easing = FastOutSlowInEasing
                                )
                            ),
                            exit = fadeOut(animationSpec = tween(0)),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            MediaGridItem(
                                item = mediaData,
                                selected = isSelected,
                                selectionOrder = selectionOrder,
                                showSelectionOrder = showSelectOrder,
                                imageLoader = imageLoader,
                                modifier = Modifier.fillMaxSize(),
                                imageModifier = if (isScrollInProgress) {
                                    Modifier
                                } else {
                                    Modifier.sharedBounds(
                                        sharedContentState = rememberSharedContentState(
                                            key = if (isPreviewFullyOpen && mediaData.uri == previewSharedElementUri) {
                                                "disabled-${mediaData.uri}"
                                            } else {
                                                mediaPreviewSharedElementKey(mediaData)
                                            }
                                        ),
                                        animatedVisibilityScope = this,
                                        enter = fadeIn(tween(1, delayMillis = 299)),
                                        exit = ExitTransition.None,
                                        boundsTransform = { _, _ ->
                                            tween(
                                                durationMillis = 300, easing = FastOutSlowInEasing
                                            )
                                        },
                                        clipInOverlayDuringTransition = OverlayClip(RectangleShape)
                                    )
                                },
                                deferVideoFrameLoading = isScrollInProgress,
                                onClick = {
                                    if (onItemClick != null) {
                                        onItemClick(provider, this@mediaItem)
                                    } else {
                                        previewItems = provider.mediaList.value
                                        previewInitialPage = provider.mediaList.value.indexOfFirst {
                                            it.uri == mediaData.uri
                                        }.coerceAtLeast(0)
                                        previewFromSelection = false
                                        previewSharedElementUri = mediaData.uri
                                        previewCurrentUri = mediaData.uri
                                        previewVisible = true
                                    }
                                },
                                onSelectionClick = { provider.toggleSelection(mediaData) }
                            )
                        }
                    }
                }

                // 相册列表遮罩
                AnimatedVisibility(
                    visible = showAlbumList,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier.fillMaxSize()
                ) {
                    AlbumListPopup(
                        visible = showAlbumList,
                        imageLoader = imageLoader,
                        onClose = { showAlbumList = false }
                    )
                }
            }
        }
    }
}

@Composable
fun BoxScope.MediaPickerOverlay(state: MediaPickerOverlayState) {
    val selectedItems by state.provider.selectedItems.collectAsState()
    val isOriginal by state.provider.isOriginal.collectAsState()
    val maxSelectCount by state.provider.maxSelectCount.collectAsState()

    with(state.sharedTransitionScope) {
        AnimatedVisibility(
            visible = state.visible,
            enter = fadeIn(
                animationSpec = tween(
                    durationMillis = 300,
                    easing = FastOutSlowInEasing
                )
            ),
            exit = fadeOut(
                animationSpec = tween(
                    durationMillis = 300,
                    easing = FastOutSlowInEasing
                )
            ),
            modifier = Modifier.fillMaxSize()
        ) {
            LaunchedEffect(transition.currentState, transition.targetState) {
                state.onPreviewFullyOpenChanged(
                    transition.currentState == EnterExitState.Visible &&
                    transition.targetState == EnterExitState.Visible
                )
            }
            MediaPreview(
                items = state.items,
                initialPage = state.initialPage,
                theme = state.theme,
                selectedItems = selectedItems,
                isOriginal = isOriginal,
                maxSelectCount = maxSelectCount,
                imageLoader = state.imageLoader,
                bottomBar = { bottomBarState ->
                    MediaPreviewDefaults.BottomBar(
                        bottomBarState.copy(
                            showOriginal = state.showOriginal,
                            showOriginalSize = state.showOriginalSize,
                            showConfirm = state.showConfirm,
                            showConfirmProgress = state.showConfirmProgress,
                            confirmText = state.confirmText
                        )
                    )
                },
                modifier = Modifier.fillMaxSize(),
                chromeModifier = Modifier.renderInSharedTransitionScopeOverlay(
                    zIndexInOverlay = 1f
                ),
                sharedTransitionScope = state.sharedTransitionScope,
                animatedVisibilityScope = this,
                sharedElementKey = { item -> mediaPreviewSharedElementKey(item) },
                onBack = state.onBack,
                onPageChanged = state.onPageChanged,
                onToggleSelection = state.provider::toggleSelection,
                onToggleOriginal = state.provider::toggleOriginal,
                onConfirm = { state.onConfirm() }
            )
        }
    }
}

private fun mediaPreviewSharedElementKey(item: MediaData): String =
    "media-picker-preview-${item.uri}"

@Composable
fun MediaPickerTopBar(
    showAlbumList: Boolean = false,
    onAlbumClick: () -> Unit = {},
    onBack: () -> Unit = {},
) {
    val scope = LocalMediaPickerProvider.current
    val currentAlbum by scope.currentAlbum.collectAsState()
    val colors = LocalMediaPickerTheme.current

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(colors.statusBarBackground)
            .statusBarsPadding()
            .height(46.dp)
    ) {
        Icon(
            painter = painterResource(colors.icons.back),
            contentDescription = "Back",
            tint = colors.statusBarContent,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .clickable { onBack() }
                .fillMaxHeight()
                .padding(horizontal = 16.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxHeight()
                .widthIn(max = 160.dp)
                .align(Alignment.Center)
                .clickable { onAlbumClick() }
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = currentAlbum?.name ?: stringResource(R.string.picker_album_all),
                color = colors.statusBarContent,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 104.dp)
            )
            Icon(
                painter = painterResource(
                    if (showAlbumList) colors.icons.albumExpanded else colors.icons.albumCollapsed
                ),
                contentDescription = null,
                tint = colors.statusBarContent,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

@Composable
fun AlbumListPopup(
    visible: Boolean,
    imageLoader: ImageLoader = rememberMediaPickerImageLoader(),
    onClose: () -> Unit
) {
    val scope = LocalMediaPickerProvider.current
    val albums by scope.albums.collectAsState()
    val currentAlbum by scope.currentAlbum.collectAsState()
    val colors = LocalMediaPickerTheme.current

    // 遮罩层淡入淡出
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = Modifier.fillMaxSize()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(colors.overlay)
                .clickable { onClose() }
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier.fillMaxWidth()
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(0.6f)
                        .clip(RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp))
                        .background(colors.statusBarBackground)
                        .clickable(enabled = false) {}
                ) {
                    items(albums) { album ->
                        AlbumItem(
                            album = album,
                            isSelected = (album.id == (currentAlbum?.id ?: -1L)),
                            imageLoader = imageLoader,
                            onClick = {
                                scope.switchAlbum(album)
                                onClose()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AlbumItem(
    album: Album,
    isSelected: Boolean,
    imageLoader: ImageLoader = rememberMediaPickerImageLoader(),
    onClick: () -> Unit
) {
    val context = LocalContext.current
    val colors = LocalMediaPickerTheme.current
    val imageRequest = remember(album.coverMedia, album.coverUri) {
        val thumbnail = album.coverMedia?.toMediaThumbnail()
                        ?: album.coverUri?.toMediaThumbnail()
        thumbnail?.let { mediaThumbnailRequest(context, it) }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(66.dp)
            .clickable { onClick() }
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            imageLoader = imageLoader,
            model = imageRequest,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(50.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(colors.disabled)
        )

        Row(modifier = Modifier.padding(start = 12.dp)) {
            Text(
                text = album.name,
                color = colors.statusBarContent,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "（${album.count}）",
                color = colors.albumSecondaryText,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }

        if (isSelected) {
            Icon(
                painter = painterResource(colors.icons.check),
                contentDescription = null,
                tint = colors.accent
            )
        }
    }
    HorizontalDivider(
        modifier = Modifier.padding(start = 78.dp, end = 16.dp),
        thickness = 0.5.dp,
        color = colors.albumDivider
    )
}

@Composable
fun MediaPickerBottomBar(
    showPreview: Boolean = true,
    showOriginal: Boolean = true,
    showOriginalSize: Boolean = true,
    showConfirm: Boolean = true,
    showConfirmProgress: Boolean = true,
    previewText: String = stringResource(R.string.picker_preview),
    confirmText: String = stringResource(R.string.picker_confirm),
    onPreview: (provider: MediaPickerProvider) -> Unit = {},
    onConfirm: (provider: MediaPickerProvider) -> Unit = {}
) {
    val scope = LocalMediaPickerProvider.current
    val selectedCount by scope.selectedCount.collectAsState()
    val maxCount by scope.maxSelectCount.collectAsState()
    val isOriginal by scope.isOriginal.collectAsState()
    val selectedItems by scope.selectedItems.collectAsState()
    val colors = LocalMediaPickerTheme.current

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)
            .background(colors.statusBarBackground)
            .navigationBarsPadding()
    ) {
        // 预览
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .clickable(enabled = showPreview && selectedCount > 0) { onPreview(scope) }
                .padding(horizontal = 16.dp)
                .align(Alignment.CenterStart),
            contentAlignment = Alignment.Center
        ) {
            if (showPreview) {
                Text(
                    text = if (selectedCount > 0) "$previewText($selectedCount)" else previewText,
                    color = if (selectedCount > 0) colors.statusBarContent else colors.disabled,
                    fontSize = 14.sp
                )
            }
        }

        // 原图
        if (showOriginal) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .clickable { scope.toggleOriginal() }
                    .padding(horizontal = 16.dp)
                    .align(Alignment.Center)
            ) {
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        painter = painterResource(
                            if (isOriginal) {
                                colors.icons.originalSelected
                            } else {
                                colors.icons.originalUnselected
                            }
                        ),
                        contentDescription = "Original",
                        tint = if (isOriginal) colors.accent else colors.disabled,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.size(4.dp))
                    Text(
                        text = stringResource(R.string.picker_original),
                        color = colors.statusBarContent,
                        fontSize = 14.sp
                    )
                }

                if (showOriginalSize && isOriginal && selectedCount > 0) {
                    Text(
                        text = stringResource(
                            R.string.picker_all_size,
                            (selectedItems.sumOf { it.size } / 1024f / 1024f).roundToInt()
                        ),
                        color = colors.statusBarContent,
                        fontSize = 11.sp,
                        maxLines = 1,
                        style = TextStyle(
                            platformStyle = PlatformTextStyle(
                                includeFontPadding = false
                            )
                        ),
                        modifier = Modifier.align(Alignment.BottomCenter)
                    )
                }
            }
        }

        Box(
            modifier = Modifier.fillMaxHeight().align(Alignment.CenterEnd),
            contentAlignment = Alignment.Center
        ) {
            if (showConfirm) {
                ConfirmButton(
                    modifier = Modifier.padding(end = 16.dp),
                    text = confirmText,
                    count = selectedCount,
                    maxCount = maxCount,
                    showConfirmProgress = showConfirmProgress,
                    onClick = { onConfirm(scope) }
                )
            }
        }
    }
}

@Composable
fun ConfirmButton(
    modifier: Modifier = Modifier,
    text: String,
    count: Int,
    maxCount: Int,
    showConfirmProgress: Boolean,
    onClick: () -> Unit
) {
    val colors = LocalMediaPickerTheme.current
    Button(
        onClick = onClick,
        enabled = count > 0,
        colors = ButtonDefaults.buttonColors(
            containerColor = colors.accent,
            disabledContainerColor = colors.accentDisabled
        ),
        shape = RoundedCornerShape(4.dp),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        modifier = modifier.height(32.dp)
    ) {
        val buttonText = if (showConfirmProgress) {
            if (count > 0) "$text($count/$maxCount)" else text
        } else {
            if (count > 0) "$text($count)" else text
        }
        Text(text = buttonText, color = colors.onAccentButton, fontSize = 14.sp)
    }
}
