package com.candy.ui.host

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import androidx.core.view.isNotEmpty
import com.candy.kit.ext.cast
import kotlin.math.abs

/**
 * [HorizontalScrollView]被嵌套时的滑动冲突解决方案
 * @author: ChenYang
 * @date: 2024-03-11 16:21
 */
class NestedScrollHost @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    defStyleRes: Int = 0
) : FrameLayout(context, attrs, defStyleAttr, defStyleRes) {

    private var touchSlop = 0
    private var lastX = 0f

    private val child: HorizontalScrollView?
        get() = if (isNotEmpty()) getChildAt(0).cast() else null

    init {
        touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        child ?: return super.dispatchTouchEvent(event)

        if (!child!!.canScrollHorizontally(1) && !child!!.canScrollHorizontally(-1)) {
            return super.dispatchTouchEvent(event)
        }

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                parent.requestDisallowInterceptTouchEvent(true)
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - lastX
                if (abs(dx) >= touchSlop) {
                    if (dx > 0 && child!!.canScrollHorizontally(-1)) {
                        parent.requestDisallowInterceptTouchEvent(true)
                    } else if (dx < 0 && child!!.canScrollHorizontally(1)) {
                        parent.requestDisallowInterceptTouchEvent(true)
                    } else {
                        parent.requestDisallowInterceptTouchEvent(false)
                    }
                }
            }
        }
        return super.dispatchTouchEvent(event)
    }
}