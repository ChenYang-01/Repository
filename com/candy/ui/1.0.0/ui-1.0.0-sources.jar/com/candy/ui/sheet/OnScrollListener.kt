package com.candy.ui.sheet

/**
 * OnScrollListener
 * @author: ChenYang
 * @date: 2024-03-05 15:58
 */
fun interface OnScrollListener {
    fun onScroll(dy: Float)
}