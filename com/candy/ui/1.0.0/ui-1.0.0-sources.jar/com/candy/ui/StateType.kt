package com.candy.ui

import android.R

/**
 * StateType
 * @author: ChenYang
 * @date: 2025-05-07 14:57
 */
sealed class StateType(val value: Int) {

    companion object {
        fun from(value: Int): StateType {
            return when (value) {
                0 -> NONE
                1 -> PRESSED
                2 -> SELECTED
                3 -> CHECKED
                else -> NONE
            }
        }
    }

    val StateType.androidState: Int
        get() {
            return when (this) {
                PRESSED -> R.attr.state_pressed
                SELECTED -> R.attr.state_selected
                CHECKED -> R.attr.state_checked
                else -> 0
            }
        }

    data object NONE : StateType(0)
    data object PRESSED : StateType(1)
    data object SELECTED : StateType(2)
    data object CHECKED : StateType(3)
}