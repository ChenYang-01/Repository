package com.candy.ui.ext

import androidx.annotation.ColorInt
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.candy.kit.ext.castOrNull
import com.candy.ui.CandyDivider

val RecyclerView.linearLayoutManager: LinearLayoutManager?
    get() = layoutManager?.castOrNull()
val RecyclerView.gridLayoutManager: GridLayoutManager?
    get() = layoutManager?.castOrNull()
val RecyclerView.staggeredGridLayoutManager: StaggeredGridLayoutManager?
    get() = layoutManager?.castOrNull()

fun RecyclerView.disableAnimate() {
    (itemAnimator as SimpleItemAnimator).supportsChangeAnimations = false
}

fun RecyclerView.scrollToPositionWithOffset(position: Int, offset: Int = 0) {
    val manager = layoutManager ?: return
    when (manager) {
        is GridLayoutManager -> manager.scrollToPositionWithOffset(position, offset)
        is LinearLayoutManager -> manager.scrollToPositionWithOffset(position, offset)
        is StaggeredGridLayoutManager -> manager.scrollToPositionWithOffset(position, offset)
    }
}

fun RecyclerView.addDivider(
    orientation: Int = RecyclerView.HORIZONTAL,
    spacing: Float,
    @ColorInt color: Int
) {
    CandyDivider().setOrientation(orientation)
        .setSpacing(spacing)
        .setDividerColor(color)
        .into(this)
}

fun RecyclerView.addDividerHorizontal(spacing: Float, @ColorInt color: Int) {
    CandyDivider().setOrientation(RecyclerView.HORIZONTAL)
        .setSpacing(spacing)
        .setDividerColor(color)
        .into(this)
}

fun RecyclerView.addDividerVertical(spacing: Float, color: String) {
    CandyDivider().setOrientation(RecyclerView.VERTICAL)
        .setSpacing(spacing)
        .setDividerColor(color)
        .into(this)
}

fun RecyclerView.addDivider(block: CandyDivider.() -> Unit) {
    val divider = CandyDivider()
    divider.block()
    divider.into(this)
}