package com.candy.ui.sheet

/**
 * OnStateChangedListener
 * @author: ChenYang
 * @date: 2024-03-05 15:47
 */
fun interface OnStateChangedListener {
    fun onStateChanged(state: SheetState)
}