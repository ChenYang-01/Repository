package com.candy.ui.shape

import android.content.Context
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout

/**
 * ShapedConstraintLayout
 * @author: ChenYang
 * @date: 2023-03-11 21:36
 */
open class ShapedConstraintLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : ConstraintLayout(context, attrs, defStyleAttr),
    IShapedView by ShapedViewDelegate(context, attrs) {

    init {
        this.init()
    }

    protected open fun init() {
        into(this)
    }
}