package com.candy.ui.dialog

import com.candy.ui.dialog.animator.BgAnimator
import com.candy.ui.dialog.animator.ContentAnimator

/**
 * AnimatorFactory
 * @author: ChenYang
 * @date: 2025-12-22 11:11
 */
open class AnimatorFactory {
    open fun createContentAnimator(): ContentAnimator {
        return ContentAnimator()
    }

    open fun createBgAnimator(): BgAnimator {
        return BgAnimator()
    }
}