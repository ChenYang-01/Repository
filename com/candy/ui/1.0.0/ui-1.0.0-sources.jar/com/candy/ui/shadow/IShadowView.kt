package com.candy.ui.shadow

import android.view.View
import com.candy.ui.StateType
import com.candy.ui.annotation.RenderMode
import com.google.android.material.shape.CornerFamily
import com.google.android.material.shape.CornerSize
import com.google.android.material.shape.CornerTreatment
import com.google.android.material.shape.EdgeTreatment
import com.google.android.material.shape.ShapeAppearanceModel

/**
 * IShadowAttrs
 * @author: ChenYang
 * @date: 2025-05-06 14:51
 */
interface IShadowView {
    /**
     * 状态切换类型[StateType]
     */
    var stateType: StateType

    /**
     * 内容区域的颜色
     */
    var contentColor: Int
    var contentColorState: Int
    var contentColorDisable: Int

    /**
     * 边框颜色
     */
    var strokeColor: Int
    var strokeColorState: Int
    var strokeColorDisable: Int

    /**
     * 边框宽度
     */
    var strokeWidth: Float

    /**
     * [stateType]状态时的边框宽度
     */
    var strokeWidthState: Float

    /**
     * [View.setEnabled]为false时的边框宽度
     */
    var strokeWidthDisable: Float

    /**
     * 是否启用阴影，为false时如果[autoInset]为true，且设置了[shadowElevation]，显示效果会与为true时
     * 保持一致
     */
    var shadowEnable: Boolean

    /**
     * 阴影的颜色
     */
    var shadowColour: Int

    /**
     * 阴影的大小
     */
    var shadowElevation: Float

    /**
     * 阴影的偏移
     */
    var shadowOffsetY: Float

    /**
     * 阴影的偏移
     */
    var shadowOffsetX: Float

    /**
     * 阴影颜色是否与[contentColor]保持一致，如果为true[shadowColour]将无效
     */
    var shadowFollowContent: Boolean

    /**
     * 自动为Drawable添加padding，padding的大小根据[shadowElevation]、
     * [shadowOffsetX]、[shadowOffsetY]计算
     */
    var autoInset: Boolean

    /**
     * drawable设置到View上的模式[RenderMode]
     */
    var renderMode: Int

    /**
     * 左上角大小
     */
    val topLeftCornerSize: Float

    /**
     * 右上角大小
     */
    val topRightCornerSize: Float

    /**
     * 左下角大小
     */
    val bottomLeftCornerSize: Float

    /**
     * 右下角大小
     */
    val bottomRightCornerSize: Float

    /**
     * 左上角处理，默认为[com.google.android.material.shape.RoundedCornerTreatment]
     */
    val topLeftCorner: CornerTreatment

    /**
     * 右上角处理，默认为[com.google.android.material.shape.RoundedCornerTreatment]
     */
    val topRightCorner: CornerTreatment

    /**
     * 左下角处理，默认为[com.google.android.material.shape.RoundedCornerTreatment]
     */
    val bottomLeftCorner: CornerTreatment

    /**
     * 右下角处理，默认为[com.google.android.material.shape.RoundedCornerTreatment]
     */
    val bottomRightCorner: CornerTreatment

    /**
     * 左边处理，可以使用[com.google.android.material.shape.TriangleEdgeTreatment]添加三角等
     */
    val leftEdge: EdgeTreatment

    /**
     * 顶边处理，可以使用[com.google.android.material.shape.TriangleEdgeTreatment]添加三角等
     */
    val topEdge: EdgeTreatment

    /**
     * 右边处理，可以使用[com.google.android.material.shape.TriangleEdgeTreatment]添加三角等
     */
    val rightEdge: EdgeTreatment

    /**
     * 底边处理，可以使用[com.google.android.material.shape.TriangleEdgeTreatment]添加三角等
     */
    val bottomEdge: EdgeTreatment

    var contentColorDirty: Boolean
    var strokeColorDirty: Boolean
    val shapedBuilder: ShapeAppearanceModel.Builder

    fun setStateType(stateType: StateType): IShadowView {
        contentColorDirty = true
        strokeColorDirty = true
        this.stateType = stateType
        return this
    }

    fun setContentColor(color: Int): IShadowView {
        contentColorDirty = true
        this.contentColor = color
        return this
    }

    fun setContentColorState(color: Int): IShadowView {
        contentColorDirty = true
        this.contentColorState = color
        return this
    }

    fun setContentColorDisable(color: Int): IShadowView {
        contentColorDirty = true
        this.contentColorDisable = color
        return this
    }

    fun setStrokeColor(color: Int): IShadowView {
        strokeColorDirty = true
        this.strokeColor = color
        return this
    }

    fun setStrokeColorState(color: Int): IShadowView {
        strokeColorDirty = true
        this.strokeColorState = color
        return this
    }

    fun setStrokeColorDisable(color: Int): IShadowView {
        strokeColorDirty = true
        this.strokeColorDisable = color
        return this
    }

    fun setStrokeWidth(width: Float): IShadowView {
        this.strokeWidth = width
        return this
    }

    fun setStrokeWidthState(width: Float): IShadowView {
        this.strokeWidthState = width
        return this
    }

    fun setStrokeWidthDisable(width: Float): IShadowView {
        this.strokeWidthDisable = width
        return this
    }

    fun setShadowEnable(enable: Boolean): IShadowView {
        this.shadowEnable = enable
        return this
    }

    fun setShadowElevation(elevation: Float): IShadowView {
        this.shadowElevation = elevation
        return this
    }

    fun setShadowColor(color: Int): IShadowView {
        this.shadowColour = color
        return this
    }

    fun setShadowOffsetY(offset: Float): IShadowView {
        this.shadowOffsetY = offset
        return this
    }

    fun setShadowOffsetX(offset: Float): IShadowView {
        this.shadowOffsetX = offset
        return this
    }

    fun setShadowFollowContent(shadowFollowContent: Boolean): IShadowView {
        this.shadowFollowContent = shadowFollowContent
        return this
    }

    fun setAutoInset(autoInset: Boolean): IShadowView {
        this.autoInset = autoInset
        return this
    }

    fun setRenderMode(@RenderMode renderMode: Int): IShadowView {
        this.renderMode = renderMode
        return this
    }

    fun setAllCornerSize(cornerSize: CornerSize): IShadowView {
        shapedBuilder.setAllCornerSizes(cornerSize)
        return this
    }

    fun setAllCornerSize(cornerSize: Float): IShadowView {
        shapedBuilder.setAllCornerSizes(cornerSize)
        return this
    }

    fun setAllCorners(cornerTreatment: CornerTreatment): IShadowView {
        shapedBuilder.setAllCorners(cornerTreatment)
        return this
    }

    fun setAllCorners(cornerFamily: Int, cornerSize: Float): IShadowView {
        shapedBuilder.setAllCorners(cornerFamily, cornerSize)
        return this
    }

    fun setAllCorners(cornerFamily: Int, cornerSize: CornerSize): IShadowView {
        shapedBuilder.setTopLeftCorner(cornerFamily, cornerSize)
            .setTopRightCorner(cornerFamily, cornerSize)
            .setBottomLeftCorner(cornerFamily, cornerSize)
            .setBottomRightCorner(cornerFamily, cornerSize)
        return this
    }

    fun setTopLeftCornerSize(cornerSize: CornerSize): IShadowView {
        shapedBuilder.setTopLeftCornerSize(cornerSize)
        return this
    }

    fun setTopLeftCornerSize(cornerSize: Float): IShadowView {
        shapedBuilder.setAllCornerSizes(cornerSize)
        return this
    }

    fun setTopLeftCorner(cornerTreatment: CornerTreatment): IShadowView {
        shapedBuilder.setTopLeftCorner(cornerTreatment)
        return this
    }

    fun setTopLeftCorner(
        @CornerFamily cornerFamily: Int,
        cornerSize: CornerSize
    ): IShadowView {
        shapedBuilder.setTopLeftCorner(cornerFamily, cornerSize)
        return this
    }

    fun setTopLeftCorner(cornerFamily: Int, cornerSize: Float): IShadowView {
        shapedBuilder.setTopLeftCorner(cornerFamily, cornerSize)
        return this
    }

    fun setTopRightCornerSize(cornerSize: CornerSize): IShadowView {
        shapedBuilder.setTopRightCornerSize(cornerSize)
        return this
    }

    fun setTopRightCornerSize(cornerSize: Float): IShadowView {
        shapedBuilder.setTopRightCornerSize(cornerSize)
        return this
    }

    fun setTopRightCorner(cornerTreatment: CornerTreatment): IShadowView {
        shapedBuilder.setTopRightCorner(cornerTreatment)
        return this
    }

    fun setTopRightCorner(cornerFamily: Int, cornerSize: CornerSize): IShadowView {
        shapedBuilder.setTopRightCorner(cornerFamily, cornerSize)
        return this
    }

    fun setTopRightCorner(cornerFamily: Int, cornerSize: Float): IShadowView {
        shapedBuilder.setTopRightCorner(cornerFamily, cornerSize)
        return this
    }

    fun setBottomLeftCornerSize(cornerSize: CornerSize): IShadowView {
        shapedBuilder.setBottomLeftCornerSize(cornerSize)
        return this
    }

    fun setBottomLeftCornerSize(cornerSize: Float): IShadowView {
        shapedBuilder.setBottomLeftCornerSize(cornerSize)
        return this
    }

    fun setBottomLeftCorner(cornerTreatment: CornerTreatment): IShadowView {
        shapedBuilder.setBottomLeftCorner(cornerTreatment)
        return this
    }

    fun setBottomLeftCorner(cornerFamily: Int, cornerSize: CornerSize): IShadowView {
        shapedBuilder.setBottomLeftCorner(cornerFamily, cornerSize)
        return this
    }

    fun setBottomLeftCorner(cornerFamily: Int, cornerSize: Float): IShadowView {
        shapedBuilder.setBottomLeftCorner(cornerFamily, cornerSize)
        return this
    }

    fun setBottomRightCornerSize(cornerSize: CornerSize): IShadowView {
        shapedBuilder.setBottomRightCornerSize(cornerSize)
        return this
    }

    fun setBottomRightCornerSize(cornerSize: Float): IShadowView {
        shapedBuilder.setBottomRightCornerSize(cornerSize)
        return this
    }

    fun setBottomRightCorner(cornerTreatment: CornerTreatment): IShadowView {
        shapedBuilder.setBottomRightCorner(cornerTreatment)
        return this
    }

    fun setBottomRightCorner(cornerFamily: Int, cornerSize: CornerSize): IShadowView {
        shapedBuilder.setBottomRightCorner(cornerFamily, cornerSize)
        return this
    }

    fun setBottomRightCorner(cornerFamily: Int, cornerSize: Float): IShadowView {
        shapedBuilder.setBottomRightCorner(cornerFamily, cornerSize)
        return this
    }

    fun setAllEdge(edgeTreatment: EdgeTreatment): IShadowView {
        shapedBuilder.setAllEdges(edgeTreatment)
        return this
    }

    fun setLeftEdge(edgeTreatment: EdgeTreatment): IShadowView {
        shapedBuilder.setLeftEdge(edgeTreatment)
        return this
    }

    fun setTopEdge(edgeTreatment: EdgeTreatment): IShadowView {
        shapedBuilder.setTopEdge(edgeTreatment)
        return this
    }

    fun setRightEdge(edgeTreatment: EdgeTreatment): IShadowView {
        shapedBuilder.setRightEdge(edgeTreatment)
        return this
    }

    fun setBottomEdge(edgeTreatment: EdgeTreatment): IShadowView {
        shapedBuilder.setBottomEdge(edgeTreatment)
        return this
    }

    fun setup()

    fun into(target: View)
}