package com.candy.ui.text

import android.content.Context
import android.content.res.ColorStateList
import android.util.AttributeSet
import android.widget.TextView
import androidx.core.content.withStyledAttributes
import com.candy.ui.R
import com.candy.ui.StateType
import com.candy.ui.StateType.CHECKED.androidState

/**
 * StateTextDelegate
 * @author: ChenYang
 * @date: 2025-05-07 14:16
 */
class StateTextDelegate(
    context: Context? = null,
    attrs: AttributeSet? = null,
    override var stateTextTarget: TextView? = null,
) : IStateText {

    override var textColorState: Int = 0
    override var textColorDisable: Int = 0
    override var stateTextStateType: StateType = StateType.NONE

    init {
        if (context != null && attrs != null) {
            initAttrs(context, attrs)
        }
    }

    private fun initAttrs(context: Context, attrs: AttributeSet?) {
        context.withStyledAttributes(attrs, R.styleable.StateView, 0, 0) {
            if (hasValue(R.styleable.StateView_candy_textColorState)) {
                textColorState = getColor(R.styleable.StateView_candy_textColorState, 0)
            }
            if (hasValue(R.styleable.StateView_candy_textColorDisable)) {
                textColorDisable = getColor(R.styleable.StateView_candy_textColorDisable, 0)
            }
        }
    }

    private fun getTextColor(): Int {
        require(stateTextTarget != null) { "stateTextTarget must not be null" }
        return if (stateTextTarget!!.textColors.isStateful) {
            stateTextTarget!!.textColors.getColorForState(
                intArrayOf(android.R.attr.state_enabled), 0
            )
        } else {
            stateTextTarget!!.textColors.defaultColor
        }
    }

    override fun setTextColorState(textColorState: Int): IStateText {
        setTextColor(getTextColor(), textColorState, textColorDisable)
        return this
    }

    override fun setTextColorDisable(textColorDisable: Int): IStateText {
        setTextColor(getTextColor(), textColorState, textColorDisable)
        return this
    }

    override fun setTextColor(
        textColor: Int,
        textColorState: Int,
        textColorDisable: Int
    ): IStateText {
        this.textColorState = textColorState
        this.textColorDisable = textColorDisable
        val states = mutableListOf<List<Int>>()
        val colors = mutableListOf<Int>()
        if (textColorState != 0 && stateTextStateType != StateType.NONE) {
            states.add(listOf(android.R.attr.state_enabled, -stateTextStateType.androidState))
            colors.add(textColor)
            states.add(listOf(android.R.attr.state_enabled, stateTextStateType.androidState))
            colors.add(textColorState)
        } else {
            states.add(listOf(android.R.attr.state_enabled))
            colors.add(textColor)
        }
        if (this.textColorDisable == 0) {
            this.textColorDisable = textColor
        }
        states.add(listOf(-android.R.attr.state_enabled))
        colors.add(textColorDisable)
        stateTextTarget!!.setTextColor(
            ColorStateList(states.map { it.toIntArray() }.toTypedArray(), colors.toIntArray())
        )
        return this
    }

    override fun setStateTextStateType(stateType: StateType): IStateText {
        super.setStateTextStateType(stateType)
        setTextColor(getTextColor(), textColorState, textColorDisable)
        return this
    }
}