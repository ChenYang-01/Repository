package com.candy.ui

import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.view.View
import androidx.annotation.ColorInt
import androidx.core.graphics.drawable.toDrawable
import androidx.core.graphics.toColorInt
import androidx.core.graphics.withSave
import androidx.core.view.forEach
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ItemDecoration
import kotlin.math.roundToInt

/**
 * [RecyclerView] 高级分割线工具类
 *
 * 功能特性：
 * 1. 支持 [LinearLayoutManager] 和 [GridLayoutManager]。
 * 2. 完美适配 [GridLayoutManager] 的 SpanSizeLookup（非对称网格）。
 * 3. 采用“剩余空间平分算法”，确保网格布局下各 Item 宽度完全一致。
 * 4. 完美支持 Item 增删动画（同步绘制 Translation 偏移）。
 * 5. 支持首尾绘制、边距穿透、对接模式等高级配置。
 *
 * @author: ChenYang
 * @date: 2023-12-11
 */
open class CandyDivider : ItemDecoration() {

    /** 分割线间距 (px) */
    private var spacing = 0

    /** 分割线样式 */
    private var drawable: Drawable? = null

    /** 绘制方向：HORIZONTAL(水平) 或 VERTICAL(垂直) */
    private var orientation: Int = RecyclerView.HORIZONTAL

    /** 是否绘制第一个 Item 之前的线 */
    private var isDrawFirst = false

    /** 是否绘制最后一个 Item 之后的线 */
    private var isDrawLast = false

    /** 分割线是否包含在 Item 的 Margin 空间内 */
    private var includeMargin = true

    /** 水平分割线是否向左右对接延伸 */
    private var dockingHorizontal = true

    /** 垂直分割线是否向上下对接延伸 */
    private var dockingVertical = false

    /** 分割线起始缩进 */
    private var startPadding = 0

    /** 分割线顶部缩进 */
    private var topPadding = 0

    /** 分割线结束缩进 */
    private var endPadding = 0

    /** 分割线底部缩进 */
    private var bottomPadding = 0

    /**
     * 核心绘制逻辑：负责在 Canvas 上画出分割线
     */
    override fun onDraw(canvas: Canvas, parent: RecyclerView, state: RecyclerView.State) {
        val drawable = drawable ?: return

        canvas.withSave {
            parent.forEach { child ->
                val position = parent.getChildAdapterPosition(child)
                // 过滤无效位置
                if (position == RecyclerView.NO_POSITION) return@forEach

                val params = child.layoutParams as RecyclerView.LayoutParams
                // 根据配置决定是否扣除 Margin 占用的空间
                val startMargin = if (includeMargin) 0 else params.marginStart
                val topMargin = if (includeMargin) 0 else params.topMargin
                val endMargin = if (includeMargin) 0 else params.marginEnd
                val bottomMargin = if (includeMargin) 0 else params.bottomMargin

                // 获取 View 的位移量，使分割线能跟随 Item 动画（如平移、删除动画）
                val tx = child.translationX.roundToInt()
                val ty = child.translationY.roundToInt()

                if (orientation == RecyclerView.HORIZONTAL) {
                    // --- 绘制水平分割线 ---
                    val dockingOffset = if (dockingHorizontal) spacing else 0
                    val leftOffset = if (isFirstColumn(child, parent)) dockingOffset else 0

                    // 计算线段左右边界（结合 Padding 和 Docking）
                    val left = child.left - startMargin + startPadding - leftOffset + tx
                    val right = child.right + endMargin - endPadding + dockingOffset + tx
                    // 线段顶部紧挨 Item 底部（考虑 Margin）
                    val top = child.bottom + bottomMargin + ty
                    val bottom = if (!isDrawLast && isLastRow(child, parent)) top else top + spacing

                    // 如果开启了绘制首行，在第一行上方额外绘制一条线
                    if (isDrawFirst && isFirstRow(child, parent)) {
                        val firstBottom = child.top - topMargin + ty
                        val firstTop = firstBottom - spacing
                        drawable.setBounds(left, firstTop, right, firstBottom)
                        drawable.draw(this)
                    }

                    drawable.setBounds(left, top, right, bottom)
                    drawable.draw(this)

                } else {
                    // --- 绘制垂直分割线 ---
                    val dockingOffset = if (dockingVertical) spacing else 0
                    val topOffset = if (isFirstRow(child, parent)) dockingOffset else 0

                    val top = child.top - topMargin + topPadding - topOffset + ty
                    val bottom = child.bottom + bottomMargin - bottomPadding + dockingOffset + ty
                    val left = child.right + endMargin + tx
                    val right = if (!isDrawLast && isLastColumn(
                            child, parent
                        )) left else left + spacing

                    // 如果开启了绘制首列，在第一列左侧额外绘制一条线
                    if (isDrawFirst && isFirstColumn(child, parent)) {
                        val firstRight = child.left - startMargin + tx
                        val firstLeft = firstRight - spacing
                        drawable.setBounds(firstLeft, top, firstRight, bottom)
                        drawable.draw(this)
                    }

                    drawable.setBounds(left, top, right, bottom)
                    drawable.draw(this)
                }
            }
        }
    }

    /**
     * 预留空间逻辑：负责给分割线留出空白区域
     */
    override fun getItemOffsets(
        outRect: Rect,
        view: View,
        parent: RecyclerView,
        state: RecyclerView.State
    ) {
        val layoutManager = parent.layoutManager ?: return
        when (layoutManager) {
            is GridLayoutManager -> getItemOffsetsWhenGrid(outRect, view, parent)
            is LinearLayoutManager -> getItemOffsetsWhenLinear(outRect, view, parent)
        }
    }

    /**
     * 线性布局偏移逻辑
     */
    private fun getItemOffsetsWhenLinear(outRect: Rect, view: View, parent: RecyclerView) {
        var left = 0;
        var top = 0;
        var right = 0;
        var bottom = 0

        if (orientation == RecyclerView.VERTICAL) {
            // 垂直分割线：左右留空
            left = if (isDrawFirst && isFirstColumn(view, parent)) spacing else 0
            right = if (!isDrawLast && isLastColumn(view, parent)) 0 else spacing
        } else {
            // 水平分割线：上下留空
            top = if (isDrawFirst && isFirstRow(view, parent)) spacing else 0
            bottom = if (!isDrawLast && isLastRow(view, parent)) 0 else spacing
        }
        outRect.set(left, top, right, bottom)
    }

    /**
     * 网格布局偏移逻辑
     * 采用公式：left = spanIndex * spacing / spanCount
     * 这样可以保证每个 item 的 (outRect.left + outRect.right) 之和在每一行都是相等的，
     * 从而保证每个 item 的真实宽度完全一致。
     */
    private fun getItemOffsetsWhenGrid(outRect: Rect, view: View, parent: RecyclerView) {
        val lm = parent.layoutManager as GridLayoutManager
        val isVertical = lm.orientation == RecyclerView.VERTICAL
        val lp = view.layoutParams as GridLayoutManager.LayoutParams
        val spanIndex = lp.spanIndex
        val spanCount = lm.spanCount

        var left = 0;
        var top = 0;
        var right = 0;
        var bottom = 0

        // 情况1：该分割线方向与布局滚动方向平行
        if ((isVertical && orientation == RecyclerView.HORIZONTAL) || (!isVertical && orientation == RecyclerView.VERTICAL)) {
            if (isVertical) {
                top = if (isDrawFirst && isFirstRow(view, parent)) spacing else 0
                bottom = if (!isDrawLast && isLastRow(view, parent)) 0 else spacing
            } else {
                left = if (isDrawFirst && isFirstColumn(view, parent)) spacing else 0
                right = if (!isDrawLast && isLastColumn(view, parent)) 0 else spacing
            }
        } else {
            // 情况2：该分割线方向与布局滚动方向垂直（需要平分剩余空间）
            when {
                isDrawFirst && isDrawLast -> {
                    left = spacing - spanIndex * spacing / spanCount
                    right = (spanIndex + lp.spanSize) * spacing / spanCount
                }
                isDrawFirst && !isDrawLast -> {
                    left = spacing; right = 0
                }
                !isDrawFirst && isDrawLast -> {
                    left = 0; right = spacing
                }
                else -> {
                    left = spanIndex * spacing / spanCount
                    right = spacing - (spanIndex + lp.spanSize) * spacing / spanCount
                }
            }
            // 如果是横向网格，上面的 left/right 计算结果实际对应的是 top/bottom 的间距
            if (!isVertical) {
                top = left; bottom = right
                left = 0; right = 0
            }
        }
        outRect.set(left, top, right, bottom)
    }

    protected open fun isFirstRow(child: View, parent: RecyclerView): Boolean {
        val position = parent.getChildAdapterPosition(child)
                           .takeIf { it != RecyclerView.NO_POSITION } ?: return false
        val lm = parent.layoutManager ?: return false
        return when (lm) {
            is GridLayoutManager -> {
                if (lm.orientation == RecyclerView.VERTICAL) {
                    // 垂直网格：GroupIndex 为 0 代表第一行
                    lm.spanSizeLookup.getSpanGroupIndex(position, lm.spanCount) == 0
                } else {
                    // 水平网格：SpanIndex 为 0 代表第一行
                    lm.spanSizeLookup.getSpanIndex(position, lm.spanCount) == 0
                }
            }
            is LinearLayoutManager -> {
                if (lm.orientation == RecyclerView.VERTICAL) position == 0 else true
            }
            else -> false
        }
    }

    protected open fun isLastRow(child: View, parent: RecyclerView): Boolean {
        val position = parent.getChildAdapterPosition(child)
                           .takeIf { it != RecyclerView.NO_POSITION } ?: return false
        val itemCount = parent.adapter?.itemCount ?: 0
        val lm = parent.layoutManager ?: return false
        return when (lm) {
            is GridLayoutManager -> {
                if (lm.orientation == RecyclerView.VERTICAL) {
                    // 判断是否与最后一个 Item 在同一组（行）
                    val lastGroupIndex = lm.spanSizeLookup.getSpanGroupIndex(
                        itemCount - 1, lm.spanCount
                    )
                    lm.spanSizeLookup.getSpanGroupIndex(position, lm.spanCount) == lastGroupIndex
                } else {
                    // 水平网格：SpanIndex + SpanSize 等于总数代表触底
                    val lp = child.layoutParams as GridLayoutManager.LayoutParams
                    lp.spanIndex + lp.spanSize == lm.spanCount
                }
            }
            is LinearLayoutManager -> {
                if (lm.orientation == RecyclerView.VERTICAL) position == itemCount - 1 else true
            }
            else -> false
        }
    }

    protected open fun isFirstColumn(child: View, parent: RecyclerView): Boolean {
        val position = parent.getChildAdapterPosition(child)
                           .takeIf { it != RecyclerView.NO_POSITION } ?: return false
        val lm = parent.layoutManager ?: return false
        return when (lm) {
            is GridLayoutManager -> {
                if (lm.orientation == RecyclerView.VERTICAL) {
                    lm.spanSizeLookup.getSpanIndex(position, lm.spanCount) == 0
                } else {
                    lm.spanSizeLookup.getSpanGroupIndex(position, lm.spanCount) == 0
                }
            }
            is LinearLayoutManager -> {
                if (lm.orientation == RecyclerView.VERTICAL) true else position == 0
            }
            else -> false
        }
    }

    protected open fun isLastColumn(child: View, parent: RecyclerView): Boolean {
        val position = parent.getChildAdapterPosition(child)
                           .takeIf { it != RecyclerView.NO_POSITION } ?: return false
        val itemCount = parent.adapter?.itemCount ?: 0
        val lm = parent.layoutManager ?: return false
        return when (lm) {
            is GridLayoutManager -> {
                if (lm.orientation == RecyclerView.VERTICAL) {
                    val lp = child.layoutParams as GridLayoutManager.LayoutParams
                    lp.spanIndex + lp.spanSize == lm.spanCount
                } else {
                    val lastGroupIndex = lm.spanSizeLookup.getSpanGroupIndex(
                        itemCount - 1, lm.spanCount
                    )
                    lm.spanSizeLookup.getSpanGroupIndex(position, lm.spanCount) == lastGroupIndex
                }
            }
            is LinearLayoutManager -> {
                if (lm.orientation == RecyclerView.VERTICAL) true else position == itemCount - 1
            }
            else -> false
        }
    }

    /** 设置分割线绘制方向：[RecyclerView.HORIZONTAL] 或 [RecyclerView.VERTICAL] */
    fun setOrientation(orientation: Int) = apply {
        this.orientation = orientation
    }

    /** 设置分割线粗细（px） */
    fun setSpacing(spacing: Float) = apply {
        this.spacing = spacing.toInt()
    }

    /** 设置分割线颜色 */
    fun setDividerColor(@ColorInt color: Int) = apply {
        this.drawable = color.toDrawable()
    }

    /** 设置分割线颜色 */
    fun setDividerColor(color: String) = apply {
        this.drawable = color.toColorInt().toDrawable()
    }

    /** 设置自定义 Drawable 作为分割线 */
    fun setDividerDrawable(drawable: Drawable) = apply {
        this.drawable = drawable
    }

    /** 是否绘制外边缘（同时设置首尾） */
    fun setDrawEdge(drawEdge: Boolean) = apply {
        this.isDrawFirst = drawEdge; this.isDrawLast = drawEdge
    }

    /** 是否绘制第一个 Item 上方/左侧的线 */
    fun setDrawFirst(isDrawFirst: Boolean) = apply {
        this.isDrawFirst = isDrawFirst
    }

    /** 是否绘制最后一个 Item 下方/右侧的线 */
    fun setDrawLast(isDrawLast: Boolean) = apply {
        this.isDrawLast = isDrawLast
    }

    /** 分割线是否包含在 Item Margin 内部（默认不包含） */
    fun setIncludeMargin(includeMargin: Boolean) = apply {
        this.includeMargin = includeMargin
    }

    /** 当绘制水平分割线时，是否自动延伸以填补垂直线留下的空隙 */
    fun setDockingHorizontal(docking: Boolean) = apply {
        this.dockingHorizontal = docking
    }

    /** 当绘制垂直分割线时，是否自动延伸以填补水平线留下的空隙 */
    fun setDockingVertical(docking: Boolean) = apply {
        this.dockingVertical = docking
    }

    fun setStartPadding(padding: Int) = apply { this.startPadding = padding }
    fun setTopPadding(padding: Int) = apply { this.topPadding = padding }
    fun setEndPadding(padding: Int) = apply { this.endPadding = padding }
    fun setBottomPadding(padding: Int) = apply { this.bottomPadding = padding }

    /** 应用到指定的 RecyclerView */
    fun into(recyclerView: RecyclerView) = apply { recyclerView.addItemDecoration(this) }
}