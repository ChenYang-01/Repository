package com.candy.compose

import androidx.compose.animation.core.DecayAnimationSpec
import androidx.compose.animation.rememberSplineBasedDecay
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.candy.kit.ext.getInRange
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import java.util.Calendar

@Stable
open class TimeWheelState(
    yearRange: IntRange,
    val yearState: WheelState,
    val monthState: WheelState,
    val dayState: WheelState,
    val hourState: WheelState,
    val minuteState: WheelState,
    val secondsState: WheelState
) {
    val yearList = yearRange.toList()
    val monthList = (1..12).toList()
    val hourList = (0..23).toList()
    val minuteList = (0..59).toList()
    val secondsList = (0..59).toList()
    val dayList by derivedStateOf {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, yearList[yearState.currentSelection])
            set(Calendar.MONTH, monthList[monthState.currentSelection] - 1)
        }
        val maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        (1..maxDays).toList()
    }
    val selectedCalendar: Calendar
        get() = Calendar.getInstance().apply {
            set(
                yearList[yearState.currentSelection],
                monthList[monthState.currentSelection] - 1,
                dayList.getInRange(dayState.currentSelection),
                hourList[hourState.currentSelection],
                minuteList[minuteState.currentSelection],
                secondsList[secondsState.currentSelection]
            )
        }

    internal val displayDayList = mutableStateListOf<Int>()

    init {
        syncDisplayDayList()
    }

    internal fun syncDisplayDayList() {
        val newList = dayList
        if (displayDayList != newList) {
            displayDayList.clear()
            displayDayList.addAll(newList)
        }
    }

    suspend fun scrollToDate(date: Calendar, animated: Boolean = true) = coroutineScope {
        val year = yearList.indexOf(date.get(Calendar.YEAR)).coerceIn(yearList.indices)
        val month = monthList.indexOf(date.get(Calendar.MONTH)).coerceIn(monthList.indices)
        val day = dayList.indexOf(date.get(Calendar.DAY_OF_MONTH)).coerceIn(dayList.indices)
        val hour = hourList.indexOf(date.get(Calendar.HOUR_OF_DAY)).coerceIn(hourList.indices)
        val minute = minuteList.indexOf(date.get(Calendar.MINUTE)).coerceIn(minuteList.indices)
        val seconds = secondsList.indexOf(date.get(Calendar.SECOND)).coerceIn(secondsList.indices)
        launch {
            yearState.scrollToIndex(year, animated)
        }
        launch {
            monthState.scrollToIndex(month, animated)
        }
        launch {
            dayState.scrollToIndex(day, animated)
        }
        launch {
            hourState.scrollToIndex(hour, animated)
        }
        launch {
            minuteState.scrollToIndex(minute, animated)
        }
        launch {
            secondsState.scrollToIndex(seconds, animated)
        }
    }
}

@Composable
fun rememberTimeWheelState(
    yearRange: IntRange = 1970..2100,
    initialDate: Calendar = remember { Calendar.getInstance() }
): TimeWheelState {
    val yearState = rememberWheelState()
    val monthState = rememberWheelState()
    val dayState = rememberWheelState()
    val hourState = rememberWheelState()
    val minuteState = rememberWheelState()
    val secondsState = rememberWheelState()

    val state = remember {
        TimeWheelState(
            yearRange = yearRange,
            yearState = yearState,
            monthState = monthState,
            dayState = dayState,
            hourState = hourState,
            minuteState = minuteState,
            secondsState = secondsState
        )
    }
    LaunchedEffect(yearState.isScrolling, monthState.isScrolling) {
        if (!monthState.isScrolling && !yearState.isScrolling) {
            state.syncDisplayDayList()
            dayState.scrollToIndex(dayState.currentSelection.coerceIn(state.dayList.indices), false)
        }
    }

    LaunchedEffect(Unit) {
        state.scrollToDate(initialDate, animated = false)
    }

    return state
}

class TimeWheelScope(val state: TimeWheelState, private val rowScope: RowScope) :
    RowScope by rowScope {

    @Composable
    fun YearWheel(
        modifier: Modifier = Modifier,
        isLooping: Boolean = true,
        visibleItemsCount: Int = 5,
        wheelRadius: Dp = 120.dp,
        itemHeight: Dp = 50.dp,
        decay: DecayAnimationSpec<Float> = rememberSplineBasedDecay(),
        offsetX: (offsetFraction: Float) -> Dp = { 0.dp },
        onItemSelected: (Int) -> Unit = {},
        content: @Composable WheelScope<Int>.() -> Unit
    ) {
        Wheel(
            items = state.yearList,
            state = state.yearState,
            modifier = modifier,
            isLooping = isLooping,
            visibleItemsCount = visibleItemsCount,
            wheelRadius = wheelRadius,
            itemHeight = itemHeight,
            decay = decay,
            offsetX = offsetX,
            onItemSelected = onItemSelected,
            content = content
        )
    }

    @Composable
    fun MonthWheel(
        modifier: Modifier = Modifier,
        isLooping: Boolean = true,
        visibleItemsCount: Int = 5,
        wheelRadius: Dp = 120.dp,
        itemHeight: Dp = 50.dp,
        decay: DecayAnimationSpec<Float> = rememberSplineBasedDecay(),
        offsetX: (offsetFraction: Float) -> Dp = { 0.dp },
        onItemSelected: (Int) -> Unit = {},
        content: @Composable WheelScope<Int>.() -> Unit
    ) = Wheel(
        items = state.monthList,
        state = state.monthState,
        modifier = modifier,
        isLooping = isLooping,
        visibleItemsCount = visibleItemsCount,
        wheelRadius = wheelRadius,
        itemHeight = itemHeight,
        decay = decay,
        offsetX = offsetX,
        onItemSelected = onItemSelected,
        content = content
    )

    @Composable
    fun DayWheel(
        modifier: Modifier = Modifier,
        isLooping: Boolean = true,
        visibleItemsCount: Int = 5,
        wheelRadius: Dp = 120.dp,
        itemHeight: Dp = 50.dp,
        decay: DecayAnimationSpec<Float> = rememberSplineBasedDecay(),
        offsetX: (offsetFraction: Float) -> Dp = { 0.dp },
        onItemSelected: (Int) -> Unit = {},
        content: @Composable WheelScope<Int>.() -> Unit
    ) = Wheel(
        items = state.displayDayList,
        state = state.dayState,
        modifier = modifier,
        isLooping = isLooping,
        visibleItemsCount = visibleItemsCount,
        wheelRadius = wheelRadius,
        itemHeight = itemHeight,
        decay = decay,
        offsetX = offsetX,
        onItemSelected = onItemSelected,
        content = content
    )

    @Composable
    fun HourWheel(
        modifier: Modifier = Modifier,
        isLooping: Boolean = true,
        visibleItemsCount: Int = 5,
        wheelRadius: Dp = 120.dp,
        itemHeight: Dp = 50.dp,
        decay: DecayAnimationSpec<Float> = rememberSplineBasedDecay(),
        offsetX: (offsetFraction: Float) -> Dp = { 0.dp },
        onItemSelected: (Int) -> Unit = {},
        content: @Composable WheelScope<Int>.() -> Unit
    ) = Wheel(
        items = state.hourList,
        state = state.hourState,
        modifier = modifier,
        isLooping = isLooping,
        visibleItemsCount = visibleItemsCount,
        wheelRadius = wheelRadius,
        itemHeight = itemHeight,
        decay = decay,
        offsetX = offsetX,
        onItemSelected = onItemSelected,
        content = content
    )

    @Composable
    fun MinuteWheel(
        modifier: Modifier = Modifier,
        isLooping: Boolean = true,
        visibleItemsCount: Int = 5,
        wheelRadius: Dp = 120.dp,
        itemHeight: Dp = 50.dp,
        decay: DecayAnimationSpec<Float> = rememberSplineBasedDecay(),
        offsetX: (offsetFraction: Float) -> Dp = { 0.dp },
        onItemSelected: (Int) -> Unit = {},
        content: @Composable WheelScope<Int>.() -> Unit
    ) = Wheel(
        items = state.minuteList,
        state = state.minuteState,
        modifier = modifier,
        isLooping = isLooping,
        visibleItemsCount = visibleItemsCount,
        wheelRadius = wheelRadius,
        itemHeight = itemHeight,
        decay = decay,
        offsetX = offsetX,
        onItemSelected = onItemSelected,
        content = content
    )

    @Composable
    fun SecondWheel(
        modifier: Modifier = Modifier,
        isLooping: Boolean = true,
        visibleItemsCount: Int = 5,
        wheelRadius: Dp = 120.dp,
        itemHeight: Dp = 50.dp,
        decay: DecayAnimationSpec<Float> = rememberSplineBasedDecay(),
        offsetX: (offsetFraction: Float) -> Dp = { 0.dp },
        onItemSelected: (Int) -> Unit = {},
        content: @Composable WheelScope<Int>.() -> Unit
    ) = Wheel(
        items = state.secondsList,
        state = state.secondsState,
        modifier = modifier,
        isLooping = isLooping,
        visibleItemsCount = visibleItemsCount,
        wheelRadius = wheelRadius,
        itemHeight = itemHeight,
        decay = decay,
        offsetX = offsetX,
        onItemSelected = onItemSelected,
        content = content
    )
}

@Composable
fun TimeWheel(
    state: TimeWheelState,
    modifier: Modifier = Modifier,
    content: @Composable TimeWheelScope.() -> Unit
) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        val scope = remember(state, this) { TimeWheelScope(state, this) }
        scope.content()
    }
}