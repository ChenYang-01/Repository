package com.candy.compose.dialog

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.DecayAnimationSpec
import androidx.compose.animation.core.tween
import androidx.compose.animation.rememberSplineBasedDecay
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.mapSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.candy.compose.ext.toColor
import com.candy.compose.sheet.BottomSheet
import com.candy.compose.sheet.BottomSheetState
import com.candy.compose.sheet.SheetDetent
import com.candy.compose.sheet.rememberBottomSheetState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * 显示在底部的Dialog，带slide动画
 *
 * @param modifier [Modifier]
 * @param dialogState Dialog的显示状态
 * @param dismissOnBackPress 是否点击返回键消失
 * @param dismissOnClickOutside 是否点击外部消失
 * @param backgroundColor Scrim颜色
 * @param dismissDelay 自动消失时间
 * @param isInterceptBackEvent 是否拦截返回事件，默认拦截
 * @param onDismiss 消失回调
 * @param content 需要显示的内容
 */
@Composable
fun BottomSheetDialog(
    dialogState: BottomSheetDialogState,
    modifier: Modifier = Modifier,
    dismissOnBackPress: Boolean = true,
    dismissOnClickOutside: Boolean = true,
    backgroundColor: Color = "#7F000000".toColor(),
    sheetEnabled: Boolean = true,
    imeAware: Boolean = false,
    dismissDelay: Long? = null,
    isInterceptBackEvent: Boolean = true,
    onDismiss: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    if (!dialogState.isVisible) return
    val sheetState = dialogState.sheetState

    val scope = rememberCoroutineScope()
    fun onDismissRequest() {
        scope.launch { dialogState.animateTo(SheetDetent.Hidden) }
    }

    val fromDetent by remember { mutableStateOf(SheetDetent.Hidden) }
    val toDetent by remember(sheetState.anchoredDraggableState.anchors) {
        mutableStateOf(
            sheetState.detents.filter { it != fromDetent }
                .maxBy { sheetState.anchoredDraggableState.anchors.positionOf(it) }
        )
    }
    val colorFraction by remember(dialogState.isSheetAttached) {
        if (dialogState.isSheetAttached) {
            derivedStateOf { sheetState.anchoredDraggableState.progress(fromDetent, toDetent) }
        } else {
            mutableFloatStateOf(0f)
        }
    }

    BaseDialog {
        Box(
            modifier = Modifier.fillMaxSize()
                .background(lerp(Color.Transparent, backgroundColor, colorFraction))
                .then(modifier)
                .clickable(
                    enabled = dismissOnClickOutside,
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = { onDismissRequest() }
                ),
            contentAlignment = Alignment.BottomCenter
        ) {
            Box(
                modifier = Modifier.clickable(
                    enabled = dismissOnClickOutside,
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {
                        // Consume clicks inside the sheet so only scrim clicks dismiss the dialog.
                    }
                )
            ) {
                DisposableEffect(Unit) {
                    onDispose {
                        dialogState.isVisible = false
                        dialogState.isSheetAttached = false
                        dialogState.sheetState.targetDetent = SheetDetent.Hidden
                        dialogState.pendingDetentChange?.cancel()
                        dialogState.pendingDetentChange = null
                    }
                }
                if (dialogState.isSheetAttached &&
                    sheetState.isIdle &&
                    sheetState.currentDetent == SheetDetent.Hidden) {
                    dialogState.isVisible = false
                }
                BottomSheet(
                    state = sheetState,
                    enabled = sheetEnabled,
                    imeAware = imeAware
                ) {
                    content()
                }
            }
        }
        if (isInterceptBackEvent) {
            BackHandler {
                val newDetent = sheetState.detents.filter {
                    sheetState.anchoredDraggableState.anchors.positionOf(it) >
                    sheetState.anchoredDraggableState.anchors.positionOf(sheetState.currentDetent)
                }.minBy { sheetState.anchoredDraggableState.anchors.positionOf(it) }
                if (!(!dismissOnBackPress && newDetent == SheetDetent.Hidden)) {
                    scope.launch {
                        sheetState.animateTo(newDetent)
                    }
                }
            }
        }
    }
}

@Composable
fun rememberBottomSheetDialogState(
    initialDetent: SheetDetent,
    detents: List<SheetDetent> = listOf(
        SheetDetent.Hidden, SheetDetent.Expanded
    ),
    animationSpec: AnimationSpec<Float> = tween(),
    velocityThreshold: () -> Dp = { 125.dp },
    positionalThreshold: (totalDistance: Dp) -> Dp = { 56.dp },
    confirmDetentChange: (SheetDetent) -> Boolean = { true },
    decayAnimationSpec: DecayAnimationSpec<Float> = rememberSplineBasedDecay()
): BottomSheetDialogState {
    val sheetState = rememberBottomSheetState(
        initialDetent = SheetDetent.Hidden,
        detents = detents,
        animationSpec = animationSpec,
        velocityThreshold = velocityThreshold,
        positionalThreshold = positionalThreshold,
        decayAnimationSpec = decayAnimationSpec,
        confirmDetentChange = confirmDetentChange,
    )
    val scope = rememberCoroutineScope()
    return rememberSaveable(
        saver = mapSaver(
            save = { state -> mapOf("detent" to state.currentDetent.identifier) },
            restore = { map ->
                val restoredDetent = detents.first { it.identifier == map["detent"] }
                BottomSheetDialogState(
                    initialDetent = restoredDetent,
                    sheetState = sheetState,
                    scope = scope
                )
            }
        ),
        init = {
            BottomSheetDialogState(
                initialDetent = initialDetent,
                sheetState = sheetState,
                scope = scope
            )
        }
    )
}

@Stable
class BottomSheetDialogState(
    internal val initialDetent: SheetDetent,
    internal val sheetState: BottomSheetState,
    internal val scope: CoroutineScope
) {
    internal var isVisible by mutableStateOf(false)
    internal var isSheetAttached by mutableStateOf(false)
    internal var pendingDetentChange: Job? = null

    val currentDetent: SheetDetent
        get() = sheetState.currentDetent

    var targetDetent: SheetDetent
        get() = sheetState.targetDetent
        set(value) {
            scope.launch {
                animateTo(value)
            }
        }

    val isIdle: Boolean
        get() = sheetState.isIdle

    init {
        isVisible = initialDetent != SheetDetent.Hidden
        if (isVisible) {
            animateTo(initialDetent)
        }
    }

    fun animateTo(value: SheetDetent) {
        scope.launch {
            isVisible = true
            if (isSheetAttached) {
                sheetState.animateTo(value)
            } else {
                pendingDetentChange?.cancel()
                pendingDetentChange = scope.launch {
                    awaitAttach()
                    sheetState.animateTo(value)
                }
                pendingDetentChange?.join()
            }
        }
    }

    fun jumpTo(value: SheetDetent) {
        isVisible = true
        if (isSheetAttached) {
            sheetState.jumpTo(value)
        } else {
            pendingDetentChange?.cancel()
            pendingDetentChange = scope.launch {
                awaitAttach()
                sheetState.jumpTo(value)
            }
        }
    }

    private suspend fun awaitAttach() {
        snapshotFlow { sheetState.offset }.filter { it > 0 }.first()
        isSheetAttached = true
    }
}
