package com.candy.compose.ext

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp

val Dp.px: Float
    @Composable
    get() = with(LocalDensity.current) { this@px.toPx() }

val Dp.roundPx: Int
    @Composable
    get() = with(LocalDensity.current) { this@roundPx.roundToPx() }