package com.candy.compose.ext

import androidx.compose.foundation.pager.PagerState

val PagerState.isLastPage: Boolean
    get() = currentPage == pageCount - 1

val PagerState.isFirstPage: Boolean
    get() = currentPage == 0

suspend fun PagerState.animateScrollToNext() {
    val target = currentPage + 1
    animateScrollToPage(target.coerceIn(0, pageCount - 1))
}

suspend fun PagerState.animateScrollToPre() {
    val target = currentPage - 1
    animateScrollToPage(target.coerceIn(0, pageCount - 1))
}