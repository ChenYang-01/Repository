package com.candy.compose.sheet

import android.util.Log
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.DecayAnimationSpec
import androidx.compose.animation.core.tween
import androidx.compose.animation.rememberSplineBasedDecay
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.mapSaver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.coerceIn
import androidx.compose.ui.unit.dp
import com.candy.compose.ext.buildModifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private fun Saver(
    animationSpec: AnimationSpec<Float>,
    coroutineScope: CoroutineScope,
    sheetDetents: List<SheetDetent>,
    velocityThreshold: () -> Float,
    positionalThreshold: (totalDistance: Float) -> Float,
    confirmDetentChange: (SheetDetent) -> Boolean,
    localDensity: () -> Density,
): Saver<BottomSheetState, *> =
    mapSaver(save = { mapOf("detent" to it.currentDetent.identifier) }, restore = { map ->
        val selectedDetentName = map["detent"]
        BottomSheetState(
            initialDetent = sheetDetents.first { it.identifier == selectedDetentName },
            detents = sheetDetents,
            coroutineScope = coroutineScope,
            animationSpec = animationSpec,
            velocityThreshold = velocityThreshold,
            positionalThreshold = positionalThreshold,
            confirmDetentChange = confirmDetentChange,
            density = localDensity
        )
    })

/**
 * Creates a [BottomSheetState]
 *
 * @param initialDetent The initial detent of the sheet.
 * @param detents The list of detents that the sheet can snap to.
 * @param animationSpec The animation spec to use for animating between detents.
 * @param confirmDetentChange Callback to confirm whether a detent change should be allowed.
 * @param decayAnimationSpec The animation spec to use for decay animations.
 * @param velocityThreshold The velocity threshold for determining whether to snap to the next detent.
 * @param positionalThreshold The positional threshold for determining whether to snap to the next detent.
 * @return A remembered [BottomSheetState] instance.
 */
@Composable
fun rememberBottomSheetState(
    initialDetent: SheetDetent,
    detents: List<SheetDetent> = listOf(SheetDetent.Hidden, SheetDetent.Expanded),
    animationSpec: AnimationSpec<Float> = tween(),
    confirmDetentChange: (SheetDetent) -> Boolean = { true },
    decayAnimationSpec: DecayAnimationSpec<Float> = rememberSplineBasedDecay(),
    velocityThreshold: () -> Dp = { 2000.dp },
    positionalThreshold: (totalDistance: Dp) -> Dp = { 56.dp },
): BottomSheetState {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    return rememberSaveable(
        saver = Saver(
            animationSpec = animationSpec,
            coroutineScope = scope,
            sheetDetents = detents,
            velocityThreshold = {
                with(density) {
                    velocityThreshold().toPx()
                }
            },
            positionalThreshold = { totalDistance ->
                with(density) {
                    positionalThreshold(totalDistance.toDp()).toPx()
                }
            },
            confirmDetentChange = confirmDetentChange,
            localDensity = { density })
    ) {
        BottomSheetState(
            initialDetent = initialDetent,
            detents = detents,
            coroutineScope = scope,
            animationSpec = animationSpec,
            velocityThreshold = {
                with(density) {
                    velocityThreshold().toPx()
                }
            },
            positionalThreshold = { totalDistance ->
                with(density) {
                    positionalThreshold(totalDistance.toDp()).toPx()
                }
            },
            confirmDetentChange = confirmDetentChange,
            density = { density })
    }
}

/**
 * A detent represents a stopping point for a bottom sheet.
 *
 * @property identifier A unique identifier for this detent.
 * @property calculateDetentHeight A function that calculates the height of this detent based on the container and sheet heights.
 */
@Immutable
class SheetDetent(val identifier: String, val calculateDetentHeight: (sheetHeight: Dp) -> Dp) {
    companion object {
        /**
         * A detent that expands the sheet to its full height.
         */
        val Expanded: SheetDetent = SheetDetent("expanded") { sheetHeight -> sheetHeight }

        /**
         * A detent that hides the sheet.
         */
        val Hidden: SheetDetent = SheetDetent("hidden") { _ -> 0.dp }
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other == null || this::class != other::class) return false

        other as SheetDetent

        return identifier == other.identifier
    }

    override fun hashCode(): Int {
        return identifier.hashCode()
    }

    override fun toString(): String {
        return "SheetDetent(identifier='$identifier')"
    }
}

class BottomSheetState(
    initialDetent: SheetDetent,
    detents: List<SheetDetent>,
    private val coroutineScope: CoroutineScope,
    animationSpec: AnimationSpec<Float>,
    velocityThreshold: () -> Float,
    positionalThreshold: (totalDistance: Float) -> Float,
    confirmDetentChange: (SheetDetent) -> Boolean,
    private val density: () -> Density
) {
    init {
        checkValidDetents(detents)
        check(detents.contains(initialDetent)) {
            "The initialDetent ${initialDetent.identifier} was not part of the included detents while creating the sheet's state."
        }
    }

    private fun checkValidDetents(detents: List<SheetDetent>) {
        check(detents.isNotEmpty()) {
            "Tried to create a bottom sheet without any detents. Make sure to pass at least one detent when creating your sheet's state."
        }

        val duplicates = detents.groupBy { it.identifier }
            .filter { it.value.size > 1 }
            .map { it.key }

        check(duplicates.isEmpty()) {
            "Detent identifiers need to be unique, but you passed the following detents multiple times: ${duplicates.joinToString { it }}."
        }
    }

    private var innerDetents: List<SheetDetent> by mutableStateOf(detents)

    var detents: List<SheetDetent>
        get() {
            return innerDetents
        }
        set(value) {
            checkValidDetents(value)
            innerDetents = value
            invalidateDetents()
        }

    internal var closestDetentToTopPx: Float by mutableFloatStateOf(Float.NaN)
    internal var contentHeightPx: Float by mutableFloatStateOf(Float.NaN)

    internal val anchoredDraggableState = UnstyledAnchoredDraggableState(
        initialValue = initialDetent,
        positionalThreshold = positionalThreshold,
        velocityThreshold = velocityThreshold,
        snapAnimationSpec = animationSpec,
        confirmValueChange = confirmDetentChange,
    )

    val currentDetent: SheetDetent
        get() {
            return anchoredDraggableState.settledValue
        }

    private val derivedTargetDetent: SheetDetent by derivedStateOf {
        // If we have a drag target, use that
        if (anchoredDraggableState.dragTarget != null) {
            return@derivedStateOf anchoredDraggableState.dragTarget as SheetDetent
        }
        // Otherwise determine target based on current offset and direction
        val currentOffset = anchoredDraggableState.offset
        if (currentOffset.isNaN()) return@derivedStateOf currentDetent

        val currentPosition = anchoredDraggableState.anchors.positionOf(currentDetent)
        val isMovingUp = currentOffset < currentPosition

        return@derivedStateOf anchoredDraggableState.anchors.closestAnchor(
            currentOffset, !isMovingUp
        ) ?: currentDetent
    }

    /**
     * The [SheetDetent] that the sheet is heading towards, in case of an animation or drag events.
     */
    var targetDetent: SheetDetent
        get() {
            return derivedTargetDetent
        }
        set(value) {
            check(innerDetents.contains(value)) {
                "Cannot set targetDetent to a detent (${value.identifier}) that is not part of the detents of the sheet's state. Current detents are: ${innerDetents.joinToString()}"
            }
            // do not start another animation if we are already heading to the requested detent
            // starting another animation, causes the sheet to pause for a split second, which is annoying for UX
            if (targetDetent == value) {
                return
            }
            coroutineScope.launch {
                anchoredDraggableState.animateTo(value)
            }
        }

    /**
     * Whether the sheet is currently rested at a detent.
     */
    val isIdle: Boolean by derivedStateOf {
        anchoredDraggableState.isDragging.not() && anchoredDraggableState.isAnimationRunning.not()
    }

    /**
     * A 0 to 1 value representing the progress of a sheet between its [currentDetent] and the [targetDetent].
     */
    @Deprecated(
        "This will go away in 2.0. Use the progress function and provide the detents you need instead."
    )
    val progress: Float
        get() = anchoredDraggableState.progress(currentDetent, targetDetent)

    /**
     * A 0 to 1 value representing the progress of a sheet between its [from] and the [to] detents.
     */
    fun progress(from: SheetDetent, to: SheetDetent): Float {
        return anchoredDraggableState.progress(from, to)
    }

    /**
     * The amount the sheet has traveled from the bottom of its container in pixels.
     *
     */
    val offset: Float by derivedStateOf {
        if (anchoredDraggableState.offset.isNaN() || closestDetentToTopPx.isNaN()) {
            0f
        } else {
            anchoredDraggableState.offset.coerceAtLeast(0f)
        }
    }

    /**
     * Animates the sheet to the given [SheetDetent]
     */
    suspend fun animateTo(value: SheetDetent) {
        check(innerDetents.contains(value)) {
            "Tried to set currentDetent to an unknown detent with identifier ${value.identifier}. Make sure that the detent is passed to the list of detents when instantiating the sheet's state."
        }
        anchoredDraggableState.animateTo(value)
    }

    /**
     * Instantly moves the sheet to the given [SheetDetent] without any animations.
     */
    fun jumpTo(value: SheetDetent) {
        check(innerDetents.contains(value)) {
            "Tried to set currentDetent to an unknown detent with identifier ${value.identifier}. Make sure that the detent is passed to the list of detents when instantiating the sheet's state."
        }
        coroutineScope.launch { anchoredDraggableState.snapTo(value) }
    }

    fun invalidateDetents() {
        val density = density()
        val sheetHeight = with(density) { contentHeightPx.toDp() }

        // We are about to update detents, and we need to figure out the new target for the sheet
        // If anchors haven't been initialized yet (offset is NaN), always use currentDetent to establish the starting position
        // Otherwise, if we're idle, use currentDetent to maintain position
        // If we're animating/dragging, use targetDetent
        val newTarget = if (anchoredDraggableState.offset.isNaN()) {
            currentDetent
        } else if (isIdle) {
            currentDetent
        } else {
            targetDetent
        }

        // Capture the direction we were moving BEFORE updating anchors
        // We determine this by comparing the target position to the current detent position
        val wasMovingUp = if (!isIdle && newTarget != currentDetent) {
            val targetPosition = anchoredDraggableState.anchors.positionOf(newTarget)
            val currentPosition = anchoredDraggableState.anchors.positionOf(currentDetent)
            targetPosition < currentPosition
        } else {
            false
        }

        val anchors = UnstyledDraggableAnchors {
            with(density) {
                closestDetentToTopPx = Float.NaN

                innerDetents.forEach { detent ->
                    val contentHeight = detent.calculateDetentHeight(sheetHeight)
                        .coerceIn(0.dp, sheetHeight)

                    val offset = (sheetHeight - contentHeight).toPx()
                    if (closestDetentToTopPx.isNaN() || closestDetentToTopPx > offset) {
                        closestDetentToTopPx = offset
                    }
                    detent at offset
                }
            }
        }

        val overridden = if (innerDetents.contains(newTarget)) {
            newTarget
        } else {
            // Find the closest detent in the direction of movement
            val currentOffset = anchoredDraggableState.offset
            val closestDetent = anchors.closestDetent(currentOffset, searchUpwards = wasMovingUp)

            (closestDetent ?: innerDetents.first()).also {
                // the anchored draggable state does not update its target value
                // so we have to force it in order to update
                targetDetent = it
            }
        }

        anchoredDraggableState.updateAnchors(anchors, newTarget = overridden)
    }
}

/**
 * Finds the closest detent to the given offset in the specified direction.
 *
 * For bottom sheets:
 * - Moving up means we want smaller offset values (closer to top of screen)
 * - Moving down means we want larger offset values (closer to bottom of screen)
 *
 * @param offset The current offset position
 * @param searchUpwards Whether to search upwards (true) or downwards (false)
 * @return The closest detent in the specified direction, or null if none found
 */
private fun UnstyledDraggableAnchors<SheetDetent>.closestDetent(
    offset: Float,
    searchUpwards: Boolean
): SheetDetent? {
    var closestDetent: SheetDetent? = null
    var closestDistance = Float.POSITIVE_INFINITY

    forEach { detent, position ->
        if (searchUpwards) {
            // Moving up: we want positions smaller than current offset
            if (position < offset) {
                val distance = offset - position
                if (distance < closestDistance) {
                    closestDetent = detent
                    closestDistance = distance
                }
            }
        } else {
            // Moving down: we want positions larger than current offset
            if (position > offset) {
                val distance = position - offset
                if (distance < closestDistance) {
                    closestDetent = detent
                    closestDistance = distance
                }
            }
        }
    }

    return closestDetent
}


class BottomSheetScope internal constructor(
    internal val state: BottomSheetState,
    enabled: Boolean
) {
    internal var enabled by mutableStateOf(enabled)
}

/**
 * A foundational component used to build bottom sheets.
 *
 * ## Basic Example
 *
 * ```kotlin
 * val sheetState = rememberBottomSheetState(
 *     initialDetent = Hidden,
 * )
 *
 * Button(onClick = { sheetState.currentDetent = FullyExpanded }) {
 *     Text("Show Sheet")
 * }
 *
 * BottomSheet(
 *     state = sheetState,
 *     modifier = Modifier.fillMaxWidth(),
 * ) {
 *     Box(
 *         modifier = Modifier.fillMaxWidth().height(1200.dp),
 *         contentAlignment = Alignment.TopCenter
 *     ) {
 *         DragIndication(Modifier.width(32.dp).height(4.dp))
 *     }
 * }
 * ```
 *
 * @param state The [BottomSheetState] that controls the sheet.
 * @param modifier Modifier to be applied to the sheet.
 * @param enabled Whether the sheet is enabled.
 * @param imeAware Automatically move the sheet according to the soft keyboard's height.
 * @param content The content of the sheet.
 */
@Composable
fun BottomSheet(
    state: BottomSheetState,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    imeAware: Boolean = false,
    content: @Composable (BottomSheetScope.() -> Unit)
) {
    val scope = remember { BottomSheetScope(state, enabled) }
    SideEffect { scope.enabled = enabled }
    val coroutineScope = rememberCoroutineScope()
    Box(
        modifier = buildModifier {
            add(
                Modifier
                    .onSizeChanged {
                        state.contentHeightPx = it.height.toFloat()
                        state.invalidateDetents()
                    }
                    .sheetOffset(state = state, imeAware = imeAware)
            )
            if (scope.enabled && state.detents.size > 1) {
                add(
                    Modifier
                        .unstyledAnchoredDraggable(
                            state = state.anchoredDraggableState,
                            orientation = Orientation.Vertical,
                            enabled = scope.enabled
                        )
                        .nestedScroll(
                            remember(state.anchoredDraggableState, Orientation.Vertical) {
                                consumeSwipeWithinBottomSheetBoundsNestedScrollConnection(
                                    orientation = Orientation.Vertical,
                                    sheetState = state.anchoredDraggableState,
                                    onFling = {
                                        coroutineScope.launch {
                                            state.anchoredDraggableState.settle(it)
                                        }
                                    }
                                )
                            }
                        )
                )
            }
            // add(modifier.pointerInput(Unit) {
            //     awaitPointerEventScope {
            //     }
            // })
        }
    ) {
        scope.content()
    }
}

@Composable
private fun Modifier.sheetOffset(state: BottomSheetState, imeAware: Boolean): Modifier {
    val density = LocalDensity.current
    val ime = WindowInsets.ime
    val imeHeight by remember {
        derivedStateOf {
            if (imeAware) ime.getBottom(density) else 0
        }
    }

    return this then buildModifier {
        add(Modifier.offset {
            when {
                state.contentHeightPx.isNaN() || state.closestDetentToTopPx.isNaN() -> {
                    // hasn't been initialized
                    IntOffset(x = 0, y = 0)
                }

                state.anchoredDraggableState.offset.isNaN() -> {
                    // draggable state is not ready
                    // let the sheet take the height of the container
                    val y = state.contentHeightPx.roundToInt()
                    IntOffset(x = 0, y = y)
                }

                else -> {
                    val calculatedOffset = state.anchoredDraggableState.requireOffset() - imeHeight
                    // do not let the sheet's top go out of screen bounds
                    val y = calculatedOffset.coerceAtLeast(0f).toInt()
                    IntOffset(x = 0, y = y)
                }
            }
        })
        if (imeAware) {
            add(Modifier.consumeWindowInsets(ime))
        }
    }
}

private fun consumeSwipeWithinBottomSheetBoundsNestedScrollConnection(
    sheetState: UnstyledAnchoredDraggableState<SheetDetent>,
    orientation: Orientation,
    onFling: (velocity: Float) -> Unit
): NestedScrollConnection = object : NestedScrollConnection {

    private var isPreFling = false

    override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
        val delta = available.toFloat()
        return if (delta < 0 && source == NestedScrollSource.UserInput) {
            sheetState.dispatchRawDelta(delta).toOffset()
        } else {
            Offset.Zero
        }
    }

    override fun onPostScroll(
        consumed: Offset,
        available: Offset,
        source: NestedScrollSource
    ): Offset {
        return if (source == NestedScrollSource.UserInput) {
            sheetState.dispatchRawDelta(available.toFloat()).toOffset()
        } else {
            Offset.Zero
        }
    }

    override suspend fun onPreFling(available: Velocity): Velocity {
        val toFling = available.toFloat()
        val currentOffset = sheetState.requireOffset()
        val minAnchor = sheetState.anchors.minAnchor()
        return if (toFling < 0 && currentOffset > minAnchor) {
            isPreFling = true
            onFling(toFling)
            // since we go to the anchor with tween settling, consume all for the best UX
            available
        } else {
            Velocity.Zero
        }
    }

    override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
        if (!isPreFling || available.toFloat() > 0) {
            onFling(available.toFloat())
        }
        isPreFling = false
        return available
    }

    private fun Float.toOffset(): Offset = Offset(
        x = if (orientation == Orientation.Horizontal) this else 0f,
        y = if (orientation == Orientation.Vertical) this else 0f
    )

    @JvmName("velocityToFloat")
    private fun Velocity.toFloat() = if (orientation == Orientation.Horizontal) x else y

    @JvmName("offsetToFloat")
    private fun Offset.toFloat(): Float = if (orientation == Orientation.Horizontal) x else y
}