package com.candy.compose

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import com.candy.kit.WorkFlow

@Composable
fun rememberWorkFlow(): WorkFlow {
    val scope = rememberCoroutineScope()
    val workFlow = remember { WorkFlow(scope) }

    DisposableEffect(Unit) {
        onDispose { workFlow.stop() }
    }
    return workFlow
}
