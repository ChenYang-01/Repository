/**
 * Automatically generated file. DO NOT MODIFY
 */
package candy.zoomable;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "candy.zoomable";
  public static final String BUILD_TYPE = "release";
}
