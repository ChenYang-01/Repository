package candy.zoomable.subsamplingimage

import android.os.Build.VERSION.SDK_INT
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.util.fastAll
import androidx.compose.ui.util.fastAny
import candy.zoomable.subsamplingimage.internal.ImageCache
import candy.zoomable.subsamplingimage.internal.ImageRegionDecoder
import candy.zoomable.subsamplingimage.internal.ImageRegionTile
import candy.zoomable.subsamplingimage.internal.ImageRegionTileGrid
import candy.zoomable.subsamplingimage.internal.ImageSampleSize
import candy.zoomable.subsamplingimage.internal.ViewportImageTile
import candy.zoomable.subsamplingimage.internal.ViewportTile
import candy.zoomable.subsamplingimage.internal.calculateFor
import candy.zoomable.subsamplingimage.internal.contains
import candy.zoomable.subsamplingimage.internal.fastMapNotNull
import candy.zoomable.subsamplingimage.internal.generate
import candy.zoomable.subsamplingimage.internal.isNotEmpty
import candy.zoomable.subsamplingimage.internal.maxScale
import candy.zoomable.subsamplingimage.internal.overlaps
import candy.zoomable.subsamplingimage.internal.scaledAndOffsetBy
import candy.zoomable.zoomable.ZoomableContentTransformation
import kotlinx.collections.immutable.ImmutableList
import kotlinx.collections.immutable.ImmutableMap
import kotlinx.collections.immutable.persistentListOf
import kotlinx.collections.immutable.persistentMapOf
import kotlinx.collections.immutable.toImmutableList
import candy.zoomable.subsamplingimage.internal.ImageRegionDecoder.DecodeResult as ImageDecodeResult

/** State for [SubSamplingImage]. Created using [rememberSubSamplingImageState]. */
@Stable
internal class RealSubSamplingImageState(
    private val imageSource: SubSamplingImageSource,
    private val contentTransformation: () -> ZoomableContentTransformation,
) : SubSamplingImageState {

    override val imageSize: IntSize?
        get() = imageRegionDecoder?.imageSize

    // todo: it isn't great that the preview image remains in memory even after the full image is loaded.
    private val imagePreview: Painter? =
        imageSource.preview?.let(::BitmapPainter)

    internal val imageOrPreviewSize: IntSize?
        get() = imageSize ?: imageSource.preview?.size()

    override val isImageDisplayed: Boolean by derivedStateOf {
        isReadyToBeDisplayed && viewportImageTiles.isNotEmpty() &&
        (viewportImageTiles.fastAny { it.isBase } || viewportImageTiles.fastAll { it.painter != null })
    }

    override val isImageDisplayedInFullQuality: Boolean by derivedStateOf {
        isImageDisplayed && viewportImageTiles.fastAll { it.painter != null }
    }

    internal var imageRegionDecoder: ImageRegionDecoder? by mutableStateOf(null)
    internal var viewportSize: IntSize? by mutableStateOf(null)
    internal var showTileBounds = false  // Only used by tests.

    /**
     * Controls whether the image is divided into equally sized tiles.
     *
     * When enabled, all tiles are generated with uniform dimensions. This creates a
     * predictable tile layout, ideal for dynamic content such as PDFs, in exchange
     * for a potentially higher number of tiles.
     *
     * When disabled, the tile sizes may vary, particularly along the image edges, in
     * order to reduce the total number of tiles. This is preferred for raster image
     * formats like JPEG and PNG, where decoding bitmaps for fewer, larger tiles is
     * typically more performant than loading many smaller ones.
     *
     * This is currently internal as there hasn't yet been a clear external use case.
     * If you'd like to control this behavior, please file an issue!
     */
    internal var preferConsistentTileSize by mutableStateOf(true)

    /**
     * Images collected from [ImageCache].
     *
     * Loaded images are kept in a separate state instead of being combined with viewport tiles
     * because images are collected asynchronously, whereas viewport tiles are updated synchronously
     * during the layout pass.
     *
     * This separation enables layout changes to be rendered immediately. In previous
     * versions, layout changes caused image flickering because tile updates were asynchronous
     * and lagged by one frame.
     */
    private var loadedImages: ImmutableMap<ImageRegionTile, ImageDecodeResult> by mutableStateOf(
        persistentMapOf()
    )

    /**
     * Whether the image contains [ultra HDR content](https://developer.android.com/media/grow/ultra-hdr/display).
     */
    val hasUltraHdrContent: Boolean by derivedStateOf {
        loadedImages.any { (_, result) -> result.hasUltraHdrContent } || imageSource.preview?.hasUltraHdrContent() == true
    }

    private val isReadyToBeDisplayed: Boolean by derivedStateOf {
        viewportSize?.isNotEmpty() == true && imageOrPreviewSize?.isNotEmpty() == true
    }

    // Note to self: This is not inlined in viewportTiles to
    // avoid creating a new grid on every transformation change.
    private val tileGrid by derivedStateOf {
        if (isReadyToBeDisplayed) {
            ImageRegionTileGrid.generate(
                viewportSize = viewportSize!!,
                unscaledImageSize = imageOrPreviewSize!!,
                preferConsistentTileSize = preferConsistentTileSize,
            )
        } else null
    }

    private val viewportTiles: ImmutableList<ViewportTile> by derivedStateOf {
        val tileGrid = tileGrid ?: return@derivedStateOf persistentListOf()
        val transformation = contentTransformation()
        val baseSampleSize = tileGrid.base.sampleSize

        val currentSampleSize = ImageSampleSize
            .calculateFor(zoom = transformation.scale.maxScale)
            .coerceAtMost(baseSampleSize)

        val isBaseSampleSize = currentSampleSize == baseSampleSize
        val foregroundRegions = if (isBaseSampleSize) emptyList() else tileGrid.foreground[currentSampleSize]!!

        (listOf(tileGrid.base) + foregroundRegions)
            .sortedByDescending { it.bounds.contains(transformation.centroid) }
            .fastMapNotNull { region ->
                val isBaseTile = region == tileGrid.base
                val drawBounds = region.bounds.scaledAndOffsetBy(
                    transformation.scale, transformation.offset
                )
                ViewportTile(
                    region = region,
                    bounds = drawBounds,
                    isBase = isBaseTile,
                    isVisible = drawBounds.overlaps(tileGrid.viewportSize),
                )
            }
            .toImmutableList()
    }

    internal val viewportImageTiles: ImmutableList<ViewportImageTile> by derivedStateOf {
        // Fill any missing gaps in tiles by drawing the low-res base tile underneath as
        // a fallback. The base tile will hide again when all bitmaps have been loaded.
        //
        // A drawback of doing this is that the base tile may get optimized out before the
        // foreground tiles complete their fade-in animation (run by ZoomableImage()).
        // This can only be solved by encoding their animation info in the tiles.
        val hasNoForeground = viewportTiles.fastAll { it.isBase }
        val hasGapsInForeground = { viewportTiles.fastAny { !it.isBase && it.isVisible && it.region !in loadedImages } }
        val canDrawBaseTile = hasNoForeground || hasGapsInForeground()

        viewportTiles.fastMapNotNull { tile ->
            if (tile.isVisible && (!tile.isBase || canDrawBaseTile)) {
                ViewportImageTile(
                    tile = tile,
                    painter = loadedImages[tile.region]?.painter
                              ?: if (tile.isBase) imagePreview else null,
                )
            } else null
        }.toImmutableList()
    }

    @Composable
    fun LoadImageTilesEffect() {
        val imageRegionDecoder = imageRegionDecoder ?: return
        val scope = rememberCoroutineScope()
        val imageCache = remember(this, imageRegionDecoder) {
            ImageCache(scope, imageRegionDecoder)
        }

        LaunchedEffect(imageCache) {
            snapshotFlow { viewportTiles }.collect { tiles ->
                imageCache.loadOrUnloadForTiles(
                    regions = tiles.fastMapNotNull { if (it.isVisible) it.region else null }
                )
            }
        }
        LaunchedEffect(imageCache) {
            imageCache.observeCachedImages().collect {
                loadedImages = it
            }
        }
    }
}

private fun ImageBitmap.hasUltraHdrContent(): Boolean {
    return if (SDK_INT >= 34) asAndroidBitmap().hasGainmap() else false
}

private fun ImageBitmap.size(): IntSize = IntSize(width, height)
