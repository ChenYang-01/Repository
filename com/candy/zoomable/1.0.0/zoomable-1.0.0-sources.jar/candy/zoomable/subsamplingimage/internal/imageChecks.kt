package candy.zoomable.subsamplingimage.internal

import android.content.Context
import candy.zoomable.subsamplingimage.SubSamplingImageSource
import candy.zoomable.subsamplingimage.util.canBeSubSampled as canBeSubSampledV2
import candy.zoomable.subsamplingimage.util.exists as existsV2

/**
 * Check whether an image source can be sub-sampled and decoded using [AndroidImageRegionDecoder].
 */
@Deprecated(
    message = "Moved to another package",
    replaceWith = ReplaceWith(
        "canBeSubSampled(context)", "candy.zoomable.subsamplingimage.util.canBeSubSampled"
    )
)
suspend fun SubSamplingImageSource.canBeSubSampled(context: Context): Boolean {
    return canBeSubSampledV2(context)
}

/** Check whether an image source exists and has non-zero bytes. */
@Deprecated(
    message = "Moved to another package",
    replaceWith = ReplaceWith("exists(context)", "candy.zoomable.subsamplingimage.util.exists")
)
suspend fun SubSamplingImageSource.exists(context: Context): Boolean {
    return existsV2(context)
}
