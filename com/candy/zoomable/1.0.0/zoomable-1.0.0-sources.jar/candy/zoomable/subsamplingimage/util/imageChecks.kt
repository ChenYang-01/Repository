package candy.zoomable.subsamplingimage.util

import android.content.Context
import android.util.TypedValue
import candy.zoomable.subsamplingimage.BufferedSubSamplingImageSource
import candy.zoomable.subsamplingimage.ResourceImageSource
import candy.zoomable.subsamplingimage.SubSamplingImageSource
import candy.zoomable.subsamplingimage.internal.AndroidImageRegionDecoder
import candy.zoomable.subsamplingimage.internal.isAvif
import candy.zoomable.subsamplingimage.internal.isGif
import candy.zoomable.subsamplingimage.internal.isSvg
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okio.Buffer

/**
 * Check whether an image source can be sub-sampled and decoded using [AndroidImageRegionDecoder].
 */
suspend fun SubSamplingImageSource.canBeSubSampled(context: Context): Boolean {
    if (this is ResourceImageSource) {
        return !isVectorDrawable(context)
    }
    if (this !is BufferedSubSamplingImageSource) {
        return true
    }

    return withContext(Dispatchers.IO) {
        try {
            peek(context).use {
                // Check for GIFs as well because Android's ImageDecoder
                // can return a Bitmap for single-frame GIFs.
                !isSvg(it) && !isGif(it) && !isAvif(it)
            }
        } catch (_: okio.FileNotFoundException) {
            // The file may have been deleted by the cache before it could be read.
            false
        }
    }
}

/** Check whether an image source exists and has non-zero bytes. */
suspend fun SubSamplingImageSource.exists(context: Context): Boolean {
    if (this !is BufferedSubSamplingImageSource) {
        return true
    }
    return withContext(Dispatchers.IO) {
        try {
            peek(context).read(Buffer(), byteCount = 1) != -1L
        } catch (_: okio.FileNotFoundException) {
            // This catch block currently makes an assumption that files are only read
            // using okio, which is true for SubSamplingImageSource.file(), but might
            // fail for SubSamplingImageSource.rawSource(). I could probably make exists()
            // a member function of SubSamplingImageSource to fix that.
            false
        }
    }
}

private suspend fun ResourceImageSource.isVectorDrawable(context: Context): Boolean {
    return withContext(Dispatchers.IO) {
        TypedValue().apply {
            context.resources.getValue(id, this, /* resolveRefs = */ true)
        }.string.endsWith(".xml")
    }
}
