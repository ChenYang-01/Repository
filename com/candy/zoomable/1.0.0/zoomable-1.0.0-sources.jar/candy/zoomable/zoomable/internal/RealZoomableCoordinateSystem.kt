package candy.zoomable.zoomable.internal

import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.geometry.takeOrElse
import androidx.compose.ui.layout.ScaleFactor
import candy.zoomable.zoomable.RealZoomableState
import candy.zoomable.zoomable.Viewport
import candy.zoomable.zoomable.ZoomableContent
import candy.zoomable.zoomable.ZoomableContentTransformation
import candy.zoomable.zoomable.ZoomableCoordinateSystem
import candy.zoomable.zoomable.spatial.CoordinateSpace
import candy.zoomable.zoomable.spatial.SpatialOffset
import candy.zoomable.zoomable.spatial.SpatialRect
import candy.zoomable.zoomable.spatial.isUnspecified

@Stable
internal class RealZoomableCoordinateSystem(
    private val state: RealZoomableState,
) : ZoomableCoordinateSystem {

    override val contentBounds: SpatialRect by derivedStateOf {
        contentBounds(clipToViewport = true)
    }

    override fun contentBounds(clipToViewport: Boolean): SpatialRect {
        val boundsInViewport = state.transformUnscaledContentBoundsBy(
            clipToViewport
        ) { _, transformation ->
            zoomedAndTranslatedBy(
                scale = transformation.scale,
                offset = transformation.offset,
            )
        }
        return if (boundsInViewport != null) {
            SpatialRect(boundsInViewport, CoordinateSpace.Viewport)
        } else {
            SpatialRect.Unspecified
        }
    }

    override val unscaledContentBounds: SpatialRect by derivedStateOf {
        unscaledContentBounds(clipToViewport = true)
    }

    override fun unscaledContentBounds(clipToViewport: Boolean): SpatialRect {
        val boundsInViewport = state.transformUnscaledContentBoundsBy(clipToViewport) { inputs, _ ->
            zoomedAndTranslatedBy(
                scale = inputs.baseZoom.value,
                offset = -(inputs.baseOffset * inputs.baseZoom.value),
            )
        }
        return if (boundsInViewport != null) {
            SpatialRect(boundsInViewport, CoordinateSpace.Viewport)
        } else {
            SpatialRect.Unspecified
        }
    }

    override val viewportSize: Size
        get() = state.viewportSize.takeOrElse { Size.Zero }

    override fun SpatialOffset.offsetIn(target: CoordinateSpace): Offset {
        if (this.isUnspecified) {
            return Offset.Unspecified
        }
        val converter = converterIfStateIsReady()
                        ?: converterWithPlaceholderBounds()
                        ?: return Offset.Unspecified
        return converter.convert(this, target)
    }

    override fun SpatialRect.rectIn(target: CoordinateSpace): Rect {
        if (this.isUnspecified) {
            return Rect.Zero
        }

        val topLeftInTarget = this.topLeft.offsetIn(target)
        val bottomRightInTarget = this.bottomRight.offsetIn(target)

        return if (topLeftInTarget.isSpecified && bottomRightInTarget.isSpecified) {
            Rect(topLeftInTarget, bottomRightInTarget)
        } else {
            Rect.Zero
        }
    }

    private fun converterIfStateIsReady(): CoordinateSpaceConverter? {
        val stateInputs = state.currentGestureStateInputs ?: return null
        val transformation = state.contentTransformation.takeIf { it.isSpecified } ?: return null
        return CoordinateSpaceConverter(
            unscaledContentBounds = stateInputs.unscaledContentBounds,
            transformation = transformation,
        )
    }

    private fun converterWithPlaceholderBounds(): CoordinateSpaceConverter? {
        // Note to self: the placeholder bounds are always unscaled
        // because placeholders can't be zoomed (at least not yet).
        return state.placeholderBoundsProvider?.calculate()?.let { placeholderBounds ->
            CoordinateSpaceConverter(
                unscaledContentBounds = placeholderBounds,
                transformation = RealZoomableContentTransformation.Unspecified,
            )
        }
    }

    internal data class CoordinateSpaceConverter(
        private val unscaledContentBounds: Rect,
        private val transformation: ZoomableContentTransformation,
    ) {
        private val scale: ScaleFactor
            get() = transformation.scale

        /**
         * The content's bounds after applying the current transformation (scale and offset).
         * This represents where the content is actually drawn in the viewport.
         *
         * For example, if the content is zoomed to 2x and panned 100px right:
         * - The size will be 2x the original content size.
         * - The topLeft will be offset by 100px from the original position.
         */
        private val transformedContentBounds: Rect
            get() = unscaledContentBounds.zoomedAndTranslatedBy(scale, transformation.offset)

        fun convert(offset: SpatialOffset, target: CoordinateSpace): Offset {
            val source = offset.space
            return when {
                source == target -> {
                    when (target) {
                        CoordinateSpace.Viewport -> offset.offset
                        CoordinateSpace.ZoomableContent -> offset.offset
                        else -> error("unknown coordinate space = $target")
                    }
                }
                source == CoordinateSpace.Viewport && target == CoordinateSpace.ZoomableContent -> {
                    viewportToContent(offset.offset)
                }
                source == CoordinateSpace.ZoomableContent && target == CoordinateSpace.Viewport -> {
                    contentToViewport(offset.offset)
                }
                else -> {
                    error("Can't convert from ${offset.space} to $target")
                }
            }
        }

        private fun viewportToContent(offset: Offset): Offset {
            // To convert from viewport to content coordinates:
            // 1. Shift by -transformedContentBounds.topLeft (to get relative to transformed content)
            // 2. Divide by scale (to get back to unscaled coordinates)
            // 3. Shift by +unscaledContentBounds.topLeft (to get absolute coordinates)
            return (
                    (offset - transformedContentBounds.topLeft) / scale + unscaledContentBounds.topLeft
                   )
        }

        private fun contentToViewport(offset: Offset): Offset {
            // To convert from content to viewport coordinates:
            // 1. Shift by -unscaledContentBounds.topLeft (to get relative to content)
            // 2. Scale by scale factor (to get scaled coordinates)
            // 3. Shift by +transformedContentBounds.topLeft (to get absolute coordinates)
            return (
                    (offset - unscaledContentBounds.topLeft) * scale + transformedContentBounds.topLeft
                   )
        }
    }
}

internal data object ContentCoordinateSpace : CoordinateSpace

internal data object ViewportCoordinateSpace : CoordinateSpace
