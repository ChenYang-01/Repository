package candy.zoomable.zoomable.internal

import androidx.compose.runtime.Stable
import androidx.compose.ui.geometry.Rect
import candy.zoomable.zoomable.Viewport
import candy.zoomable.zoomable.ZoomableState
import candy.zoomable.zoomable.spatial.CoordinateSpace
import candy.zoomable.zoomable.spatial.isSpecified

/**
 * Used by [candy.zoomable.zoomable.ZoomableImage] to provide a fallback value for
 * [ZoomableState.transformedContentBounds] before the full quality image is loaded. This
 * ensures that the bounds aren't empty while a placeholder image is visible.
 */
@JvmInline

internal value class PlaceholderBoundsProvider(
    private val placeholderState: ZoomableState,
) {
    @Stable
    fun calculate(): Rect? {
        return with(placeholderState.coordinateSystem) {
            val bounds = unscaledContentBounds.takeIf { it.isSpecified } ?: return null
            bounds.rectIn(CoordinateSpace.Viewport)
        }
    }
}
