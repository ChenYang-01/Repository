package candy.zoomable.zoomable

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.ui.geometry.Offset
import candy.zoomable.zoomable.internal.maxScale
import candy.zoomable.zoomable.spatial.CoordinateSpace
import candy.zoomable.zoomable.spatial.SpatialOffset

/**
 * Implement this interface for reacting to double clicks on `Modifier.zoomable`'s content.
 * By default, [DoubleClickToZoomListener.cycle] is used.
 */
@Immutable
fun interface DoubleClickToZoomListener {
    companion object {
        /**
         * Cycles between [maxZoomFactor] and the minimum zoom factor on double clicks.
         * When [maxZoomFactor] is null, [ZoomSpec.maximum] is used.
         */
        @Stable
        fun cycle(
            maxZoomFactor: Float? = null
        ): DoubleClickToZoomListener = CycleZoomOnDoubleClick(maxZoomFactor)
    }

    suspend fun onDoubleClick(
        state: ZoomableState,
        centroid: Offset,
    )


    suspend fun ZoomableCoordinateSystem.onDoubleClick(
        state: ZoomableState,
        centroid: SpatialOffset,
    ) {
        onDoubleClick(
            state = state,
            centroid = with(state.coordinateSystem) {
                centroid.offsetIn(CoordinateSpace.Viewport)
            }
        )
    }

    /**
     * Toggles between [ZoomSpec.maximum] and the [ZoomSpec.minimum] on double clicks.
     */
    @Deprecated(
        message = "Use DoubleClickToZoomListener.cycle() instead",
        replaceWith = ReplaceWith("DoubleClickToZoomListener.cycle()"),
    )
    data object ToggleBetweenMinAndMax : DoubleClickToZoomListener {
        override suspend fun onDoubleClick(state: ZoomableState, centroid: Offset) {
            cycle().onDoubleClick(state, centroid)
        }
    }
}

/**
 * See [DoubleClickToZoomListener.cycle].
 */

private data class CycleZoomOnDoubleClick(
    private val maxZoomFactor: Float? = null
) : DoubleClickToZoomListener {

    override suspend fun ZoomableCoordinateSystem.onDoubleClick(
        state: ZoomableState,
        centroid: SpatialOffset
    ) {
        val transformation = state.contentTransformation.takeIf { it.isSpecified }
        val zoomFraction = state.zoomFraction

        if (transformation == null || zoomFraction == null) {
            // Content isn't ready yet. Technically, this should never happen because Modifier.zoomable()
            // doesn't register a double click listener until after it has measured the content.
            return
        }

        val isAtMaxZoom = if (maxZoomFactor == null) {
            zoomFraction >= 0.95f
        } else {
            maxZoomFactor - transformation.scale.maxScale < 0.05f
        }

        if (isAtMaxZoom) {
            state.resetZoom()
        } else {
            state.zoomTo(
                zoomFactor = maxZoomFactor ?: state.zoomSpec.maximum.factor,
                focal = ZoomFocalPoint.zoomAround(centroid),
            )
        }
    }

    override suspend fun onDoubleClick(state: ZoomableState, centroid: Offset) {
        with(state.coordinateSystem) {
            onDoubleClick(state, SpatialOffset(centroid, CoordinateSpace.Viewport))
        }
    }
}
