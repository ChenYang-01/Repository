package candy.zoomable.zoomable.internal

import android.os.Parcelable

@Target(AnnotationTarget.CLASS)
@Retention(AnnotationRetention.BINARY)
internal annotation class AndroidParcelize

internal typealias AndroidParcelable = Parcelable
