@file:Suppress("NAME_SHADOWING")

package candy.zoomable.zoomable.coil3

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.Composable
import androidx.compose.runtime.NonRestartableComposable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.DefaultAlpha
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import candy.zoomable.zoomable.DoubleClickToZoomListener
import candy.zoomable.zoomable.EnabledZoomGestures
import candy.zoomable.zoomable.ZoomableImage
import candy.zoomable.zoomable.ZoomableImageSource
import candy.zoomable.zoomable.ZoomableImageState
import candy.zoomable.zoomable.rememberZoomableImageState
import candy.zoomable.zoomable.rememberZoomableState
import coil3.ImageLoader
import coil3.annotation.ExperimentalCoilApi
import coil3.compose.LocalAsyncImageModelEqualityDelegate
import coil3.imageLoader
import kotlinx.coroutines.flow.distinctUntilChanged

/**
 * A zoomable image that can be loaded by Coil 3.
 *
 * Example usages:
 *
 * ```kotlin
 * ZoomableAsyncImage(
 *   model = "https://example.com/image.jpg",
 *   contentDescription = …
 * )
 *
 * ZoomableAsyncImage(
 *   model = ImageRequest.Builder(LocalContext.current)
 *     .data("https://example.com/image.jpg")
 *     .build(),
 *   contentDescription = …
 * )
 * ```
 *
 * See [ZoomableImage()][ZoomableImage] for full documentation of parameters.
 */
@Composable
@NonRestartableComposable
fun ZoomableAsyncImage(
    model: Any?,
    contentDescription: String?,
    gestures: EnabledZoomGestures,
    modifier: Modifier = Modifier,
    state: ZoomableImageState = rememberZoomableImageState(rememberZoomableState()),
    imageLoader: ImageLoader = LocalContext.current.imageLoader,
    alpha: Float = DefaultAlpha,
    colorFilter: ColorFilter? = null,
    alignment: Alignment = Alignment.Center,
    contentScale: ContentScale = ContentScale.Fit,
    onClick: ((Offset) -> Unit)? = null,
    onLongClick: ((Offset) -> Unit)? = null,
    onDoubleClick: DoubleClickToZoomListener = DoubleClickToZoomListener.cycle(),
    clipToBounds: Boolean = true,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    interactionSource: MutableInteractionSource? = null,
) {
    ZoomableImage(
        image = ZoomableImageSource.coil(model, imageLoader),
        contentDescription = contentDescription,
        modifier = modifier,
        state = state,
        alpha = alpha,
        colorFilter = colorFilter,
        alignment = alignment,
        contentScale = contentScale,
        gestures = gestures,
        onClick = onClick,
        onLongClick = onLongClick,
        onDoubleClick = onDoubleClick,
        clipToBounds = clipToBounds,
        contentPadding = contentPadding,
        interactionSource = interactionSource,
    )
}

@Composable
@NonRestartableComposable
fun ZoomableAsyncImage(
    model: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    state: ZoomableImageState = rememberZoomableImageState(rememberZoomableState()),
    imageLoader: ImageLoader = LocalContext.current.imageLoader,
    alpha: Float = DefaultAlpha,
    colorFilter: ColorFilter? = null,
    alignment: Alignment = Alignment.Center,
    contentScale: ContentScale = ContentScale.Fit,
    onClick: ((Offset) -> Unit)? = null,
    onLongClick: ((Offset) -> Unit)? = null,
    clipToBounds: Boolean = true,
    onDoubleClick: DoubleClickToZoomListener = DoubleClickToZoomListener.cycle(),
    contentPadding: PaddingValues = PaddingValues(0.dp),
    interactionSource: MutableInteractionSource? = null,
) {
    ZoomableAsyncImage(
        model = model,
        contentDescription = contentDescription,
        modifier = modifier,
        state = state,
        imageLoader = imageLoader,
        alpha = alpha,
        colorFilter = colorFilter,
        alignment = alignment,
        contentScale = contentScale,
        gestures = EnabledZoomGestures.ZoomAndPan,
        onClick = onClick,
        onLongClick = onLongClick,
        onDoubleClick = onDoubleClick,
        clipToBounds = clipToBounds,
        contentPadding = contentPadding,
        interactionSource = interactionSource,
    )
}

@Deprecated(
    "Use the 'gestures' parameter instead. " +
    "Replace `gesturesEnabled = true` with `gestures = ZoomInteractions.ZoomAndPan`, " +
    "or `gesturesEnabled = false` with `gestures = ZoomInteractions.None`.",
)
@Composable
@NonRestartableComposable
fun ZoomableAsyncImage(
    model: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    state: ZoomableImageState = rememberZoomableImageState(rememberZoomableState()),
    imageLoader: ImageLoader = LocalContext.current.imageLoader,
    alpha: Float = DefaultAlpha,
    colorFilter: ColorFilter? = null,
    alignment: Alignment = Alignment.Center,
    contentScale: ContentScale = ContentScale.Fit,
    gesturesEnabled: Boolean = true,
    onClick: ((Offset) -> Unit)? = null,
    onLongClick: ((Offset) -> Unit)? = null,
    clipToBounds: Boolean = true,
    onDoubleClick: DoubleClickToZoomListener = DoubleClickToZoomListener.cycle(),
    contentPadding: PaddingValues = PaddingValues(0.dp),
    interactionSource: MutableInteractionSource? = null,
) {
    ZoomableAsyncImage(
        model = model,
        contentDescription = contentDescription,
        modifier = modifier,
        state = state,
        imageLoader = imageLoader,
        alpha = alpha,
        colorFilter = colorFilter,
        alignment = alignment,
        contentScale = contentScale,
        gestures = if (gesturesEnabled) EnabledZoomGestures.ZoomAndPan else EnabledZoomGestures.None,
        onClick = onClick,
        onLongClick = onLongClick,
        onDoubleClick = onDoubleClick,
        clipToBounds = clipToBounds,
        contentPadding = contentPadding,
        interactionSource = interactionSource,
    )
}

/**
 * A zoomable image that can be loaded by Coil and displayed using
 * [ZoomableImage()][ZoomableImageSource].
 *
 * Example usage:
 *
 * ```kotlin
 * ZoomableImage(
 *   image = ZoomableImageSource.coil("https://example.com/image.jpg"),
 *   contentDescription = …
 * )
 *
 * ZoomableImage(
 *   image = ZoomableImageSource.coil(
 *     ImageRequest.Builder(LocalContext.current)
 *       .data("https://example.com/image.jpg")
 *       .build()
 *   ),
 *   contentDescription = …
 * )
 * ```
 */
@Composable
@OptIn(ExperimentalCoilApi::class)
fun ZoomableImageSource.Companion.coil(
    model: Any?,
    imageLoader: ImageLoader = LocalContext.current.imageLoader
): ZoomableImageSource {
    val model by rememberUpdatedState(model)
    val imageLoader by rememberUpdatedState(imageLoader)
    val equalityDelegate = LocalAsyncImageModelEqualityDelegate.current
    return remember {
        Coil3ImageSource(
            models = snapshotFlow { model }.distinctUntilChanged(equalityDelegate::equals),
            imageLoaders = snapshotFlow { imageLoader },
        )
    }
}

@Composable
@Suppress("unused")
@NonRestartableComposable
@Deprecated("Kept for binary compatibility", level = DeprecationLevel.HIDDEN)
fun ZoomableAsyncImage(
    model: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    state: ZoomableImageState = rememberZoomableImageState(rememberZoomableState()),
    imageLoader: ImageLoader = LocalContext.current.imageLoader,
    alpha: Float = DefaultAlpha,
    colorFilter: ColorFilter? = null,
    alignment: Alignment = Alignment.Center,
    contentScale: ContentScale = ContentScale.Fit,
    gesturesEnabled: Boolean = true,
    onClick: ((Offset) -> Unit)? = null,
    onLongClick: ((Offset) -> Unit)? = null,
    clipToBounds: Boolean = true,
    onDoubleClick: DoubleClickToZoomListener = DoubleClickToZoomListener.cycle(),
) {
    ZoomableAsyncImage(
        model = model,
        contentDescription = contentDescription,
        modifier = modifier,
        state = state,
        imageLoader = imageLoader,
        alpha = alpha,
        colorFilter = colorFilter,
        alignment = alignment,
        contentScale = contentScale,
        gestures = if (gesturesEnabled) EnabledZoomGestures.ZoomAndPan else EnabledZoomGestures.None,
        onClick = onClick,
        onLongClick = onLongClick,
        onDoubleClick = onDoubleClick,
        clipToBounds = clipToBounds,
        contentPadding = PaddingValues(0.dp),
    )
}

@Composable
@NonRestartableComposable
@Deprecated("Kept for binary compatibility", level = DeprecationLevel.HIDDEN)
fun ZoomableAsyncImage(
    model: Any?,
    contentDescription: String?,
    gestures: EnabledZoomGestures,
    modifier: Modifier = Modifier,
    state: ZoomableImageState = rememberZoomableImageState(rememberZoomableState()),
    imageLoader: ImageLoader = LocalContext.current.imageLoader,
    alpha: Float = DefaultAlpha,
    colorFilter: ColorFilter? = null,
    alignment: Alignment = Alignment.Center,
    contentScale: ContentScale = ContentScale.Fit,
    onClick: ((Offset) -> Unit)? = null,
    onLongClick: ((Offset) -> Unit)? = null,
    onDoubleClick: DoubleClickToZoomListener = DoubleClickToZoomListener.cycle(),
    clipToBounds: Boolean = true,
    contentPadding: PaddingValues = PaddingValues(0.dp),
) {
    ZoomableAsyncImage(
        model = model,
        contentDescription = contentDescription,
        gestures = gestures,
        modifier = modifier,
        state = state,
        imageLoader = imageLoader,
        alpha = alpha,
        colorFilter = colorFilter,
        alignment = alignment,
        contentScale = contentScale,
        onClick = onClick,
        onLongClick = onLongClick,
        onDoubleClick = onDoubleClick,
        clipToBounds = clipToBounds,
        contentPadding = contentPadding,
        interactionSource = null,
    )
}

@Composable
@NonRestartableComposable
@Deprecated("Kept for binary compatibility", level = DeprecationLevel.HIDDEN)
fun ZoomableAsyncImage(
    model: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    state: ZoomableImageState = rememberZoomableImageState(rememberZoomableState()),
    imageLoader: ImageLoader = LocalContext.current.imageLoader,
    alpha: Float = DefaultAlpha,
    colorFilter: ColorFilter? = null,
    alignment: Alignment = Alignment.Center,
    contentScale: ContentScale = ContentScale.Fit,
    onClick: ((Offset) -> Unit)? = null,
    onLongClick: ((Offset) -> Unit)? = null,
    clipToBounds: Boolean = true,
    onDoubleClick: DoubleClickToZoomListener = DoubleClickToZoomListener.cycle(),
    contentPadding: PaddingValues = PaddingValues(0.dp),
) {
    ZoomableAsyncImage(
        model = model,
        contentDescription = contentDescription,
        modifier = modifier,
        state = state,
        imageLoader = imageLoader,
        alpha = alpha,
        colorFilter = colorFilter,
        alignment = alignment,
        contentScale = contentScale,
        onClick = onClick,
        onLongClick = onLongClick,
        onDoubleClick = onDoubleClick,
        clipToBounds = clipToBounds,
        contentPadding = contentPadding,
        interactionSource = null,
    )
}

@Composable
@NonRestartableComposable
@Deprecated("Kept for binary compatibility", level = DeprecationLevel.HIDDEN)
fun ZoomableAsyncImage(
    model: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    state: ZoomableImageState = rememberZoomableImageState(rememberZoomableState()),
    imageLoader: ImageLoader = LocalContext.current.imageLoader,
    alpha: Float = DefaultAlpha,
    colorFilter: ColorFilter? = null,
    alignment: Alignment = Alignment.Center,
    contentScale: ContentScale = ContentScale.Fit,
    gesturesEnabled: Boolean = true,
    onClick: ((Offset) -> Unit)? = null,
    onLongClick: ((Offset) -> Unit)? = null,
    clipToBounds: Boolean = true,
    onDoubleClick: DoubleClickToZoomListener = DoubleClickToZoomListener.cycle(),
    contentPadding: PaddingValues = PaddingValues(0.dp),
) {
    ZoomableAsyncImage(
        model = model,
        contentDescription = contentDescription,
        gestures = if (gesturesEnabled) EnabledZoomGestures.ZoomAndPan else EnabledZoomGestures.None,
        modifier = modifier,
        state = state,
        imageLoader = imageLoader,
        alpha = alpha,
        colorFilter = colorFilter,
        alignment = alignment,
        contentScale = contentScale,
        onClick = onClick,
        onLongClick = onLongClick,
        onDoubleClick = onDoubleClick,
        clipToBounds = clipToBounds,
        contentPadding = contentPadding,
        interactionSource = null,
    )
}

@Composable
@NonRestartableComposable
@Deprecated("Kept for binary compatibility", level = DeprecationLevel.HIDDEN)
fun ZoomableAsyncImage(
    model: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    state: ZoomableImageState = rememberZoomableImageState(rememberZoomableState()),
    imageLoader: ImageLoader = LocalContext.current.imageLoader,
    alpha: Float = DefaultAlpha,
    colorFilter: ColorFilter? = null,
    alignment: Alignment = Alignment.Center,
    contentScale: ContentScale = ContentScale.Fit,
    gesturesEnabled: Boolean = true,
    onClick: ((Offset) -> Unit)? = null,
    onLongClick: ((Offset) -> Unit)? = null,
    clipToBounds: Boolean = true,
) {
    ZoomableAsyncImage(
        model = model,
        contentDescription = contentDescription,
        gestures = if (gesturesEnabled) EnabledZoomGestures.ZoomAndPan else EnabledZoomGestures.None,
        modifier = modifier,
        state = state,
        imageLoader = imageLoader,
        alpha = alpha,
        colorFilter = colorFilter,
        alignment = alignment,
        contentScale = contentScale,
        onClick = onClick,
        onLongClick = onLongClick,
        onDoubleClick = DoubleClickToZoomListener.cycle(),
        clipToBounds = clipToBounds,
        contentPadding = PaddingValues(0.dp),
        interactionSource = null,
    )
}
