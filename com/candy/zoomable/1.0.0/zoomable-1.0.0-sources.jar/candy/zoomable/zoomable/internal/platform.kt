package candy.zoomable.zoomable.internal

internal enum class HostPlatform {
    Android,
    Desktop,
    iOS,
    Web,
    ;

    companion object;
}

internal val HostPlatform.Companion.current: HostPlatform
    get() = HostPlatform.Android
